<?php
 session_start();

if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_team'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_team']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_teamA'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_teamA_id_by_teamA_name($_POST['cbo_teamA']);
    return $id;
}
if (isset($_POST['cbo_teamB'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_teamB_id_by_teamB_name($_POST['cbo_teamB']);
    return $id;
}
if (isset($_POST['cbo_matches'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_matches_id_by_matches_name($_POST['cbo_matches']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_winner'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_winner_id_by_winner_name($_POST['cbo_winner']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_team'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_team']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_transfer_request'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_transfer_request_id_by_transfer_request_name($_POST['cbo_transfer_request']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_teamA'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_teamA_id_by_teamA_name($_POST['cbo_teamA']);
    return $id;
}
if (isset($_POST['cbo_teamB'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_teamB_id_by_teamB_name($_POST['cbo_teamB']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_matches'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_matches_id_by_matches_name($_POST['cbo_matches']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_team'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_team']);
    return $id;
}
if (isset($_POST['cbo_created_by'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_created_by_id_by_created_by_name($_POST['cbo_created_by']);
    return $id;
}
if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from profile
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);}
//The Delete from championship
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'championship') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_championship($id);}
//The Delete from schedule
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'schedule') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_schedule($id);}
//The Delete from fixture
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'fixture') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_fixture($id);}
//The Delete from matches
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'matches') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_matches($id);}
//The Delete from goal
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'goal') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_goal($id);}
//The Delete from penalty
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'penalty') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_penalty($id);}
//The Delete from substitution
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'substitution') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_substitution($id);}
//The Delete from card
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'card') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_card($id);}
//The Delete from team
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'team') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_team($id);}
//The Delete from player
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'player') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_player($id);}
//The Delete from federation_mng
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'federation_mng') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_federation_mng($id);}
//The Delete from transfer
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'transfer') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_transfer($id);}
//The Delete from trans_request
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'trans_request') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_trans_request($id);}
//The Delete from match_participant
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'match_participant') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_match_participant($id);}
//The Delete from team_manager
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'team_manager') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_team_manager($id);}
//The Delete from account
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);}
//The Delete from account_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
profile_del_udpate();
championship_del_udpate();
schedule_del_udpate();
fixture_del_udpate();
matches_del_udpate();
goal_del_udpate();
penalty_del_udpate();
substitution_del_udpate();
card_del_udpate();
team_del_udpate();
player_del_udpate();
federation_mng_del_udpate();
transfer_del_udpate();
trans_request_del_udpate();
match_participant_del_udpate();
team_manager_del_udpate();
account_del_udpate();
account_category_del_udpate();

