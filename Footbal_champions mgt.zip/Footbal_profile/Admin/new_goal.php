<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_goal'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'goal'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $goal_id=$_SESSION['id_upd'];
                      
$matches =trim( $_POST['txt_matches_id']);
$player = $_POST['txt_player_id'];

$winner = $_POST['txt_winner_id'];

$goal_team_a = $_POST['txt_goal_team_a'];
$goal_team_b = $_POST['txt_goal_team_b'];
$type = $_POST['txt_type'];
$entry_date = date("y-m-d");

$User = $_SESSION['userid'];



$upd_obj->update_goal($matches, $player, $winner, $goal_team_a, $goal_team_b, $type, $entry_date, $User,$goal_id);
unset($_SESSION['table_to_update']);
}}else{$matches =trim( $_POST['txt_matches_id']);
$player =trim( $_POST['txt_player_id']);
$winner =trim( $_POST['txt_winner_id']);
$goal_team_a = $_POST['txt_goal_team_a'];
$goal_team_b = $_POST['txt_goal_team_b'];
$type = $_POST['txt_type'];
$entry_date =date("y-m-d");
$User = $_SESSION['userid'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_goal($matches, $player, $winner, $goal_team_a, $goal_team_b, $type, $entry_date, $User);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
goal</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_goal.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_matches_id"   name="txt_matches_id"/><input type="hidden" id="txt_player_id"   name="txt_player_id"/><input type="hidden" id="txt_winner_id"   name="txt_winner_id"/>
      <?php
            include 'Admin_header.php';
                ?>

  <!--Start dialog's-->
          <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

<div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 goal saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  goal Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_goal_team_a">Goals team A </label></td><td> <input type="text"     name="txt_goal_team_a" required id="txt_goal_team_a" class="textbox" value="<?php echo trim(chosen_goal_team_a_upd());?>"   />  </td></tr>
<tr><td><label for="txt_goal_team_b">Goal Team B </label></td><td> <input type="text"     name="txt_goal_team_b" required id="txt_goal_team_b" class="textbox" value="<?php echo trim(chosen_goal_team_b_upd());?>"   />  </td></tr>
<tr><td><label for="txt_type">type </label></td><td> <input type="text"     name="txt_type" required id="txt_type" class="textbox" value="<?php echo trim(chosen_type_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_goal" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">goal List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_goal();
                    $obj->list_goal($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
               
var matches = '<?php echo chosen_matches_upd(); ?>';        $('.cbo_matches').val(matches);
        $('#txt_matches_id').val(matches);
    
        
var player = '<?php echo chosen_player_upd(); ?>';        $('.cbo_player').val(player);
        $('#txt_player_id').val(player);
    
        
var winner = '<?php echo chosen_winner_upd(); ?>';        $('.cbo_winner').val(winner);
        $('#txt_winner_id').val(winner);
    
     }
</script>
</body>
</hmtl>
<?php
function chosen_matches_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $matches = new multi_values();
               return $matches->get_chosen_goal_matches($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_player_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $player = new multi_values();
               return $player->get_chosen_goal_player($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_winner_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $winner = new multi_values();
               return $winner->get_chosen_goal_winner($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_goal_team_a_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $goal_team_a = new multi_values();
               return $goal_team_a->get_chosen_goal_goal_team_a($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_goal_team_b_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $goal_team_b = new multi_values();
               return $goal_team_b->get_chosen_goal_goal_team_b($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_type_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $type = new multi_values();
               return $type->get_chosen_goal_type($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $entry_date = new multi_values();
               return $entry_date->get_chosen_goal_entry_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'goal') {               $id = $_SESSION['id_upd'];
               $User = new multi_values();
               return $User->get_chosen_goal_User($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}

function get_matches_combo() {
    $obj = new multi_values();
    $obj->get_matches_in_combo();
}
function get_matches_combo() {
    $obj = new multi_values();
    $obj->get_matches_in_combo();
}
function get_matches_combo() {
    $obj = new multi_values();
    $obj->get_matches_in_combo();
}
