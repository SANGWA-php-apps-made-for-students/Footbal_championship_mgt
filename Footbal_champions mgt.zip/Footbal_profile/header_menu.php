<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                Footaball auto timetable
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_profile.php">profile</a>
<a href="new_championship.php">championship</a>
<a href="new_schedule.php">schedule</a>
<a href="new_fixture.php">fixture</a>
<a href="new_matches.php">matches</a>
<a href="new_goal.php">goal</a>
<a href="new_penalty.php">penalty</a>
<a href="new_substitution.php">substitution</a>
<a href="new_card.php">card</a>
<a href="new_team.php">team</a>
<a href="new_player.php">player</a>
<a href="new_federation_mng.php">federation_mng</a>
<a href="new_transfer.php">transfer</a>
<a href="new_trans_request.php">trans_request</a>
<a href="new_match_participant.php">match_participant</a>
<a href="new_team_manager.php">team_manager</a>
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
