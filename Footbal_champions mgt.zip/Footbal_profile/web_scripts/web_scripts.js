//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_to_update = '';
var table_to_delete = '';
var id_delete = 0;
var id_update = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {
get_new_data_hide_show();
show_form_toUpdate();
account_category_del_udpate();
//get_pages_moving();
dlog_btn_No_Yes();
hide_select_pane();
hide_Y_N_dialog();
account_category_del_udpate();
profile_del_udpate();
championship_del_udpate();
schedule_del_udpate();
fixture_del_udpate();
matches_del_udpate();
goal_del_udpate();
penalty_del_udpate();
substitution_del_udpate();
card_del_udpate();
team_del_udpate();
player_del_udpate();
federation_mng_del_udpate();
transfer_del_udpate();
trans_request_del_udpate();
match_participant_del_udpate();
team_manager_del_udpate();
account_del_udpate();
account_category_del_udpate();

        get_account_id_combo();        get_team_id_combo();        get_championship_id_combo();        get_championship_id_combo();        get_championship_id_combo();        get_account_id_combo();        get_teamA_id_combo();        get_teamB_id_combo();        get_matches_id_combo();        get_player_id_combo();        get_winner_id_combo();        get_player_id_combo();        get_match_id_combo();        get_match_id_combo();        get_player_id_combo();        get_match_id_combo();        get_team_id_combo();        get_account_id_combo();        get_profile_id_combo();        get_account_id_combo();        get_transfer_request_id_combo();        get_account_id_combo();        get_teamA_id_combo();        get_teamB_id_combo();        get_player_id_combo();        get_account_id_combo();        get_player_id_combo();        get_matches_id_combo();        get_account_id_combo();        get_team_id_combo();        get_created_by_id_combo();        get_account_category_id_combo();        get_profile_id_combo();


});

function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_team_id_combo() {
    try {
        $('.cbo_team').change(function () {
            var cbo_team = $('.cbo_team option:selected').val();
                $('#txt_team_id').val(cbo_team);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_championship_id_combo() {
    try {
        $('.cbo_championship').change(function () {
            var cbo_championship = $('.cbo_championship option:selected').val();
                $('#txt_championship_id').val(cbo_championship);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_championship_id_combo() {
    try {
        $('.cbo_championship').change(function () {
            var cbo_championship = $('.cbo_championship option:selected').val();
                $('#txt_championship_id').val(cbo_championship);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_championship_id_combo() {
    try {
        $('.cbo_championship').change(function () {
            var cbo_championship = $('.cbo_championship option:selected').val();
                $('#txt_championship_id').val(cbo_championship);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_teamA_id_combo() {
    try {
        $('.cbo_teamA').change(function () {
            var cbo_teamA = $('.cbo_teamA option:selected').val();
                $('#txt_teamA_id').val(cbo_teamA);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_teamB_id_combo() {
    try {
        $('.cbo_teamB').change(function () {
            var cbo_teamB = $('.cbo_teamB option:selected').val();
                $('#txt_teamB_id').val(cbo_teamB);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_matches_id_combo() {
    try {
        $('.cbo_matches').change(function () {
            var cbo_matches = $('.cbo_matches option:selected').val();
                $('#txt_matches_id').val(cbo_matches);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').val();
                $('#txt_player_id').val(cbo_player);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_winner_id_combo() {
    try {
        $('.cbo_winner').change(function () {
            var cbo_winner = $('.cbo_winner option:selected').val();
                $('#txt_winner_id').val(cbo_winner);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').val();
                $('#txt_player_id').val(cbo_player);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').val();
                $('#txt_match_id').val(cbo_match);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').val();
                $('#txt_match_id').val(cbo_match);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').val();
                $('#txt_player_id').val(cbo_player);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').val();
                $('#txt_match_id').val(cbo_match);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_team_id_combo() {
    try {
        $('.cbo_team').change(function () {
            var cbo_team = $('.cbo_team option:selected').val();
                $('#txt_team_id').val(cbo_team);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_transfer_request_id_combo() {
    try {
        $('.cbo_transfer_request').change(function () {
            var cbo_transfer_request = $('.cbo_transfer_request option:selected').val();
                $('#txt_transfer_request_id').val(cbo_transfer_request);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_teamA_id_combo() {
    try {
        $('.cbo_teamA').change(function () {
            var cbo_teamA = $('.cbo_teamA option:selected').val();
                $('#txt_teamA_id').val(cbo_teamA);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_teamB_id_combo() {
    try {
        $('.cbo_teamB').change(function () {
            var cbo_teamB = $('.cbo_teamB option:selected').val();
                $('#txt_teamB_id').val(cbo_teamB);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').val();
                $('#txt_player_id').val(cbo_player);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').val();
                $('#txt_player_id').val(cbo_player);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_matches_id_combo() {
    try {
        $('.cbo_matches').change(function () {
            var cbo_matches = $('.cbo_matches option:selected').val();
                $('#txt_matches_id').val(cbo_matches);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_team_id_combo() {
    try {
        $('.cbo_team').change(function () {
            var cbo_team = $('.cbo_team option:selected').val();
                $('#txt_team_id').val(cbo_team);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_created_by_id_combo() {
    try {
        $('.cbo_created_by').change(function () {
            var cbo_created_by = $('.cbo_created_by option:selected').val();
                $('#txt_created_by_id').val(cbo_created_by);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
                $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
                $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            window.location.reload();
        });
    });
    $('#no_btn, .no_btn, .abs_full').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.abs_full').fadeOut(10);
        $('.menu').show();
    });
    $('.abs_full').click(function () {
        $(this).fadeOut(200, function () {
            $('.y_n_dialog').fadeOut(70);
        });
    });
}
}function show_Y_N_dialog() {
      $('.abs_full').fadeIn(300,function () {
         $('.y_n_dialog').fadeIn(0);
    });
}
function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
function validate_numbers_textfields() {
  $('.only_numbers').keydown(function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                        // Allow: Ctrl+A, Command+A
                                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                                // Allow: home, end, left, right, down, up
                                        (e.keyCode >= 35 && e.keyCode <= 40)) {
                            // let it happen, don't do anything
                            return;
                        }
                        // Ensure that it is a number and stop the keypress
                        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                            e.preventDefault();
                        }
                    });   }
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer','pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname=$('#txt_shall_expand_toUpdate').val();
    if (updname!='') {
          $('.new_data_box').delay(200).slideDown();
    }
        
}
function postDisplayData(call_dialog,div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
         alert('Declined!');
    });
}function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}


//update from profile ...
 
function profile_del_udpate() {   $('.profile_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromprofile.. 
 $('.profile_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from championship ...
 
function championship_del_udpate() {   $('.championship_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromchampionship.. 
 $('.championship_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from schedule ...
 
function schedule_del_udpate() {   $('.schedule_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromschedule.. 
 $('.schedule_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from fixture ...
 
function fixture_del_udpate() {   $('.fixture_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromfixture.. 
 $('.fixture_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from matches ...
 
function matches_del_udpate() {   $('.matches_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete frommatches.. 
 $('.matches_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from goal ...
 
function goal_del_udpate() {   $('.goal_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromgoal.. 
 $('.goal_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from penalty ...
 
function penalty_del_udpate() {   $('.penalty_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete frompenalty.. 
 $('.penalty_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from substitution ...
 
function substitution_del_udpate() {   $('.substitution_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromsubstitution.. 
 $('.substitution_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from card ...
 
function card_del_udpate() {   $('.card_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromcard.. 
 $('.card_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from team ...
 
function team_del_udpate() {   $('.team_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromteam.. 
 $('.team_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from player ...
 
function player_del_udpate() {   $('.player_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromplayer.. 
 $('.player_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from federation_mng ...
 
function federation_mng_del_udpate() {   $('.federation_mng_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromfederation_mng.. 
 $('.federation_mng_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from transfer ...
 
function transfer_del_udpate() {   $('.transfer_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromtransfer.. 
 $('.transfer_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from trans_request ...
 
function trans_request_del_udpate() {   $('.trans_request_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromtrans_request.. 
 $('.trans_request_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from match_participant ...
 
function match_participant_del_udpate() {   $('.match_participant_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete frommatch_participant.. 
 $('.match_participant_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from team_manager ...
 
function team_manager_del_udpate() {   $('.team_manager_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromteam_manager.. 
 $('.team_manager_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from account ...
 
function account_del_udpate() {   $('.account_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromaccount.. 
 $('.account_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
//update from account_category ...
 
function account_category_del_udpate() {   $('.account_category_update_link').click(function () {        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
         $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        }); });//delete fromaccount_category.. 
 $('.account_category_delete_link').click(function () {
          table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
