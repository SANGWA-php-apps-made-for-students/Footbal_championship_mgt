<?php
    session_start();
?>
<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="parts eighty_centered no_paddin_shade_no_Border reverse_border">
            <div class="parts full_center_two_h margin_free heit_free no_shade_noBorder whilte_text skin" id="">
                <div class="parts no_paddin_shade_no_Border  "style=" background-size: 40%;  background-repeat: no-repeat;background-image: url('web_images/logo2.png');">
                </div>
            </div>
            <?php
            include './Admin_header.php';
            ?>   
            <div class="parts eighty_centered ">
                <div class="parts x_height_fifty x_width_two_h scoll_free  no_shade_noBorder">
                    <div class="parts margin_free whilte_text">  5</div> &nbsp; Tot users
                </div>
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                  <div class="parts margin_free whilte_text">  60</div>   &nbsp;   Tot Matches
                </div>
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                 <div class="parts margin_free whilte_text">  40</div>  &nbsp;  Tot Referees
                </div>
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                    <div class="parts margin_free whilte_text">  30</div> &nbsp;   Tot Champions
                </div>
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                    <div class="parts margin_free whilte_text">  45</div>   &nbsp;  Tot Teams
                </div>
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                 <div class="parts margin_free whilte_text">  6</div>   &nbsp;   Total Federation managers
                </div>
                
                <div class="parts x_height_fifty x_width_two_h scoll_free no_shade_noBorder">
                 <div class="parts margin_free whilte_text">  86</div>   &nbsp;   Total Transfers
                </div>
                
                
            </div>
            
        </div>
    </body>
</html>
