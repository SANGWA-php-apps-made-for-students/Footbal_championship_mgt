<div class="parts menu full_center_two_h heit_free margin_free no_shade_noBorder reverse_border skin">
<!--    <div class="parts allow_drop no_shade_noBorder">
        <a href="#">Users</a>
        <div class="parts hovable_item  ">
            <a href="All_users.php">All users</a>
            <a href="new_team_manager.php">Team Manager</a>
            <a href="new_account_category.php">Account category</a>
            <a href="new_referee.php">Referee</a>
            <a href="new_federation_mng.php">Federation managers</a>
            <a href="new_team_manager.php">Team managers</a>
            <a href="new_coordinator.php">Admin</a>
        </div>
    </div>-->
    <div class="parts allow_drop1 no_shade_noBorder"> 
        <a href="#">Championships</a>
        <div class="parts hovable_item1">   
          
          
            <a href="new_card.php">Cards</a>
               <a href="new_goal.php">Goal</a>
               <a href="new_penalty.php">Penalty</a>
            <a href="new_confirmation.php">Confirm match</a>
            <!--<a href="new_fixture.php">Fixtures</a>-->
         
            <!--<a href="new_penalty.php">Penalties</a>-->
<!--            <a href="new_player.php">Player</a>
              <a href="new_team.php">Teams</a>-->
            <!--<a href="new_trans_request.php">Transfer request</a>-->
            <!--<a href="new_transfer.php">Transfer</a>-->
        </div>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">  <?php echo 'Welcome ' . $_SESSION['cat']; ?></a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">Home</a>
    </div>

</div>


<!--<div>
    preparation
    
    
    
    
    events
    
    
    
    view
    
    
    <a href="All_users.php">All users</a>
    <a href="new_team_manager.php">Team Manager</a>
    <a href="new_account_category.php">Account category</a>
    <a href="new_referee.php">Referee</a>
    <a href="new_federation_mng.php">Federation managers</a>
    <a href="new_team_manager.php">Team managers</a>
    <a href="new_coordinator.php">Coordinator</a>
    
    <a href="new_championship.php">Championships</a>  
    <a href="new_schedule.php">Schedule</a>
    <a href="new_card.php">Cards</a>
    <a href="new_confirmation.php">Confirm match</a>
    <a href="new_fixture.php">Fixtures</a>
    <a href="new_goal.php">Goal</a>
    <a href="new_player.php">Player</a>
   /---------------------------------------

    <a href="new_confirmation.php">Confirmation</a>
    <a href="new_card.php">Cards</a>
    <a href="new_fixture.php">Fixtures</a>
    <a href="new_goal.php">Goal</a>
    <a href="new_penalty.php">Penalties</a>

    //----------------------------------------------
    
     <a href="new_licenses_check.php">Licenses</a>
     <a href="new_match_participant.php">Confirm participants</a>

</div>-->