<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
 
?>
<html>
    <head>
        <title>
            account</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>  
    <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered">
                 <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                   <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                          Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                  
                </div>
                <div class="parts sixty_centered ">  account</div>
                <table class="new_data_table off">
                    <tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" />  </td></tr>
                    <tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" />  </td></tr>
                    <tr><td>account_category :</td><td> <input type="text"     name="txt_account_category" required class="textbox" />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_account" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_All_users();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

