<?php

require_once('../../web_db/connection.php');
$db = new dbconnection();
$sql = "select   championship.name from championship order by championship.championship_id desc limit 1";
$stmt = $db->openConnection()->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$userid = $row['name'];
echo $userid;
