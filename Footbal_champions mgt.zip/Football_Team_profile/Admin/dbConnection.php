<?php

class my_connection {
    function getCon() {
        $db = new PDO('mysql:host=localhost;dbname=footbal_profile;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}
