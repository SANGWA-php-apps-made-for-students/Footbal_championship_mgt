<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="get_team_cols.php" method="post">
            <div class="parts" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_teams_to_participate();
                ?> 
                <input type="submit" name="send_all"  value="Save"/>
            </div> 
            <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
            <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        </form>
    </body>
</html>

<?php
if (isset($_POST['send_all'])) {

    $FirstArray = array('a', 'b', 'c', 'd');
    $SecondArray = array('1', '2', '3', '4');
    
    foreach ($FirstArray as $index => $value) {
        echo $FirstArray[$index] . $SecondArray[$index];
        echo "<br/>";
    }
   
}
