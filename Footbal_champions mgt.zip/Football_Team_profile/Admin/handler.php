<?php

session_start();
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_team'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_team']);
    return $id;
}
if (isset($_POST['cbo_teamA'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_teamA']);
    return $id;
}
if (isset($_POST['cbo_teamB'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_team_id_by_team_name($_POST['cbo_teamB']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_championship_id_by_championship_name($_POST['cbo_championship']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_player'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_player_id_by_player_name($_POST['cbo_player']);
    return $id;
}
if (isset($_POST['cbo_match'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_match_id_by_match_name($_POST['cbo_match']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['profile_by_id'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_by_id($_POST['profile_by_id']);
    echo $id;
}
if (isset($_POST['keep_match_id'])) {
    $_SESSION['current_match'] = $_POST['keep_match_id'];
    if (!empty($_SESSION['current_match'])) {
        
    }
}
if (isset($_POST['get_match_displed'])) {//though we said that it is match team A, it returns all the teams
    if (!empty($_SESSION['current_match'])) {
        $get_match_displed = $_POST['get_match_displed'];
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_matches_teamA_name_by_matches($_SESSION['current_match']);
        return $id;
    }
}
if (isset($_POST['current_championship'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_lastchampionship_name();
    echo $id;
}
if (isset($_POST['players_by_teams'])) {
    $teamA = $_POST['teamA'];
    $teamB = $_POST['teamB'];

    require_once '../web_db/player_selected_by_id.php';
    $obj = new multi_valuesp();
    $id = $obj->get_player_by_teams($teamA, $teamB);
    return $id;
}
if (isset($_POST['match_confimr'])) {
    require_once '../web_db/updates.php';
    $obj = new updates();
    $id = $obj->update_confirm_match('yes', $_POST['match_confimr']);

    return $id;
}
if (isset($_POST['schedule_id'])) {
    $champ_id = $_POST[champ_id];
    require_once '../web_db/updates.php';
    $obj = new updates();
    return $id;
}
