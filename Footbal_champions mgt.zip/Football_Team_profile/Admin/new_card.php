<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}include '../web_db/multi_values.php';
if (isset($_POST['send_card'])) {
    $card_date = date("Y-m-d");
    $player = $_POST['txt_player_id'];
    if (!empty($card_date) && !empty($player)) {
        $match = $_POST['txt_match_id'];
        $color = $_POST['txt_color_id'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_card($color, $card_date, $player, $match);
    } else {
        ?>
        <script>
            alert('You have to select the player and the match');
        </script>
        <?php
    }
}
?>
<html>
    <head>
        <title>
            card</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_card.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_player_id" placeholder="player"   name="txt_player_id"/>
            <input type="hidden" id="txt_match_id" placeholder="match"  name="txt_match_id"/>
            <input type="hidden" id="txt_color_id"  placeholder="color"  name="txt_color_id"/>
            <div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts  seventy_centered abs_child left_off_seventy off" style="opacity: 1;" id="dialog_child">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_players();
                ?>
            </div>

            <div class="parts  seventy_centered abs_child left_off_seventy  heit_free off" style="opacity: 1;" id="dialog_child_mathces">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_mathes();
                ?>
            </div>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered">
                <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                </div>
                <div class="parts sixty_centered ">  card</div>
                <table class="new_data_table">
                    <tr><td>color :</td><td> 
                            <div class="parts iconed no_shade_noBorder" id="yellow_card">
                            </div>
                            <div class="parts iconed no_shade_noBorder" id="red_card">
                            </div>
                            <input type="text" style="margin-top: 16px;" id="txt_card" name="txt_color" disabled="true">

                        </td></tr>
                    <tr><td>player :</td><td> 
                            <a href="#" id="show_player" style="color: #000080;">Choose a player</a>
                        </td></tr>
                    <tr><td>match :</td><td> 
                            <a href="#" id="show_match" style="color: #000080;">Choose a match</a>
                        </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_card" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_card();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_player_combo() {

    $obj = new multi_values();
    $obj->get_player_in_combo();
}

function get_match_combo() {
    $obj = new multi_values();
    $obj->get_match_in_combo();
}
