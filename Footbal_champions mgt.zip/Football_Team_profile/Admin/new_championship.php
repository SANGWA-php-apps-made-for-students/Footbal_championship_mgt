<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
if (isset($_POST['send_championship_home'])) {

    $date_started = date("Y-m-d");
    $account = $_SESSION['userid'];
    $championship = $_POST['txt_championship_name'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_championship($date_started, $account, $championship);

    require_once '../web_db/connection.php';

    $schedule_date = date("Y-m-d");
    $obj_mul = new multi_values();

    $last_championship = $obj_mul->get_last_championship();
    require_once '../web_db/new_values.php';
    require_once '../web_db/multi_values.php';
    require_once '../web_db/updates.php';
    $obj = new new_values();
    $obj_update = new updates();
    $team_id = $_POST['teams'];
    $team_id2 = $_POST['teams'];
    $home_team_c = 0;
    //match
    $account = $_SESSION['userid'];

    $date_picked = '';

    $confirmed = 'no';

    //save the fixture
    $fixture_date = date("Y-m-d");
    $championship = $last_championship;

    $position = '0';
    $date_to_play = date("Y-m-d");
    $counter1 = 0;
    foreach ($team_id as $counter) {
        $counter1+=1;
    }
    if ($counter1 % 2 == 0) {
        foreach ($team_id as $team) {
            $database = new dbconnection();
            $sql = "select    player_id  from player  
                join team on player.team = team.team_id 
                where   team.team_id =:team_id ";
            $stmt = $database->openconnection()->prepare($sql);
            $stmt->bindValue(':team_id', $team);
            $stmt->execute();
            while ($row = $stmt->fetch()) {
                $userid = $row['player_id'];
                $obj->new_match_participant('no', 0, $userid, 'no', 'no');
            }
            if ($home_team_c % 2 == 0) {
                $sql2 = "select    team_name from team where team_id=:team_id";
                $stmt2 = $database->openConnection()->prepare($sql2);
                $stmt2->bindValue(':team_id', $team);
                $stmt2->execute();
                $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                $teamA_name = $row2['team_name'];
                $obj->new_match('null', $team, 'null', $championship, $account, $teamA_name, 'null', 'null', 'null');
                $obj->new_schedule('', $team, '', $last_championship, $teamA_name, '', '');
                $obj->new_fixture($schedule_date, $championship, $team, '', $position, '', $teamA_name, '');

                $obj->new_away_schedule('', '', $team, $championship, '', $teamA_name, '');
                $obj->new_away_match_match('', '', $team, $championship, $account, '', $teamA_name, '', '');
                $obj->new_away_match_fixture($fixture_date, $championship, '', $team, $position, '', '', $teamA_name);
            } if ($home_team_c % 2 != 0) {
                $sql2 = "select    team_name from team where team_id=:team_id";
                $stmt2 = $database->openConnection()->prepare($sql2);
                $stmt2->bindValue(':team_id', $team);
                $stmt2->execute();
                $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                $teamA_name = $row2['team_name'];
                $obj_update->update_away_team_match($team, $teamA_name);
                $obj_update->update_away_team_schedule($team, $teamA_name);
                $obj_update->update_away_team_fixture($team, $teamA_name);

                $obj_update->update_away_team_match2($team, $teamA_name);
                $obj_update->update_away_team_schedule2($team, $teamA_name);
                $obj_update->update_away_team_fixture2($team, $teamA_name);
            }$home_team_c+=1;
        }
    } else {
        ?>
        <script>
            alert('The number of teams must be even');
        </script>
        <?php
    }
}
?>
<html>
    <head>
        <title>
            championship</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_championship.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
            include 'Admin_header.php';
            ?>

            <?php
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            $res = $obj->get_unassigned_teams();
            if (!$res) {
                ?>
                <div class="parts eighty_centered"> 
                    <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                        <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                            Current championship
                        </div>
                        <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                            Name championship
                        </div>

                    </div>
                    <div class="parts sixty_centered ">  championship</div>
                    <table class="new_data_table"><tr><td>Name:</td><td>
                                <input type="text" class="textbox" name="txt_championship_name" required /></td>
                            <td>
                            <td colspan="2">

                                <div class="parts" >
                                    <?php
                                    $obj = new multi_values();
                                    $obj->get_teams_to_participate();
                                    ?> 
                                </div> 
                            </td>
                            </td>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons two_fifty_right heit_free" name="send_championship_home" value="Start championship"/> 

                            </td></tr>
                    </table>
                </div>
                <div class="parts eighty_centered" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_championship();
                    ?>
                </div> 
                <?php
            } else {
                ?>
                <div class="parts eighty_centered x_titles full_center_two_h heit_free no_shade_noBorder">
                    They are some teams who have no players
                </div>
                <div class="parts eighty_centered heit_free">
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->get_unassigned_teams_list();
                    ?>
                </div>
                <?php
            }
            ?></form>
        <script src = "../web_scripts/jquery-2.1.3.min.js" type = "text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_account_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_account_in_combo();
}
