<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
if (isset($_POST['send_player'])) {
    $name = $_POST['txt_name'];
    $middle_name = $_POST['txt_middle_name'];
    $last_name = $_POST['txt_last_name'];
    $gender = $_POST['txt_gender'];
    $date_of_birth = $_POST['txt_date_of_birth'];
    $nationality = $_POST['txt_nationality'];
    $date_registered = date("Y-m-d");
    $telephone = $_POST['txt_telephone'];
    $residence = $_POST['txt_residence'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence);

    $obj_mul = new multi_values();
    $last_profile = $obj_mul->get_last_profile();

    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];
    $account_category = 12;
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_referee($username, $password, $account_category, $last_profile);
}
?>
<html>
    <head>
        <title>
            player</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_coordinator.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_team_id"   name="txt_team_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <div class=" parts abs_full accept_abs off"  id="dialog_students">
            </div>
            <div class="parts abs_child fifty_centered  heit_free  off " style="background-color: #ffffff; padding-bottom: 50px; border:1px solid #2c2d62  " id="box_get_profile_by_id">

            </div>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered off">
                player saved successfully!</div>
            <div class="parts eighty_centered"><div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>

                </div>
                <div class="parts sixty_centered ">  New Coordinator</div>
                <div class="parts  no_paddin_shade_no_Border">
                    <table class="new_data_table" style="margin-top: 0px;">
                        <tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" style="width:250px;" />  </td></tr>
                        <tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" style="width:250px;" />  </td></tr>
                        <tr><td colspan="2">
                            </td></tr>
                    </table>

                    <table class="new_data_table" style="margin-top: 5px;">
                        <tr><td colspan="2"><center> PERSONAL DETAILS </center></td></tr>
                        <tr><td colspan="2" >
                                <table class="new_data_table"   style="margin-top: 0px;">
                                    <tr ><td>name :</td><td> <input type="text"     name="txt_name" required class="parts" />  </td> 
                                        <td>middle_name :</td><td> <input type="text"     name="txt_middle_name"  class="parts" />  </td>
                                        <td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="parts" />  </td>
                                    </tr>
                                    <tr>
                                        <td> gender :</td><td> 

                                            <select name="txt_gender">
                                                <option></option>
                                                <option>Male</option>
                                                <option>Female</option>
                                            </select>
                                        </td>
                                        <td>date_of_birth :</td><td> <input type="date"     name="txt_date_of_birth" required class="parts" /> </td>
                                        <td>nationality :</td><td> <input type="text" value="Rwandan"    name="txt_nationality" required class="parts" />  </td>
                                    </tr>
                                    <tr>
                                        <td>telephone :</td><td> <input type="text"     name="txt_telephone" required class="parts" />  </td>
                                        <td>residence :</td><td> <input type="text"     name="txt_residence" required class="parts" />  </td>
                                        <td></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr><td></td><td>  <input type="submit" class="confirm_buttons" name="send_player" value="Save"/>  </td></tr>
                    </table>

                </div>
            </div>
            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_referees('coordinator');
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_team_combo() {

    $obj = new multi_values();
    $obj->get_team_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}
