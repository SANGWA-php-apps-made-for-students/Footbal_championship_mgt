<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
include '../web_db/multi_values.php';
if (isset($_POST['send_match'])) {
    $match_date = date("Y-m-d");
    $teamA = $_POST['txt_team_idA'];
    $teamB = $_POST['txt_team_idB'];
    if ($teamA == $teamB) {
        ?>
        <script>
            alert('You have to select different teams');
        </script>
        <?php
    } else {
        $teamA_name = $_POST['txt_teamA_name'];
        $teamB_name = $_POST['txt_teamB_name'];
        $account = $_SESSION['userid'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj_mul = new multi_values();
        $last_championship = $obj_mul->get_last_championship();
        $stadium = $_POST['txt_stadium'];
        $confirmed = 'no';
        $obj->new_match($match_date, $teamA, $teamB, $last_championship, $account, $teamA_name, $teamB_name, $stadium, $confirmed);
    }
}
?>
<html>
    <head>
        <title>
            match</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_match.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_championship_id"   name="txt_championship_id"/>
            <input type="hidden" id="txt_team_idA"   name="txt_team_idA"/>
            <input type="hidden" id="txt_team_idB"   name="txt_team_idB"/>
            <input type="hidden" id="txt_teamA_name"   name="txt_teamA_name"/>
            <input type="hidden" id="txt_teamB_name"   name="txt_teamB_name"/>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered"> <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                </div>
                <div class="parts sixty_centered ">  match</div>
                <table class="new_data_table">
                    <tr><td>team :</td><td> <?php get_teamA_combo(); ?>  </td></tr> 
                    <tr><td>team :</td><td> <?php get_teamB_combo(); ?>  </td> 
                    <tr><td>Stadium :</td><td> <input type="text" class="textbox" name="txt_stadium" /> </td> 
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_match" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered" >
                <?php
                $obj = new multi_values();
                $obj->list_matches();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_championship_combo() {
    $obj = new multi_values();
    $obj->get_championship_in_combo();
}

function get_account_combo2() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_teamA_combo() {
    $obj = new multi_values();
    $obj->get_teamA_in_combo();
}

function get_teamB_combo() {
    $obj = new multi_values();
    $obj->get_teamB_in_combo();
}
