<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_profile'])) {

    $name = $_POST['txt_name'];
    $middle_name = $_POST['txt_middle_name'];
    $last_name = $_POST['txt_last_name'];
    $gender = $_POST['txt_gender'];
    $date_of_birth = $_POST['txt_date_of_birth'];
    $nationality = $_POST['txt_nationality'];
    $date_registered = $_POST['txt_date_registered'];
    $telephone = $_POST['txt_telephone'];
    $residence = $_POST['txt_residence'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence);
}
?>

<html>
    <head>
        <title>
            profile</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_profile.php" method="post" enctype="multipart/form-data">



            <?php
            include 'Admin_header.php';
            ?>

            <div class="parts eighty_centered">
                profile saved successfully!</div>

            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  profile</div>
                <table class="new_data_table">
                    <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
                    <tr><td>middle_name :</td><td> <input type="text"     name="txt_middle_name" required class="textbox" />  </td></tr>
                    <tr><td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="textbox" />  </td></tr>
                    <tr><td>gender :</td><td> <input type="text"     name="txt_gender" required class="textbox" />  </td></tr>
                    <tr><td>date_of_birth :</td><td> <input type="text"     name="txt_date_of_birth" required class="textbox" />  </td></tr>
                    <tr><td>nationality :</td><td> <input type="text"     name="txt_nationality" required class="textbox" />  </td></tr>
                    <tr><td>date_registered :</td><td> <input type="text"     name="txt_date_registered" required class="textbox" />  </td></tr>
                    <tr><td>telephone :</td><td> <input type="text"     name="txt_telephone" required class="textbox" />  </td></tr>
                    <tr><td>residence :</td><td> <input type="text"     name="txt_residence" required class="textbox" />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_profile" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_profile();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>



        <div class="parts full_center_two_h footer skin"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

