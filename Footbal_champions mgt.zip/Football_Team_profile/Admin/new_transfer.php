<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
} include '../web_db/multi_values.php';
if (isset($_POST['send_transfer'])) {
    $transfer_request = $_POST['txt_transfer_request_id'];
    $trans_date = date("Y-m-d");
    $agreed_price = $_POST['txt_agreed_price'];
    $account = $_SESSION['userid'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_transfer($transfer_request, $trans_date, $agreed_price, $account);
    //update team    
    require_once '../web_db/updates.php';
    $player_id = $_POST['txt_player_id'];
    $team = $_POST['txt_trans_team_id'];

    $upd_obj = new updates();
    $upd_obj->update_player_team($team, $player_id);
}
?>
<html>
    <head>
        <title>
            transfer
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_transfer.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_transfer_request_id"   name="txt_transfer_request_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_player_id"   name="txt_player_id"/>
            <input type="hidden" id="txt_trans_team_id"   name="txt_trans_team_id"/>
            <div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts x_height_4x full_center_two_h abs_child  off heit_free" style="opacity: 1; background-color: #529bac;" id="dialog_child_trans_requests">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_request();
                ?>
            </div>
            <?php
            include 'Admin_header.php';
            ?> 
            <div class="parts eighty_centered"><div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>                  
                </div>
                <div class="parts sixty_centered ">  transfer</div>
                <div class="parts sixty_centered ">    <table class="new_data_table">

                        <tr><td>transfer_request :</td><td> 
                                <a href="#" id="show_trans_requests" style="color: #000080;">Choose a request</a>
                            </td></tr>
                        <tr><td>agreed_price :</td><td> <input type="text"     name="txt_agreed_price" required class="only_numbers textbox" />  </td></tr>

                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_transfer" value="Save"/>  </td></tr>
                    </table></div>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_transfer();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_transfer_request_combo() {

    $obj = new multi_values();
    $obj->get_transfer_request_in_combo();
}

function get_account_combo() {

    $obj = new multi_values();
    $obj->get_account_in_combo();
}
