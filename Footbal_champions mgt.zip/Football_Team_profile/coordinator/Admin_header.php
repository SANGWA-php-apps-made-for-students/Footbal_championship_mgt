<div class="parts menu full_center_two_h heit_free margin_free no_shade_noBorder reverse_border skin">

    <div class="parts allow_drop1 no_shade_noBorder"> 
        <a href="#">Match events</a>
        <div class="parts hovable_item1">
            <a href="new_confirmation.php">Confirmation</a>
            <a href="new_card.php">Cards</a>
            <a href="new_fixture.php">Fixtures</a>
            <a href="new_goal.php">Goal</a>
            <a href="new_penalty.php">Penalties</a>
 
        </div>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">  <?php echo 'Welcome ' . $_SESSION['cat']; ?></a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">Home</a>
    </div>

</div>