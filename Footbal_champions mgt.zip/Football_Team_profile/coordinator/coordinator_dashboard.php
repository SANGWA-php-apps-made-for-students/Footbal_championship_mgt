<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head> 
</head>
<body>
    <form action="coordinator_dashboard.php" method="post">
        <?php
        include 'Admin_header.php';
        ?>
        <div class="parts eighty_centered">
            
        <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
            <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                Current championship
            </div>
            <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                Name championship
            </div>

        </div>



        </div>
    </form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
</body>
</html>
