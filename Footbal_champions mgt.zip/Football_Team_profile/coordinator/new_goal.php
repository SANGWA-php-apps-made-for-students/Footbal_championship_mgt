<?php
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_goal'])) {
    require_once '../web_db/multi_values.php';
    $obj_mul = new multi_values();
    $goal_date = date("Y-m-d");
    $fixture_date = $goal_date;
    $match = $_POST['txt_match_id'];
    $player = $_POST['txt_player_id'];

    //get team by player
    $team_by_player = $obj_mul->get_team_by_player($player);

    //get the point of each team 
    $pointsA = $obj_mul->get_point_teamA($match);
    $pointsB = $obj_mul->get_point_teamB($match);

    $teamA = $obj_mul->get_teamA_by_match($match);
    $teamB = $obj_mul->get_teamA_by_match($match);

    if ($team_by_player == $teamA) {
        $winner = $teamA;
        $pointsA = 3;
        $pointsB = 0;
    } else {
        $winner = $teamB;
        $pointsB = 3;
        $pointsA = 0;
    }
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_goal($goal_date, $match, $player, $winner, $pointsA, $pointsB);
}
?>
<html>
    <head>
        <title>
            goal</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_goal.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_match_id"   name="txt_match_id"/>
            <input type="hidden" id="txt_player_id"   name="txt_player_id"/>
            <div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts x_height_4x eighty_centered abs_child left_off_seventy off  heit_free" style="opacity: 1; " id="dialog_child">
                <?php
//                require_once '../web_db/multi_values.php';
//                $obj_mul = new multi_values();
//                $obj_mul->get_selectable_players_for_goals();
                ?>
            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off heit_free" style="opacity: 1;" id="dialog_child_mathces">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_mathes_for_goal();
                ?>
            </div>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered">
                <div class="parts full_center_two_h heit_free ">  goal</div>
                <table class=" parts new_data_table">
                    <tr><td>match :</td><td>
                            <a href="#" id="show_match" style="color: #000080;">Choose a match</a>
                        </td>
                        <td> <div class="parts no_paddin_shade_no_Border" id="current_match_box">
                            </div>
                        </td>
                    </tr>
                    <tr><td>player :</td><td> 
                            <a href="#" id="show_player" style="color: #000080;">Choose a player</a>
                        </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_goal" value="Save"/>  </td></tr>
                    <td></td>
                </table><div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                   <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                          Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                  
                </div>
                <div class="parts two_fifty_right heit_free" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_goal();
                    ?>
                </div>  
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_match_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_match_in_combo();
}

function get_player_combo() {
    $obj = new multi_values();
    $obj->get_player_in_combo();
}
