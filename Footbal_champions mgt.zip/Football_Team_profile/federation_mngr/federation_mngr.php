<?php session_start(); ?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
       include './Admin_header.php';
        
        ?>
        <form action="federation_mngr.php" method="post">
                        
        </form>
    </body>
</html>
