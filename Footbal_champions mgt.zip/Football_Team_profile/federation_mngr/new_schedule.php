<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
if (isset($_POST['send_schedule'])) {
    require_once '../web_db/updates.php';
    $champ_id = $_POST['txt_champ_id'];
    $match_id = $_POST['txt_match_id'];
    $update_obj = new updates();
    $date_pick = $_POST['date_pick'];
    $stadium = $_POST['txt_stadium'];
    $t = $_POST['txt_time'];
    $hour = substr($t, -3, -1);
    $min = $_POST['txt_min'];
    $time = $date_pick . ' :' . $hour . ':' . $min.':00';
     
    $update_obj->update_match_staidum_time($time, $stadium, $match_id);
    $update_obj->update_fixture_staidum_time($time, $champ_id);
    
}
?>
<html>
    <head>
        <title>
            schedule
        </title>
        <link href = "web_style/styles.css" rel = "stylesheet" type = "text/css"/>
        <link href = "web_style/StylesAddon.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.theme.min.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.theme.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.structure.min.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.structure.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.min.css" rel = "stylesheet" type = "text/css"/>
        <link href = "date_picker/jquery-ui.css" rel = "stylesheet" type = "text/css"/>
    </head>
    <body>
        <form action = "new_schedule.php" method = "post" enctype = "multipart/form-data">
            <input type = "hidden" id = "txt_team_idA" name = "txt_team_idA"/>
            <input type = "hidden" id = "txt_team_idB" name = "txt_team_idB"/>
            <input type = "hidden" id = "txt_away_id" class = "off" name = "txt_away_id"/>
            <input type = "hidden" id = "txt_home_id" class = "off" name = "txt_home_id"/>
            <input type = "hidden" id = "txt_championship_id" name = "txt_championship_id"/>
            <input type = "hidden" id = "txt_teamA_name" name = "txt_teamA_name"/>
            <input type = "hidden" id = "txt_teamB_name" name = "txt_teamB_name"/>
            <input type = "hidden" id = "txt_champ_id" name = "txt_champ_id"/>
            <input type = "hidden" id = "txt_match_id" name = "txt_match_id"/>
            <div class = " parts abs_full accept_abs off" id = "dialog_teams_box">
            </div>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">
                <div class="parts">
                    <div class=" parts abs_full accept_abs off"  id="dialog_students">

                    </div>
                    <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off" style="opacity: 1;" id="dialog_update_datePicker">
                        <table>
                            <tr>
                                <td>Match date:</td>
                                <td>
                                    <table>
                                        <tr>
                                            <td> 
                                                <input type="text"style="float: left;" id="date_pick" class="textbox" name="date_pick"/>
                                            </td>
                                            <td>
                                                <select style="width: auto;" name="txt_time">
                                                    <option>08h</option>
                                                    <option>09h</option>
                                                    <option>10h</option>
                                                    <option>11h</option>
                                                    <option>12h</option>
                                                    <option>13h</option>
                                                    <option>14h</option>
                                                    <option>14h</option>
                                                    <option>15h</option>
                                                    <option>16h</option>
                                                    <option>17h</option>
                                                    <option>18h</option>
                                                    <option>19h</option>
                                                    <option>20h</option>
                                                    <option>21h</option>
                                                    <option>22h</option>
                                                    <option>23h</option>
                                                    <option>00h</option>
                                                    <option>01h</option>
                                                    <option>02h</option>
                                                    <option>03h</option>
                                                    <option>04h</option>
                                                    <option>05h</option>
                                                    <option>06h</option>
                                                    <option>07h</option>
                                                </select> 
                                            </td>
                                            <td>
                                                <input type="text" class="two_digits only_numbers" placeholder="minutes"  style="width: 80px; padding: 10px;" id="minutes" name="txt_min">
                                            </td>
                                        </tr>

                                    </table>
                                </td> 

                            <tr>
                                <td>Stadium:</td>
                                <td><input type="text" class="textbox" name="txt_stadium"/></td></tr>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="submit" class="confirm_buttons"   name="send_schedule" value="Save"/>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="parts eighty_centered " >
                <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                </div>
                <?php
                $obj = new multi_values();
                $obj->list_schedule_to_update();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js"     type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $('#date_pick').datepicker({
                minDate: new Date(),
                dateFormat: 'yy-mm-dd'
            });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_teamA_combo() {
    $obj = new multi_values();
    $obj->get_teamA_in_combo();
}

function get_teamB_combo() {
    $obj = new multi_values();
    $obj->get_teamB_in_combo();
}

function get_championship_combo() {
    $obj = new multi_values();
    $obj->get_championship_in_combo();
}
