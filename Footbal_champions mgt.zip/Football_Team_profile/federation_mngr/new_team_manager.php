<?php
session_start();
require_once '../web_db/multi_values.php';
if (isset($_POST['send_account'])) {
    $name = $_POST['txt_name'];
    $middle_name = $_POST['txt_middle_name'];
    $last_name = $_POST['txt_last_name'];
    $gender = $_POST['txt_gender'];
    $date_of_birth = $_POST['txt_date_of_birth'];
    $nationality = $_POST['txt_nationality'];
    $date_registered = date("Y-m-d");
    $telephone = $_POST['txt_telephone'];
    $residence = $_POST['txt_residence'];

    require_once '../web_db/new_values.php';
    require_once '../web_db/multi_values.php';
    $obj = new new_values();
    $obj->new_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence);

    $obj_mul = new multi_values();
    $last_profile = $obj_mul->get_last_profile();
    //account

    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];
    $account_category = '2';
    $date_created=date('Y-m-d');
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_account($account_category,$date_created,$last_profile,$username, $password,  'no');

    //new team manager
    $team_managerdeleted = 'no';
    $account = $obj_mul->get_lastaccount();
    $team = $_POST['txt_team_id'];
    $created_by = $_SESSION['userid'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_team_manager($team_managerdeleted, $account, $team, $created_by);
}
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include './Admin_header.php';
        ?>
        <form action="new_team_manager.php" method="post">
            <input type="hidden" id="txt_team_id"   name="txt_team_id"/>
            <div class="parts eighty_centered"> 
                <div class="parts two_fifty_right off x_width_3x skin2 no_paddin_shade_no_Border" id="current_champ">
                    <div class="parts full_center_two_h heit_free no_shade_noBorder  margin_free skin3">
                        Current championship
                    </div>
                    <div class="parts full_center_two_h heit_free  margin_free no_shade_noBorder" id="current_champ_holder">
                        Name championship
                    </div>
                </div>
                <div class="parts fifty_centered">
                    Team Manager
                </div>
                <table class="new_data_table " style="margin-top: 0px;">
                    <tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" style="width:250px;" />  </td></tr>
                    <tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" style="width:250px;" />  </td></tr>
                    <tr><td colspan="2">

                        </td></tr>
                </table>

                <table class="new_data_table"   style="margin-top: 0px;">
                    <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="parts" />  </td> 
                        <td>middle_name :</td><td> <input type="text"     name="txt_middle_name"  class="parts" />  </td>
                        <td>last_name :</td><td> <input type="text"     name="txt_last_name"  class="parts" />  </td>
                    </tr>
                    <tr>
                        <td> gender :</td><td> 
                            <select required name="txt_gender">
                                <option></option>
                                <option>Male</option>
                                <option>Female</option>
                            </select>
                        </td>
                        <td>date_of_birth :</td><td> <input type="text"   id="dob"  name="txt_date_of_birth" required class="parts" /> </td>
                        <td>nationality :</td><td> <input type="text" value="Rwandan"    name="txt_nationality" required class="parts" />  </td>
                    </tr>
                    <tr>
                        <td>telephone :</td><td> <input type="text"     name="txt_telephone" required class="parts" />  </td>
                        <td>residence :</td><td> <input type="text"     name="txt_residence" required class="parts" />  </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Team:</td>
                        <td colspan="5"> 
                            <?php get_team_combo(); ?>  </td>
                    </tr>
                </table>

                <div class="parts sixty_centered heit_free no_paddin_shade_no_Border">
                    <div class="parts no_paddin_shade_no_Border two_fifty_right heit_free">
                        <input type="submit" class="confirm_buttons" name="send_account" value="Save"/>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border " >
                    <?php
                    $obj = new multi_values();
                    $obj->list_team_manager();
                    ?>
                </div>  
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('#dob').datepicker({
                    dateFormat: 'yy-mm-dd',
                    maxDate: new Date()
                });
            });
        </script>
    </body>
</html>
<?php

function get_team_combo() {
    $obj = new multi_values();
    $obj->get_team_in_combo();
}
