<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
} include '../web_db/multi_values.php';
if (isset($_POST['send_transfer'])) {
    $transfer_request = $_POST['txt_transfer_request_id'];
    $trans_date = date("Y-m-d");
    $agreed_price = $_POST['txt_agreed_price'];
    $account = $_SESSION['userid'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_transfer($transfer_request, $trans_date, $agreed_price, $account);
}
?>
<html>
    <head>
        <title>
            transfer</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_transfer.php" method="post" enctype="multipart/form-data">

            <input type="hidden" id="txt_transfer_request_id"   name="txt_transfer_request_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/><div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts x_height_4x full_center_two_h abs_child  off heit_free" style="opacity: 1; background-color: #fff;" id="dialog_child_trans_requests">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_request();
                ?>
            </div>
            <?php
            include 'Admin_header.php';
            ?>
             <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  transfer</div>
                <table class="new_data_table">

                    <tr><td>transfer_request :</td><td> 
                            <a href="#" id="show_trans_requests" style="color: #000080;">Choose a request</a>
                        </td></tr>
                    <tr><td>agreed_price :</td><td> <input type="text"     name="txt_agreed_price" required class="textbox" />  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_transfer" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_transfer();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_transfer_request_combo() {

    $obj = new multi_values();
    $obj->get_transfer_request_in_combo();
}

function get_account_combo() {

    $obj = new multi_values();
    $obj->get_account_in_combo();
}
