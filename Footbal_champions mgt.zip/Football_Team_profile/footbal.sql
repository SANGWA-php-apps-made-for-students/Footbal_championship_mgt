-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: footbal_profile
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `account_category` varchar(60) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (8,'paul@gmail.com','123','8',NULL),(9,'Thierry@gmail.com','123','11',17),(10,'Theo@gmail.com','123','11',18),(11,'yvan@gmail.com','123','10',19),(12,'yves@gmail.com','123','11',20),(13,'Hugues','123','11',21),(14,'marcellin@gmail.com','123','9',22),(16,'theogene','123','10',25),(17,'Tino','123','11',31),(22,'Bruno','123','11',36),(23,'Bryan','123','11',37),(24,NULL,NULL,'12',42),(25,'Placide','123','12',43),(26,'aime','123','11',47),(27,'aime','123','11',48),(28,'eric','123','11',49),(29,'paul','123','11',50),(30,'pascal','123','11',51),(31,'luc','123','11',52),(32,'lionnel','123','11',53),(33,NULL,NULL,'9',67),(34,'theo','123','9',68);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (8,'admin'),(9,'Referee'),(10,'Federation'),(11,'team'),(12,'coordinator');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card`
--

DROP TABLE IF EXISTS `card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card` (
  `card_id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(60) DEFAULT NULL,
  `card_date` date DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `match` int(11) DEFAULT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card`
--

LOCK TABLES `card` WRITE;
/*!40000 ALTER TABLE `card` DISABLE KEYS */;
INSERT INTO `card` VALUES (2,'red','2017-07-13',24,229),(3,'yellow','2018-04-05',30,246),(4,'yellow','2018-05-21',25,240);
/*!40000 ALTER TABLE `card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `championship`
--

DROP TABLE IF EXISTS `championship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `championship` (
  `championship_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_started` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`championship_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `championship`
--

LOCK TABLES `championship` WRITE;
/*!40000 ALTER TABLE `championship` DISABLE KEYS */;
INSERT INTO `championship` VALUES (69,'2017-07-13',8,'Azam'),(70,'2017-07-13',8,'Azam'),(71,'2017-07-21',8,'Igikombe cyamahoro'),(72,'2018-04-05',8,'Azam');
/*!40000 ALTER TABLE `championship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `federation_mng`
--

DROP TABLE IF EXISTS `federation_mng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `federation_mng` (
  `federation_mng_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`federation_mng_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `federation_mng`
--

LOCK TABLES `federation_mng` WRITE;
/*!40000 ALTER TABLE `federation_mng` DISABLE KEYS */;
/*!40000 ALTER TABLE `federation_mng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixture`
--

DROP TABLE IF EXISTS `fixture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixture` (
  `fixture_id` int(11) NOT NULL AUTO_INCREMENT,
  `fixture_date` date DEFAULT NULL,
  `championship` int(11) DEFAULT NULL,
  `TeamA` int(11) DEFAULT NULL,
  `TeamB` int(11) DEFAULT NULL,
  `position` varchar(60) DEFAULT NULL,
  `date_to_play` date DEFAULT NULL,
  `teamA_name` varchar(45) DEFAULT NULL,
  `teamB_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`fixture_id`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixture`
--

LOCK TABLES `fixture` WRITE;
/*!40000 ALTER TABLE `fixture` DISABLE KEYS */;
INSERT INTO `fixture` VALUES (224,'2017-07-13',70,30,31,'0','2017-07-31','APR FC','RAYON SPORT FC'),(225,'2017-07-13',70,31,30,'0','2017-07-31','RAYON SPORT FC','APR FC'),(226,'2017-07-13',70,32,33,'0','2017-07-31','KIYOVU SPORT','AMAGAJU FC'),(227,'2017-07-13',70,33,32,'0','2017-07-31','AMAGAJU FC','KIYOVU SPORT'),(228,'2017-07-13',70,34,35,'0','2017-07-31','ESPOIR FC','POLICE FC'),(229,'2017-07-13',70,35,34,'0','2017-07-31','POLICE FC','ESPOIR FC'),(230,'2017-07-13',70,36,37,'0','2017-07-31','ETENCELLE FC','MARINE FC'),(231,'2017-07-13',70,37,36,'0','2017-07-31','MARINE FC','ETENCELLE FC'),(232,'2017-07-13',70,38,39,'0','2017-07-31','PEPINIERE','MUSANZE'),(233,'2017-07-13',70,39,38,'0','2017-07-31','MUSANZE','PEPINIERE'),(234,'2017-07-21',71,30,31,'0','2018-04-20','APR FC','RAYON SPORT FC'),(235,'2017-07-21',71,31,30,'0','2018-04-20','RAYON SPORT FC','APR FC'),(236,'2017-07-21',71,32,33,'0','2018-04-20','KIYOVU SPORT','AMAGAJU FC'),(237,'2017-07-21',71,33,32,'0','2018-04-20','AMAGAJU FC','KIYOVU SPORT'),(238,'2017-07-21',71,34,35,'0','2018-04-20','ESPOIR FC','POLICE FC'),(239,'2017-07-21',71,35,34,'0','2018-04-20','POLICE FC','ESPOIR FC'),(240,'2017-07-21',71,36,37,'0','2018-04-20','ETENCELLE FC','MARINE FC'),(241,'2017-07-21',71,37,36,'0','2018-04-20','MARINE FC','ETENCELLE FC'),(242,'2017-07-21',71,38,39,'0','2018-04-20','PEPINIERE','MUSANZE'),(243,'2017-07-21',71,39,38,'0','2018-04-20','MUSANZE','PEPINIERE'),(244,'2018-04-05',72,30,31,'0',NULL,'APR FC','RAYON SPORT FC'),(245,'2018-04-05',72,31,30,'0',NULL,'RAYON SPORT FC','APR FC'),(246,'2018-04-05',72,32,33,'0',NULL,'KIYOVU SPORT','AMAGAJU FC'),(247,'2018-04-05',72,33,32,'0',NULL,'AMAGAJU FC','KIYOVU SPORT'),(248,'2018-04-05',72,34,35,'0',NULL,'ESPOIR FC','POLICE FC'),(249,'2018-04-05',72,35,34,'0',NULL,'POLICE FC','ESPOIR FC'),(250,'2018-04-05',72,36,37,'0',NULL,'ETENCELLE FC','MARINE FC'),(251,'2018-04-05',72,37,36,'0',NULL,'MARINE FC','ETENCELLE FC'),(252,'2018-04-05',72,38,39,'0',NULL,'PEPINIERE','MUSANZE'),(253,'2018-04-05',72,39,38,'0',NULL,'MUSANZE','PEPINIERE');
/*!40000 ALTER TABLE `fixture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goal`
--

DROP TABLE IF EXISTS `goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goal` (
  `goal_id` int(11) NOT NULL AUTO_INCREMENT,
  `goal_date` date DEFAULT NULL,
  `matches` int(11) DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `winner` int(11) DEFAULT NULL,
  `pointsA` int(11) DEFAULT NULL,
  `pointB` int(11) DEFAULT NULL,
  PRIMARY KEY (`goal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goal`
--

LOCK TABLES `goal` WRITE;
/*!40000 ALTER TABLE `goal` DISABLE KEYS */;
INSERT INTO `goal` VALUES (3,'2017-07-13',228,22,31,0,3),(4,'2017-07-13',227,22,30,0,3),(5,'2018-04-05',238,22,31,0,3);
/*!40000 ALTER TABLE `goal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match`
--

DROP TABLE IF EXISTS `match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `match` (
  `match_id` int(11) NOT NULL AUTO_INCREMENT,
  `match_date` date DEFAULT NULL,
  `teamA` int(11) DEFAULT NULL,
  `teamB` int(11) DEFAULT NULL,
  `championship` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `stadium` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`match_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match`
--

LOCK TABLES `match` WRITE;
/*!40000 ALTER TABLE `match` DISABLE KEYS */;
/*!40000 ALTER TABLE `match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `match_participant`
--

DROP TABLE IF EXISTS `match_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `match_participant` (
  `match_participant_id` int(11) NOT NULL AUTO_INCREMENT,
  `match_participantdeleted` varchar(60) DEFAULT NULL,
  `match` int(11) DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `allowed` varchar(60) DEFAULT NULL,
  `substitute` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`match_participant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=661 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `match_participant`
--

LOCK TABLES `match_participant` WRITE;
/*!40000 ALTER TABLE `match_participant` DISABLE KEYS */;
INSERT INTO `match_participant` VALUES (635,'no',0,21,'no','no'),(636,'no',0,22,'no','no'),(637,'no',0,23,'no','no'),(638,'no',0,24,'no','no'),(639,'no',0,25,'no','no'),(640,'no',0,26,'no','no'),(641,'no',0,32,'no','no'),(642,'no',0,33,'no','no'),(643,'no',0,27,'no','no'),(644,'no',0,28,'no','no'),(645,'no',0,29,'no','no'),(646,'no',0,30,'no','no'),(647,'no',0,31,'no','no'),(648,'no',0,21,'no','no'),(649,'no',0,22,'no','no'),(650,'no',0,23,'no','no'),(651,'no',0,24,'no','no'),(652,'no',0,25,'no','no'),(653,'no',0,26,'no','no'),(654,'no',0,32,'no','no'),(655,'no',0,33,'no','no'),(656,'no',0,27,'no','no'),(657,'no',0,28,'no','no'),(658,'no',0,29,'no','no'),(659,'no',0,30,'no','no'),(660,'no',0,31,'no','no');
/*!40000 ALTER TABLE `match_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matches`
--

DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matches` (
  `matches_id` int(11) NOT NULL AUTO_INCREMENT,
  `match_date` datetime DEFAULT NULL,
  `teamA` int(11) DEFAULT NULL,
  `teamB` int(11) DEFAULT NULL,
  `championship` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `teamA_name` varchar(45) DEFAULT NULL,
  `teamB_name` varchar(45) DEFAULT NULL,
  `stadium` varchar(45) DEFAULT NULL,
  `confirmed` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`matches_id`)
) ENGINE=InnoDB AUTO_INCREMENT=257 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matches`
--

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
INSERT INTO `matches` VALUES (237,'2017-08-08 08:45:00',30,31,71,8,'APR FC','RAYON SPORT FC','Amahoro',NULL),(238,'2018-04-06 15:30:00',31,30,71,8,'RAYON SPORT FC','APR FC','Amahoro',NULL),(239,'2018-04-20 18:00:00',32,33,71,8,'KIYOVU SPORT','AMAGAJU FC','Amahoro',NULL),(240,NULL,33,32,71,8,'AMAGAJU FC','KIYOVU SPORT',NULL,NULL),(241,NULL,34,35,71,8,'ESPOIR FC','POLICE FC',NULL,'yes'),(242,NULL,35,34,71,8,'POLICE FC','ESPOIR FC',NULL,NULL),(243,NULL,36,37,71,8,'ETENCELLE FC','MARINE FC',NULL,NULL),(244,NULL,37,36,71,8,'MARINE FC','ETENCELLE FC',NULL,NULL),(245,NULL,38,39,71,8,'PEPINIERE','MUSANZE',NULL,'yes'),(246,NULL,39,38,71,8,'MUSANZE','PEPINIERE',NULL,NULL),(247,NULL,30,31,72,8,'APR FC','RAYON SPORT FC',NULL,NULL),(248,NULL,31,30,72,8,'RAYON SPORT FC','APR FC',NULL,NULL),(249,NULL,32,33,72,8,'KIYOVU SPORT','AMAGAJU FC',NULL,NULL),(250,NULL,33,32,72,8,'AMAGAJU FC','KIYOVU SPORT',NULL,NULL),(251,NULL,34,35,72,8,'ESPOIR FC','POLICE FC',NULL,NULL),(252,NULL,35,34,72,8,'POLICE FC','ESPOIR FC',NULL,NULL),(253,NULL,36,37,72,8,'ETENCELLE FC','MARINE FC',NULL,NULL),(254,NULL,37,36,72,8,'MARINE FC','ETENCELLE FC',NULL,NULL),(255,NULL,38,39,72,8,'PEPINIERE','MUSANZE',NULL,NULL),(256,NULL,39,38,72,8,'MUSANZE','PEPINIERE',NULL,'yes');
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `penalty`
--

DROP TABLE IF EXISTS `penalty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `penalty` (
  `penalty_id` int(11) NOT NULL AUTO_INCREMENT,
  `penalty_date` date DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `match` int(11) DEFAULT NULL,
  `scored` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`penalty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penalty`
--

LOCK TABLES `penalty` WRITE;
/*!40000 ALTER TABLE `penalty` DISABLE KEYS */;
/*!40000 ALTER TABLE `penalty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player` (
  `player_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary` int(11) DEFAULT NULL,
  `position` varchar(60) DEFAULT NULL,
  `team` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (21,600000,'Goal keeper',30,8,54),(22,700000,'Defenders',31,8,55),(23,700000,'Midfielder',32,8,56),(24,700000,'Midfielder',33,8,57),(25,700000,'Forwaders',34,8,58),(26,700000,'Midfielder',35,8,59),(27,700000,'Midfielder',36,8,60),(28,700000,'Defenders',37,8,61),(29,700000,'Midfielder',38,8,62),(30,700000,'Forwaders',39,8,63),(31,700000,'Defenders',39,32,64),(32,600000,'Defenders',35,32,65),(33,700000,'Forwaders',35,32,66);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `middle_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nationality` varchar(60) DEFAULT NULL,
  `date_registered` date DEFAULT NULL,
  `telephone` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (8,'Jean ','Pierre','HABIMFURA',NULL,'1988-09-25','Rwandan','2017-06-23','0788578578','Kicukiro'),(9,'Jean','marie','RUKUNDO','Male','1989-03-20','Rwandan','2017-06-23','0788576747','Gikondo'),(10,'Jean ','Marie','RUKUNDO','Male','2017-04-23','Rwandan','2017-06-23','0788576747','Gikondo'),(11,'Jean','Marie','RUKUNDO','Male','2014-04-23','Rwandan','2017-06-23','0788576747','Gikondo'),(12,'Thierry','none','HABIMANA','Male','2015-04-21','Rwandan','2017-06-23','0788576745','Gikondo'),(13,'Claude','none','SEMANA','Male','2014-03-23','Rwandan','2017-06-23','0788576745','Gikondo'),(14,'Paul','none','Jean','Male','2014-04-21','Rwandan','2017-06-23','0788576745','Rwamagana'),(15,'NTIMUGURA','none','Fabrice','Male','2006-04-20','Rwandan','2017-06-23','07227565746','Nyamirambo'),(16,'Thierry','none','HABIYAREMYE','Male','2014-03-26','Rwandan',NULL,'078475757','Nyamirambo'),(17,'Thierry','none','HABIYAREMYE','Male','1999-03-26','Rwandan','2017-06-29','078475757','Nyamirambo'),(18,'Theoneste','none','HABIMANA','Male','1988-03-26','Rwandan','2017-06-29','078444757','KIMISAGARA'),(19,'Yvan','none','BAUDRY','Male','2015-06-27','Rwandan','2017-06-29','07889686868','KIMIRONKO'),(20,'Yves','none','AHISHAKIYE','Male','2014-03-26','Rwandan','2017-06-29','078444757','KIMIRONKO'),(21,'Hugues','none','KAYIHURA','Male','2014-04-29','Rwandan','2017-06-29','07224958686','Nyamirambo'),(22,'marcellin','none','NGABO','Male','2013-03-26','Rwandan','2017-06-29','0722756838','GATSATA'),(23,'Gasigwa','none','Filbert','Male','2017-07-08','Rwandan','2017-07-08','078857663','Nyamirambo'),(24,'Theogene','','NSABIMANA','Male','2017-07-05','Rwandan','2017-07-09','078847566','Nyamrambo'),(25,'Theogene','','NSABIMANA','Male','2017-07-05','Rwandan','2017-07-09','078847566','Nyamrambo'),(26,'John','','UJENEZA','Male','2015-07-06','Rwandan','2017-07-09','078847566','Nyamrambo'),(27,'Jean','Pierre','BAZINDE','Male','2017-07-09','Rwandan','2017-07-09','078847566','KIMISAGARA'),(28,'Pascience','','MUNYANSHOZA','Male','2017-07-12','Rwandan','2017-07-09','0788545090','KIMISAGARA'),(29,'Pascience','','MUNYANSHOZA','Male','2017-07-12','Rwandan','2017-07-09','0788545090','KIMISAGARA'),(30,'Pascience','','MUNYANSHOZA','Male','2017-07-12','Rwandan','2017-07-09','0788545090','KIMISAGARA'),(35,'TINO','','KWIZERA','Male','2017-07-10','Rwandan','2017-07-11','0722395632','KMISAGARA'),(36,'bruno','','KAREKEZI','Male','2017-07-05','Rwandan','2017-07-11','0722395632','KMISAGARA'),(37,'Bryan','','SERUBUGA','Male','2017-07-10','Rwandan','2017-07-11','0722395632','nyarutarama'),(38,'Claver','','SEMANA','Male','2015-05-09','Rwandan','2017-07-11','0788495948','KIMISAGARA'),(39,'Hubert','','KAREMERA','Male','2014-06-09','Rwandan','2017-07-11','0722395632','Narutarama'),(40,'Dieu Donne','','KWIZERA','Male','2015-06-09','Rwandan','2017-07-11','0722345632','KISIMENTI'),(41,'asdf','','asdf','Male','2015-05-09','Rwandan','2017-07-11','0722345632','KIMISAGARA'),(42,'Joyce','','BLISS','Male','2015-05-09','Rwandan','2017-07-11','07889475456','RUSIZI'),(43,'Placide','','KALISA','Male','2014-04-08','Rwandan','2017-07-11','0722345632','KIMISAGARA'),(44,'asdlfk','laskdhf','askldf','Male','2017-07-12','Rwandan','2017-07-12','asdf','asdf'),(45,'asklfj;','alskjdf','laskjd','Male','2017-07-12','Rwandan','2017-07-12','0788875756','kimisagara'),(46,'asklf','askldfh','askld','Male','2017-07-12','Rwandan','2017-07-12','0788834756','Nyrugenge'),(47,'Aime','','RUKUNDO','Male','2017-07-03','Rwandan','2017-07-13','0788834756','kimisagara'),(48,'Aime','','RUKUNDO','Male','2017-07-03','Rwandan','2017-07-13','0788834756','kimisagara'),(49,'eric','','NSENGIMANA','Male','2017-07-11','Rwandan','2017-07-13','0788834756','RWAMAGANA'),(50,'paul','Jean','Claude','Male','2017-06-11','Rwandan','2017-07-13','0788834756','RWAMAGANA'),(51,'pascal','','UWINEZA','Male','2017-06-11','Rwandan','2017-07-13','072234756','REMERA'),(52,'Luc','','KAREKEZI','Male','2017-04-10','Rwandan','2017-07-13','072234336','GIKONDO'),(53,'Lionnel','','KARENZI','Male','2017-05-08','Rwandan','2017-07-13','072254336','KABEZA'),(54,'Olivier','','RUKUNDO','Male','2017-07-13','Rwandan','2017-07-13','072234336','GIKONDO'),(55,'Savior','','NSHUTI','Male','2017-07-13','Rwandan','2017-07-13','072234336','GIKONDO'),(56,' Deo  ','','AMANI','Male','2017-07-13','Rwandan','2017-07-13','0788834756','GIKONDO'),(57,'Jean','','GATETE','Male','2017-07-13','Rwandan','2017-07-13','072234336','RWAMAGANA'),(58,'Claude','','KAMANZI','Male','2017-07-13','Rwandan','2017-07-13','072234336','KABEZA'),(59,'Placide','','TUYI','Male','2017-07-13','Rwandan','2017-07-13','072234756','kimisagara'),(60,'Thierry','','BAKAREKE','Male','2017-07-13','Rwandan','2017-07-13','0788834756','REMERA'),(61,'Vianney','Jean','SEMANA','Male','2017-07-13','Rwandan','2017-07-13','0788875756','Nyarugenge'),(62,'Paulain','','INEZA','Male','2017-07-13','Rwandan','2017-07-13','072234756','kimisagara'),(63,'obed','','NKURUNZIZA','Male','2017-07-13','Rwandan','2017-07-13','072234756','REMERA'),(64,' Deo  ','ss','dd','Male','2017-07-13','Rwandan','2017-07-13','072234756','GIKONDO'),(65,'sdfasf','asdfas','asdf','Female','2017-07-13','Rwandan','2017-07-13','072234336','GIKONDO'),(66,'Yves','gg','Bucyana','Male','2017-07-13','Rwandan','2017-07-13','072254336','GIKONDO'),(67,'Theo','','RWIGARA','Male','2017-07-13','Rwandan','2017-07-13','072234336','GIKONDO'),(68,'Theo','','RWIGARA','Male','2017-07-13','Rwandan','2017-07-13','072234336','KABEZA');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referee`
--

DROP TABLE IF EXISTS `referee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referee` (
  `referee_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`referee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referee`
--

LOCK TABLES `referee` WRITE;
/*!40000 ALTER TABLE `referee` DISABLE KEYS */;
/*!40000 ALTER TABLE `referee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedal`
--

DROP TABLE IF EXISTS `schedal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedal` (
  `schedual` int(11) NOT NULL AUTO_INCREMENT,
  `sche_date` date DEFAULT NULL,
  `teamA` int(11) DEFAULT NULL,
  `teamB` int(11) DEFAULT NULL,
  `championship` int(11) DEFAULT NULL,
  `account` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`schedual`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedal`
--

LOCK TABLES `schedal` WRITE;
/*!40000 ALTER TABLE `schedal` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_date` date DEFAULT NULL,
  `teamA` varchar(60) DEFAULT NULL,
  `teamB` varchar(60) DEFAULT NULL,
  `championship` int(11) DEFAULT NULL,
  `home_team` varchar(45) DEFAULT NULL,
  `away_team` varchar(45) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (224,NULL,'30','31',70,'APR FC','RAYON SPORT FC',NULL),(225,NULL,'31','30',70,'RAYON SPORT FC','APR FC',NULL),(226,NULL,'32','33',70,'KIYOVU SPORT','AMAGAJU FC',NULL),(227,NULL,'33','32',70,'AMAGAJU FC','KIYOVU SPORT',NULL),(228,NULL,'34','35',70,'ESPOIR FC','POLICE FC',NULL),(229,NULL,'35','34',70,'POLICE FC','ESPOIR FC',NULL),(230,NULL,'36','37',70,'ETENCELLE FC','MARINE FC',NULL),(231,NULL,'37','36',70,'MARINE FC','ETENCELLE FC',NULL),(232,NULL,'38','39',70,'PEPINIERE','MUSANZE',NULL),(233,NULL,'39','38',70,'MUSANZE','PEPINIERE',NULL),(234,NULL,'30','31',71,'APR FC','RAYON SPORT FC',NULL),(235,NULL,'31','30',71,'RAYON SPORT FC','APR FC',NULL),(236,NULL,'32','33',71,'KIYOVU SPORT','AMAGAJU FC',NULL),(237,NULL,'33','32',71,'AMAGAJU FC','KIYOVU SPORT',NULL),(238,NULL,'34','35',71,'ESPOIR FC','POLICE FC',NULL),(239,NULL,'35','34',71,'POLICE FC','ESPOIR FC',NULL),(240,NULL,'36','37',71,'ETENCELLE FC','MARINE FC',NULL),(241,NULL,'37','36',71,'MARINE FC','ETENCELLE FC',NULL),(242,NULL,'38','39',71,'PEPINIERE','MUSANZE',NULL),(243,NULL,'39','38',71,'MUSANZE','PEPINIERE',NULL),(244,NULL,'30','31',72,'APR FC','RAYON SPORT FC',NULL),(245,NULL,'31','30',72,'RAYON SPORT FC','APR FC',NULL),(246,NULL,'32','33',72,'KIYOVU SPORT','AMAGAJU FC',NULL),(247,NULL,'33','32',72,'AMAGAJU FC','KIYOVU SPORT',NULL),(248,NULL,'34','35',72,'ESPOIR FC','POLICE FC',NULL),(249,NULL,'35','34',72,'POLICE FC','ESPOIR FC',NULL),(250,NULL,'36','37',72,'ETENCELLE FC','MARINE FC',NULL),(251,NULL,'37','36',72,'MARINE FC','ETENCELLE FC',NULL),(252,NULL,'38','39',72,'PEPINIERE','MUSANZE',NULL),(253,NULL,'39','38',72,'MUSANZE','PEPINIERE',NULL);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `substitution`
--

DROP TABLE IF EXISTS `substitution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `substitution` (
  `substitution_id` int(11) NOT NULL AUTO_INCREMENT,
  `substitution_date` date DEFAULT NULL,
  `to_replace` int(11) DEFAULT NULL,
  `replacing` int(11) DEFAULT NULL,
  `match` int(11) DEFAULT NULL,
  PRIMARY KEY (`substitution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `substitution`
--

LOCK TABLES `substitution` WRITE;
/*!40000 ALTER TABLE `substitution` DISABLE KEYS */;
/*!40000 ALTER TABLE `substitution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(60) DEFAULT NULL,
  `team_date` date DEFAULT NULL,
  `manager` int(11) DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (30,'APR FC','2017-07-13',8),(31,'RAYON SPORT FC','2017-07-13',8),(32,'KIYOVU SPORT','2017-07-13',8),(33,'AMAGAJU FC','2017-07-13',8),(34,'ESPOIR FC','2017-07-13',8),(35,'POLICE FC','2017-07-13',8),(36,'ETENCELLE FC','2017-07-13',8),(37,'MARINE FC','2017-07-13',8),(38,'PEPINIERE','2017-07-13',8),(39,'MUSANZE','2017-07-13',8),(40,'TEAM','2018-04-05',8),(41,'AZAM','2018-04-05',8);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_manager`
--

DROP TABLE IF EXISTS `team_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_manager` (
  `team_manager_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_managerdeleted` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `team` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`team_manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_manager`
--

LOCK TABLES `team_manager` WRITE;
/*!40000 ALTER TABLE `team_manager` DISABLE KEYS */;
INSERT INTO `team_manager` VALUES (16,'no',27,30,8),(17,'no',28,31,8),(18,'no',29,32,8),(19,'no',30,33,8),(20,'no',31,34,8),(21,'no',32,35,8);
/*!40000 ALTER TABLE `team_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trans_request`
--

DROP TABLE IF EXISTS `trans_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trans_request` (
  `trans_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_date` date DEFAULT NULL,
  `teamA` int(11) DEFAULT NULL,
  `teamB` int(11) DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `teamA_name` varchar(40) DEFAULT NULL,
  `teamB_name` varchar(40) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `proposed_price` int(11) DEFAULT NULL,
  PRIMARY KEY (`trans_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trans_request`
--

LOCK TABLES `trans_request` WRITE;
/*!40000 ALTER TABLE `trans_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `trans_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfer`
--

DROP TABLE IF EXISTS `transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfer` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_request` int(11) DEFAULT NULL,
  `trans_date` date DEFAULT NULL,
  `agreed_price` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfer`
--

LOCK TABLES `transfer` WRITE;
/*!40000 ALTER TABLE `transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'footbal_profile'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-21 15:37:15
