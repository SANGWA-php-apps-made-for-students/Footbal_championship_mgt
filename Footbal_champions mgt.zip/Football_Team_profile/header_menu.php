<div class="parts menu full_center_two_h heit_free margin_free no_shade_noBorder reverse_border skin">
    <a href="index.php">Home</a>
    <a href="Admin/new_account_category.php">About</a>
    <a href="Admin/new_card.php">Contact us</a>
      <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border whilte_text" >
          <a href="login.php">Login</a>
                </div>
</div>