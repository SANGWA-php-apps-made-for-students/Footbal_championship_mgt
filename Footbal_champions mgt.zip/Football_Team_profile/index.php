<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            td{
                padding: 5px;   
            }
            thead{
                background-color: #19454f;
                color: #fff;
            }
            #fixture_table{
                border: 1px solid #1c3d6a;
                border-collapse: collapse;
            }
            #fixture_table td{
                padding: 7px;
            }
            #fixture_table tr{
                border-bottom: 1px solid #1c3d6a;
            }
            #fixture_box{

            }
            #home_login, #home_login_ad_box, #fixture_box{
                color: #0a182c;
                min-height: 400px;
            }
        </style>
    </head>
    <body id="login_pic">
        <form action="index.php" method="post">
            <div class="parts  eighty_centered no_paddin_shade_no_Border reverse_border" id="home_bg">
                <div class="parts full_center_two_h margin_free heit_free no_shade_noBorder whilte_text skin" id="my_title">
                    <div class="parts no_paddin_shade_no_Border box "style=" background-size: 40%;  background-repeat: no-repeat;background-image: url('web_images/logo2.png');">
                    </div>
                </div>
                <?php
                    include 'header_menu.php';
                ?>
                <div class="parts full_center_two_h margin_free no_paddin_shade_no_Border heit_free" style="height:30px; color: #c8ff00; font-size: 18px; padding: 3px;  background-color: #84b9cb; border-bottom:  2px solid #fff;"  >
                    <marquee>
                        FERWAFA CHAMPIONSHIP 
                        &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                        &nbsp; &nbsp;&nbsp; &nbsp;
                        GET LIVE MATCHES 
                        &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                        &nbsp; &nbsp;&nbsp; &nbsp;
                        LIVE SCORES 
                        &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; 
                        &nbsp; &nbsp;&nbsp; &nbsp;
                        LIVE STANDING
                    </marquee>
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free" style="color: #fff;">
                    <div class="parts thirty_Per_cent_two_h no_shade_noBorder skin3 " id="fixture_box" style="width: 500px; min-height: 400px">
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border x_titles">
                            Fixtures
                        </div>
                        <?php
                            $obj = new more_db_op();
                            $obj->list_fixture();
                        ?>
                    </div>

                    <div class="parts two_fifty_right no_shade_noBorder" id="home_login">
                        <span id="display" style="color: #fff; font-size: 20px;">

                        </span>
                    </div>
                    <div class="parts  no_shade_noBorder skin3 " id="fixture_box" style="width: 500px; min-height: 400px">
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border x_titles">
                            Goals
                        </div>
                        <?php
                            $obj = new more_db_op();
                            $obj->more_matches();
                        ?>
                    </div>
                </div>
                <div class="parts full_center_two_h no_shade_noBorder margin_free skin whilte_text heit_free"> Copyrights <?php echo date("Y") ?></div>
            </div>  
        </form>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>
<?php

    function login() {
        if (isset($_POST['send'])) {
            $obj = new more_db_op();
            $username = $_POST['username'];
            $password = $_POST['password'];
            $cat = $obj->get_user_category($username, $password);
            if (isset($cat)) {
                $_SESSION['names'] = $obj->get_name_logged_in($username, $password);
                $_SESSION['userid'] = $obj->get_id_logged_in($username, $password);
                $_SESSION['cat'] = $obj->get_user_category($username, $password);
                $_SESSION['login_token'] = $_SESSION['userid'];
                if ($cat == 'admin') {//he is sector
                    header('location: Admin/Admin_dashboard.php');
                } else if ($cat == 'team') {// he is district
                    header('location: team_manager/team_manager_dashboard.php');
                } else if ($cat == 'Federation') {// he is minagri
                    header('location: federation_mngr/federation_mngr.php');
                } else if ($cat == 'admin') {// he is amdinistrator
                    header('location: AdminDash/index.php');
                } else if ($cat == 'Referee') {
                    header('location: referee/referee_dashboard.php');
                }
            } else {
                echo '<div class="red_message">Username or password invalid</div>';
            }
        }
    }

    class more_db_op {

        function more_matches() {
            require_once 'Admin/dbConnection.php';
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select matches.matches_id,  matches.match_date,  matches.teamA_name,  matches.teamB_name,  matches.stadium
             from matches
             join goal on goal.matches = matches.matches_id 
             join player on goal.player = player.player_id 
             join championship on matches.championship = championship.championship_id 
             join account on matches.account = account.account_id where matches.confirmed='yes'";
            ?>
            <table class="new_data_table" style="margin-top: 0px;" id="fixture_table">
                <thead><tr><td> match_id </td><td> match_date </td><td> teamA_name </td><td> teamB_name </td><td> stadium </td>
                    </tr></thead>

                <?php foreach ($db->query($sql) as $row) { ?><tr> 
                        <td>        <?php echo $row['matches_id']; ?> </td>
                        <td>        <?php echo $row['match_date']; ?> </td>
                        <td>        <?php echo $row['teamA_name']; ?> </td>
                        <td>        <?php echo $row['teamB_name']; ?> </td>
                        <td>        <?php echo $row['stadium']; ?> </td>

                    </tr>
                <?php } ?></table>
            <?php
        }

        function list_fixture() {
            require_once 'Admin/dbConnection.php';
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "select * from fixture";
            ?>
            <table class="fixture_table " id="fixture_table">
                <thead><tr>
                        <td> championship </td>
                        <td> TeamA </td>
                        <td> TeamB </td>
                        <td> date_to_play </td>
                    </tr></thead>
                <?php foreach ($db->query($sql) as $row) { ?><tr> 
                        <td>
                            <?php echo $row['championship']; ?>
                        </td>
                        <td>
                            <?php echo $row['teamA_name']; ?>
                        </td>
                        <td>
                            <?php echo $row['teamB_name']; ?>
                        </td>
                        <td>
                            <?php echo $row['date_to_play']; ?>
                        </td>

                    </tr>
                <?php } ?></table>
            <?php
        }

        function get_user_category($username, $password) {
            require_once 'Admin/dbConnection.php';
            $con = new my_connection();
            $cat = '';
            $sql = "select     account_category.name from  account join account_category on account_category.account_category_id=account.account_category where  account.username=:username and  account.password =:password";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'];
            return $cat;
        }

        function get_name_logged_in($username, $password) {
            require_once 'Admin/dbConnection.php';
            $con = new my_connection();
            $cat = '';
            $sql = "select   profile.name from profile join account on account.profile=profile.profile_id where   account.username=:username and   account.password=:password";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'];
            return $cat;
        }

        function get_userid_by_Acc_cat($name) {
            $userid = 0;
            require_once '../Admin/dbConnection.php';
            $con = new my_connection();
            $sql = "select    account.account_id from  account join account_category on account_category.account_category_id=account.account_category where   name = :name";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->bindValue(':name', $name);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        }

        function get_id_logged_in($username, $password) {
            $userid = 0;
            require_once 'Admin/dbConnection.php';
            $con = new my_connection();
            $sql = "select    account.account_id from account where  account.username=:username and  account.password =:password";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        }

        function get_overall_fixtures() {
            require_once 'Admin/dbConnection.php';
            $database = new my_connection();
            $db = $database->getCon();
            $sql = "  select * from matches";
            ?>
            <table class="new_data_table" id="fixture_table" style="margin-top: 0px;">
                <thead style="background-color: #1c3d6a; ">
                <td class="cells"> Team A </td>
                <td class="cells"> &nbsp;  &nbsp;  </td>
                <td class="cells"> Team B </td>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?>
                <tr> 
                    <td class="cells">              <?php echo $row['teamA_name']; ?> </td>
                    <td class="cells">        Vs        </td>
                    <td class="cells">          <?php echo $row['teamB_name']; ?> </td>

                </tr>
            <?php } ?></table>
            <?php
        }

    }
    