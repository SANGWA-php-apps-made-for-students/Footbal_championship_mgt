<div class="parts menu full_center_two_h heit_free margin_free no_shade_noBorder reverse_border skin">

    <div class="parts allow_drop1 no_shade_noBorder"> 
        <a href="#">Championships</a>
        <div class="parts hovable_item1"> 
            <a href="new_licenses_check.php">Licenses</a>
            <a href="new_match_participant.php">Confirm participants</a>
        </div>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
      
        <a href="Admin_dashboard.php">  <?php echo 'Welcome ' .  ($_SESSION['cat']=='Referee') ? 'Welcome COMMISSIONER':''; ?></a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">Home</a>
    </div>

</div>