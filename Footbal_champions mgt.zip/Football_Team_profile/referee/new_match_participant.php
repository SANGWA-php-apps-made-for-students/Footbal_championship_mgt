<?php
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_match_participant'])) {

    $match_participantdeleted = 'no';
    $match = $_POST['txt_match_id'];
    $player = $_POST['txt_player_id'];
    $allowed = $_POST['txt_allowed'];
    $substitute = $_POST['txt_substitute'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_match_participant($match_participantdeleted, $match, $player, $allowed, $substitute);
}
?>

<html>
    <head>
        <title>
            match_participant</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_match_participant.php" method="post" enctype="multipart/form-data">
            <div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off heit_free" style="opacity: 1;" id="dialog_child_mathces">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_mathes_for_goal();
                ?>
            </div>
            <div class="parts x_height_4x eighty_centered abs_child left_off_seventy off" style="opacity: 1;" id="dialog_child">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_players();
                ?>
            </div>

            <input type="hidden" id="txt_match_id"   name="txt_match_id"/><input type="hidden" id="txt_player_id"   name="txt_player_id"/>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border"> 
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div><div class="parts eighty_centered off saved_dialog">
                match_participant saved successfully!</div>
            <div class="parts eighty_centered new_data_box ">
                <div class="parts eighty_centered ">  match_participant</div>
                <table class="new_data_table">

                    <tr><td>match :</td><td>   <a href="#" id="show_match" style="color: #000080;">Choose a match</a> </td></tr> 
                    <tr><td>player :</td><td>     <a href="#" id="show_player" style="color: #000080;">Choose a player</a> </td></tr>
                    <tr><td>allowed :</td><td> 
                            <select style="width: 200px" name="txt_allowed">
                                <option>Yes</option>
                                <option>No</option>
                            </select> </td></tr>  </td></tr>
                    <tr><td>substitute :</td><td>

                            <select style="width: 200px" name="txt_substitute">
                                <option>Yes</option>
                                <option>No</option>
                            </select> </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="button" name="send_match_participant" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <?php
                $obj = new multi_values();
                $obj->list_match_participant();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_match_combo() {
    $obj = new multi_values();
    $obj->get_match_in_combo();
}

function get_player_combo() {
    $obj = new multi_values();
    $obj->get_player_in_combo();
}
