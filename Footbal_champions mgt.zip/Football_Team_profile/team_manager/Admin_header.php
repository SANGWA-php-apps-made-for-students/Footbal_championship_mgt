<div class="parts menu full_center_two_h heit_free margin_free no_shade_noBorder reverse_border skin">
    <div class="parts allow_drop1 no_shade_noBorder"> 
        <a href="#">Championships</a>
        <div class="parts hovable_item1"> 
            <a href="new_team.php">My team</a>
            <a href="new_player.php">Player</a>
            <!--<a href="new_trans_request.php">Transfer request</a>-->
        </div>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="Admin_dashboard.php">  <?php echo 'Welcome ' . $_SESSION['cat']; ?></a>
        <a href="../logout.php">Logout</a>
    </div>
    <div class="parts two_fifty_right heit_free margin_free no_shade_noBorder whilte_text">
        <a href="team_manager_dashboard.php">Home</a>
    </div>
 
</div>





