<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
require_once '../web_db/multi_values.php';
$objm = new multi_values();
$team_name = $_SESSION['my_team'];
$t_id = $objm->get_team_id_by_team_name($team_name);
if (isset($_POST['send_player'])) {
    $name = $_POST['txt_name'];
    $middle_name = $_POST['txt_middle_name'];
    $last_name = $_POST['txt_last_name'];
    $gender = $_POST['txt_gender'];
    $date_of_birth = $_POST['txt_date_of_birth'];
    $nationality = $_POST['txt_nationality'];
    $date_registered = date("Y-m-d");
    $telephone = $_POST['txt_telephone'];
    $residence = $_POST['txt_residence'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence);

    $obj_mul = new multi_values();
    $last_profile = $obj_mul->get_last_profile();

    $salary = $_POST['txt_salary'];
    $position = $_POST['txt_position'];
    $team = $_POST['txt_team_id'];
    $account = $_SESSION['userid'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_player($salary, $position, $t_id, $account, $last_profile);
}
?>
<html>
    <head>
        <title>
            player</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_player.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_team_id"   name="txt_team_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>


            <div class=" parts abs_full accept_abs off"  id="dialog_students">

            </div>
            <div class="parts abs_child   heit_free left_off_seventy off " style="background-color: #529bac; padding-bottom: 50px;  " id="box_get_profile_by_id">

            </div>
            <?php
            include 'Admin_header.php';
            ?>
            <div class="parts eighty_centered">
                player saved successfully!</div>

            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  player</div>
                <div class="parts eighty_centered no_paddin_shade_no_Border">
                    <table class="new_data_table" style="margin-top: 5px;">
                        <tr><td colspan="2"><center> PERSONAL DETAILS </center></td></tr>
                        <tr><td colspan="2" >
                                <table class="new_data_table"   style="margin-top: 0px;">
                                    <tr ><td>name :</td><td> <input type="text"     name="txt_name" required class="parts" />  </td> 
                                        <td>middle_name :</td><td> <input type="text"     name="txt_middle_name"  class="parts" />  </td>
                                        <td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="parts" />  </td>
                                    </tr>
                                    <tr>
                                        <td> gender :</td><td> 

                                            <select name="txt_gender">
                                                <option></option>
                                                <option>Male</option>
                                                <option>Female</option>
                                            </select>
                                        </td>
                                        <td>date_of_birth :</td><td> <input type="date"     name="txt_date_of_birth" required class="parts" /> </td>
                                        <td>nationality :</td><td> <input type="text" value="Rwandan"    name="txt_nationality" required class="parts" />  </td>
                                    </tr>
                                    <tr>
                                        <td>telephone :</td><td> <input type="text"     name="txt_telephone" required class="parts" />  </td>
                                        <td>residence :</td><td> <input type="text"     name="txt_residence" required class="parts" />  </td>
                                        <td></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr><td colspan="2"><center> TEAM DETAILS </center></td></tr>
                        <tr><td>salary :</td><td> <input type="text"     name="txt_salary" required class="textbox" />  </td></tr>
                        <tr><td>position :</td><td> 
                                <select name="txt_position" class="textbox">
                                    <option></option>
                                    <option>
                                        Goal keeper
                                    </option>  <option>
                                        Defenders
                                    </option>
                                    <option>
                                        Midfielder
                                    </option>

                                    <option>
                                        Forwaders
                                    </option>
                                </select>

                            </td></tr>
                        
                        <tr><td></td><td>  <input type="submit" class="confirm_buttons" name="send_player" value="Save"/>  </td></tr>
                    </table>

                </div>
            </div>

            <div class="parts eighty_centered" >
                 <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_my_players($t_id);
                ?>
                 

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_team_combo() {

    $obj = new multi_values();
    $obj->get_team_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}
