<?php
session_start();
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$id = $obj->get_my_team_for_teamManager($_SESSION['userid']);
$_SESSION['my_team'] = $id;
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include './Admin_header.php';
        ?>
        <form action="team_manager_dashboard.php" method="post">
            <div class="part eighty_centered">

                <div class="parts full_center_two_h heit_free">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">   Team Manager dashboard
                        <div class="parts two_fifty_right heit_free">
                            <?php echo $_SESSION['my_team']; ?>
                        </div>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free">
                    Players
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $team_name = $_SESSION['my_team'];
                    $t_id = $obj->get_team_id_by_team_name($team_name);
                    $obj->get_my_players($t_id);
                    ?>
                </div>
            </div>

        </form>

    </body>
</html>
