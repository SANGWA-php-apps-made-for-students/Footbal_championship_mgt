 <?php

class dbconnection {
    function openconnection() {
        $db = new PDO('mysql:host=localhost;dbname=footbal_profile;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }

}

