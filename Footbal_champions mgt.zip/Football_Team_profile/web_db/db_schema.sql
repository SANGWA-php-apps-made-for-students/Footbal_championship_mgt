
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`account_category`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`middle_name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`date_of_birth`     Date 
,`nationality`     VARCHAR(60) 
,`date_registered`     Date 
,`telephone`     VARCHAR(60) 
,`residence`     VARCHAR(60) 

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `championship`
--

CREATE TABLE IF NOT EXISTS `championship` (
`championship_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date_started`     Date 

,PRIMARY KEY (`championship_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
`schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
,`schedule_date`     Date 

,PRIMARY KEY (`schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `fixture`
--

CREATE TABLE IF NOT EXISTS `fixture` (
`fixture_id`     int(11) NOT NULL AUTO_INCREMENT 
,`fixture_date`     Date 
,`position`     VARCHAR(60) 
,`date_to_play`     Date 

,PRIMARY KEY (`fixture_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `match`
--

CREATE TABLE IF NOT EXISTS `match` (
`match_id`     int(11) NOT NULL AUTO_INCREMENT 
,`match_date`     Date 

,PRIMARY KEY (`match_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `goal`
--

CREATE TABLE IF NOT EXISTS `goal` (
`goal_id`     int(11) NOT NULL AUTO_INCREMENT 
,`goal_date`     Date 

,PRIMARY KEY (`goal_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `penalty`
--

CREATE TABLE IF NOT EXISTS `penalty` (
`penalty_id`     int(11) NOT NULL AUTO_INCREMENT 
,`penalty_date`     Date 
,`scored`     VARCHAR(60) 

,PRIMARY KEY (`penalty_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `substitution`
--

CREATE TABLE IF NOT EXISTS `substitution` (
`substitution_id`     int(11) NOT NULL AUTO_INCREMENT 
,`substitution_date`     Date 

,PRIMARY KEY (`substitution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `card`
--

CREATE TABLE IF NOT EXISTS `card` (
`card_id`     int(11) NOT NULL AUTO_INCREMENT 
,`color`     VARCHAR(60) 
,`card_date`     Date 

,PRIMARY KEY (`card_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
`team_id`     int(11) NOT NULL AUTO_INCREMENT 
,`team_name`     VARCHAR(60) 
,`team_date`     Date 

,PRIMARY KEY (`team_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
`player_id`     int(11) NOT NULL AUTO_INCREMENT 
,`position`     VARCHAR(60) 

,PRIMARY KEY (`player_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `referee`
--

CREATE TABLE IF NOT EXISTS `referee` (
`referee_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`referee_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `federation_mng`
--

CREATE TABLE IF NOT EXISTS `federation_mng` (
`federation_mng_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`federation_mng_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`account_category`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`middle_name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`date_of_birth`     Date 
,`nationality`     VARCHAR(60) 
,`date_registered`     Date 
,`telephone`     VARCHAR(60) 
,`residence`     VARCHAR(60) 

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `championship`
--

CREATE TABLE IF NOT EXISTS `championship` (
`championship_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date_started`     Date 

,PRIMARY KEY (`championship_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
`schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
,`schedule_date`     Date 

,PRIMARY KEY (`schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `fixture`
--

CREATE TABLE IF NOT EXISTS `fixture` (
`fixture_id`     int(11) NOT NULL AUTO_INCREMENT 
,`fixture_date`     Date 
,`position`     VARCHAR(60) 
,`date_to_play`     Date 

,PRIMARY KEY (`fixture_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `match`
--

CREATE TABLE IF NOT EXISTS `match` (
`match_id`     int(11) NOT NULL AUTO_INCREMENT 
,`match_date`     Date 

,PRIMARY KEY (`match_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `goal`
--

CREATE TABLE IF NOT EXISTS `goal` (
`goal_id`     int(11) NOT NULL AUTO_INCREMENT 
,`goal_date`     Date 

,PRIMARY KEY (`goal_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `penalty`
--

CREATE TABLE IF NOT EXISTS `penalty` (
`penalty_id`     int(11) NOT NULL AUTO_INCREMENT 
,`penalty_date`     Date 
,`scored`     VARCHAR(60) 

,PRIMARY KEY (`penalty_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `substitution`
--

CREATE TABLE IF NOT EXISTS `substitution` (
`substitution_id`     int(11) NOT NULL AUTO_INCREMENT 
,`substitution_date`     Date 

,PRIMARY KEY (`substitution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `card`
--

CREATE TABLE IF NOT EXISTS `card` (
`card_id`     int(11) NOT NULL AUTO_INCREMENT 
,`color`     VARCHAR(60) 
,`card_date`     Date 

,PRIMARY KEY (`card_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
`team_id`     int(11) NOT NULL AUTO_INCREMENT 
,`team_name`     VARCHAR(60) 
,`team_date`     Date 

,PRIMARY KEY (`team_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
`player_id`     int(11) NOT NULL AUTO_INCREMENT 
,`position`     VARCHAR(60) 

,PRIMARY KEY (`player_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `referee`
--

CREATE TABLE IF NOT EXISTS `referee` (
`referee_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`referee_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `federation_mng`
--

CREATE TABLE IF NOT EXISTS `federation_mng` (
`federation_mng_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`federation_mng_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

