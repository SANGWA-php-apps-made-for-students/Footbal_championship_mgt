<?php 
class deletions{


 function deleteFrom_account( $account_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account where account_id ='$account_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account_category where account_category_id ='$account_category_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$con = new dbconnection();
$con->con_users();
$query="delete from profile where profile_id ='$profile_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_championship( $championship_id){
$con = new dbconnection();
$con->con_users();
$query="delete from championship where championship_id ='$championship_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_schedule( $schedule_id){
$con = new dbconnection();
$con->con_users();
$query="delete from schedule where schedule_id ='$schedule_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_fixture( $fixture_id){
$con = new dbconnection();
$con->con_users();
$query="delete from fixture where fixture_id ='$fixture_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_match( $match_id){
$con = new dbconnection();
$con->con_users();
$query="delete from match where match_id ='$match_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_goal( $goal_id){
$con = new dbconnection();
$con->con_users();
$query="delete from goal where goal_id ='$goal_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_penalty( $penalty_id){
$con = new dbconnection();
$con->con_users();
$query="delete from penalty where penalty_id ='$penalty_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_substitution( $substitution_id){
$con = new dbconnection();
$con->con_users();
$query="delete from substitution where substitution_id ='$substitution_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_card( $card_id){
$con = new dbconnection();
$con->con_users();
$query="delete from card where card_id ='$card_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_team( $team_id){
$con = new dbconnection();
$con->con_users();
$query="delete from team where team_id ='$team_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_player( $player_id){
$con = new dbconnection();
$con->con_users();
$query="delete from player where player_id ='$player_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_referee( $referee_id){
$con = new dbconnection();
$con->con_users();
$query="delete from referee where referee_id ='$referee_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_federation_mng( $federation_mng_id){
$con = new dbconnection();
$con->con_users();
$query="delete from federation_mng where federation_mng_id ='$federation_mng_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


}

