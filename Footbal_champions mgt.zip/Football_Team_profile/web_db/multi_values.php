<?php
require_once '../web_db/connection.php';


class multi_values {

    function list_account() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> username </td>
                    <td> password </td>
                    <td> account_category </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['account_category']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_account_category() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> account_category </td>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_profile() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> middle_name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> date_of_birth </td>
                    <td> nationality </td>
                    <td> date_registered </td>
                    <td> telephone </td>
                    <td> residence </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['middle_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_of_birth']; ?>
                    </td>
                    <td>
                        <?php echo $row['nationality']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_registered']; ?>
                    </td>
                    <td>
                        <?php echo $row['telephone']; ?>
                    </td>
                    <td>
                        <?php echo $row['residence']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_championship() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from championship";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> date_started </td>
                    <td> account </td>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['date_started']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_schedule() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from schedule";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> schedule_date </td>

                    <td> championship </td>
                    <td> Home team </td>
                    <td> Away team </td>
                    <td> Time </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?>
                <tr> 
                    <td>
                        <?php echo $row['schedule_date']; ?>
                    </td>

                    <td>
                        <?php echo $row['championship']; ?>
                    </td>
                    <td>
                        <?php echo $row['home_team']; ?>
                    </td>
                    <td>
                        <?php echo $row['away_team']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_time']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_schedule_to_update() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.matches_id,  matches.match_date,  matches.championship,  
            matches.teamA,  matches.teamB,  matches.teamA_name,  matches.teamB_name,  matches.stadium
                from matches    ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> match_id </td>
                    <td> match_date </td>
                    <td> championship </td>
                    <td> teamA_name </td>
                    <td> teamB_name </td>
                    <td> stadium </td>
                    <td> Option </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td class="match_id_col"><?php echo $row['matches_id']; ?> </td>
                    <td><?php echo $row['match_date']; ?> </td>
                    <td class="champ_id_col"><?php echo $row['championship']; ?> </td>
                    <td><?php echo $row['teamA_name']; ?> </td>
                    <td><?php echo $row['teamB_name']; ?> </td>
                    <td><?php echo $row['stadium']; ?> </td>
                    <td>
                        <a href="#" style="color: #fff;" class="schedule_update_link">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_fixture() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from fixture";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> fixture_date </td>
                    <td> championship </td>
                    <td> TeamA </td>
                    <td> TeamB </td>
                    <td> position </td>
                    <td> date_to_play </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['fixture_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['championship']; ?>
                    </td>
                    <td>
                        <?php echo $row['teamA_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['teamB_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['position']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_to_play']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_match() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from matches";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> match_id </td>
                    <td> match_date </td>
                    <td> teamA </td>
                    <td> teamB </td>
                    <td> championship </td>
                    <td> account </td>

                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['matches_id']; ?>
                    </td> <td>
                        <?php echo $row['match_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['teamA']; ?>
                    </td>
                    <td>
                        <?php echo $row['teamB']; ?>
                    </td>
                    <td>
                        <?php echo $row['championship']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_match_to_confirm() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.matches_id,  matches.match_date,  matches.teamA_name,  matches.teamB_name,  matches.stadium,  matches.confirmed
             from matches
             join championship on matches.championship = championship.championship_id 
             join account on matches.account = account.account_id ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> match_id </td><td> match_date </td><td> teamA_name </td><td> teamB_name </td>
                    <td> stadium </td><td> confirmed </td> 
                    <td>Option</td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['matches_id']; ?> </td>
                    <td>        <?php echo $row['match_date']; ?> </td>
                    <td>        <?php echo $row['teamA_name']; ?> </td>
                    <td>        <?php echo $row['teamB_name']; ?> </td>
                    <td>        <?php echo $row['stadium']; ?> </td>
                    <td>        <?php echo $row['confirmed']; ?> </td>

                    <td>
                        <a href="#" class="match_Confirm_link" value="<?php echo $row['matches_id'] ?>">Confirm</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_goal() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from goal";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> goal_date </td>
                    <td> match </td>
                    <td> player </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['goal_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['matches']; ?>
                    </td>
                    <td>
                        <?php echo $row['player']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_penalty() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from penalty";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> penalty_date </td>
                    <td> player </td>
                    <td> match </td>
                    <td> scored </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['penalty_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['player']; ?>
                    </td>
                    <td>
                        <?php echo $row['match']; ?>
                    </td>
                    <td>
                        <?php echo $row['scored']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_substitution() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from substitution";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> substitution_date </td>
                    <td> to_replace </td>
                    <td> replacing </td>
                    <td> match </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['substitution_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['to_replace']; ?>
                    </td>
                    <td>
                        <?php echo $row['replacing']; ?>
                    </td>
                    <td>
                        <?php echo $row['match']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_card() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from card";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> color </td>
                    <td> card_date </td>
                    <td> player </td>
                    <td> match </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['color']; ?>
                    </td>
                    <td>
                        <?php echo $row['card_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['player']; ?>
                    </td>
                    <td>
                        <?php echo $row['match']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_team() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from team ";
        ?>
        <table class="new_data_table">
            <thead>
                <tr><td> TEAM ID </td>
                    <td> TEAM NAME </td>
<!--                    <td> CREATED DATE </td>
                    <td> MANAGER </td>-->
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['team_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['team_name']; ?>
                    </td>
                    <td class="off">
                        <?php // echo $row['team_date']; ?>
                    </td>
                    <td class="off">
                        <?php //echo $row['manager']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_player() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from player "
                . "   ";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> player </td>
                    <td> salary </td>
                    <td> position </td>
                    <td> team </td>
                    <td> account </td>
                    <td> profile </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['player_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['salary']; ?>
                    </td>
                    <td>
                        <?php echo $row['position']; ?>
                    </td>
                    <td>
                        <?php echo $row['team']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>

                    <td>
                        <a href="#" class="get_player_selected_for_profile" value="<?php echo $row['profile']; ?>" style="color: #000080;"y>View details</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_referee() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from referee";
        ?>
        <table class="new_data_table">
            <thead><tr>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 


                </tr>
            <?php } ?></table>
        <?php
    }

    function list_federation_mng() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from federation_mng";
        ?>
        <table class="new_data_table">
            <thead><tr>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 


                </tr>
            <?php } ?></table>
        <?php
    }

    function list_transfer() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from transfer";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> transfer_request </td>
                    <td> trans_date </td>
                    <td> agreed_price </td>
                    <td> account </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['transfer_request']; ?>
                    </td>
                    <td>
                        <?php echo $row['trans_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['agreed_price']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_team_manager() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from team_manager   ";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> team_manager </td>
                    
                    <td> account </td>
                    <td> team </td>
                    <td> created_by </td>

                </tr></thead>

                    <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['team_manager_id']; ?>
                    </td>
                     
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['team']; ?>
                    </td>
                    <td>
            <?php echo $row['created_by']; ?>
                    </td>

                    </tr>
        <?php } ?></table>
    <?php
    }

    function get_championship_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select championship.championship_id,   championship.name from championship";
        ?>
        <select class="textbox cbo_championship"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['championship_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_championship_id_by_championship_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    championship.championship_id from championship where championship.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['championship_id'];
        echo $userid;
    }

    function get_match_id_by_match_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    match.match_id from match where match.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['match_id'];
        echo $userid;
    }

    function get_player_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select player.player_id,   player.name from player";
        ?>
        <select class="textbox cbo_player"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['player_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_player_id_by_player_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    player.player_id from player where player.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['player_id'];
        echo $userid;
    }

    function get_match_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.matches_id,   match.name from match";
        ?>
        <select class="textbox cbo_match"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['matches_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_team_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,   team.team_name from team";
        ?>
        <select class="textbox cbo_team only_team"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['team_id'] . ">" . $row['team_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_team_id_by_team_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    team.team_id from team where team.team_name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_id'];
        return $userid;
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_id_by_account_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account.account_id from account where account.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        echo $userid;
    }

    function new_trans_request($trans_date, $teamA, $teamB, $player) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into trans_request values(:trans_request_id, :trans_date,  :teamA,  :teamB,  :player)");
        $stm->execute(array(':trans_request_id' => 0, ':trans_date' => $trans_date, ':teamA' => $teamA, ':teamB' => $teamB, ':player' => $player
        ));
    }

    //uni and more

    function get_user_category($username, $password) {
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $cat = '';
        $sql = "select     account_category.name from  account join account_category on account_category.account_category_id=account.account_category where  account.username=:username and  account.password =:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'];
        return $cat;
    }

    function get_name_logged_in($username, $password) {
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $cat = '';
        $sql = "select   profile.name from profile join account on account.profile=profile.profile_id where   account.username=:username and   account.password=:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cat = $row['name'];
        return $cat;
    }

    function get_userid_by_Acc_cat($name) {
        $userid = 0;
        require_once '../Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select     account_category_id from  account_category    where   name = :name";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }

    function get_id_logged_in($username, $password) {
        $userid = 0;
        require_once 'Admin/dbConnection.php';
        $con = new my_connection();
        $sql = "select    account.account_id from account where  account.username=:username and  account.password =:password";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_teamA_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,   team.team_name from team";
        ?>
        <select class="textbox cbo_teamA" name="txt_TeamA" ><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['team_id'] . ">" . $row['team_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_teamB_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,   team.team_name from team";
        ?>
        <select class="textbox cbo_teamB" name="txt_TeamB" ><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['team_id'] . ">" . $row['team_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_transfer_request_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select transfer_request.transfer_request_id,   transfer_request.name from transfer_request";
        ?>
        <select class="textbox cbo_transfer_request"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['transfer_request_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_transfer_request_id_by_transfer_request_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    transfer_request.transfer_request_id from transfer_request where transfer_request.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['transfer_request_id'];
        echo $userid;
    }

    function get_teamA_id_by_teamA_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    teamA.team_id from teamA where team.team_name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['teamA_id'];
        echo $userid;
    }

    function get_teamB_id_by_teamB_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    teamB.teamB_id from teamB where teamB.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['teamB_id'];
        echo $userid;
    }

    function get_last_championship() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   championship.championship_id  from championship order by  championship.championship_id desc limit 1 ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['championship_id'];
        return $userid;
    }

    function get_last_profile() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_lastaccount() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.account_id from account order by account.account_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_lastchampionship_name() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   championship.name from championship order by championship.championship_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_selectable_players() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select player.player_id,  profile.name as fname,  profile.middle_name as mname,  profile.last_name as lname,
            profile.gender,                 profile.date_of_birth,  profile.nationality,  profile.date_registered,  
            profile.telephone,  profile.residence                from profile
                 join player on player.profile = profile.profile_id 
                join team on player.team = team.team_id ";
        ?>
        <table class="new_data_table" id="selectable_option_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> FIRST NAME </td>
                    <td> MIDDLE NAME</td>
                    <td> LAST NAME</td>
                    <td> GENDER </td>
                    <td> DATE OF BIRTH </td>
                    <td> NATIONALITY </td>
                    <td> DATE REGISTERED </td>
                    <td> TELEPHONE </td>
                    <td> RESIDENCE </td>
                    <td> OPTION </td>

                </tr></thead>
                    <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
            <?php echo $row['fname']; ?>
                    </td>
                    <td>
            <?php echo $row['mname']; ?>
                    </td>
                    <td>
            <?php echo $row['lname']; ?>
                    </td>
                    <td>
            <?php echo $row['gender']; ?>
                    </td>
                    <td>
            <?php echo $row['date_of_birth']; ?>
                    </td>
                    <td>
            <?php echo $row['nationality']; ?>
                    </td>
                    <td>
            <?php echo $row['date_registered']; ?>
                    </td>
                    <td>
            <?php echo $row['telephone']; ?>
                    </td>
                    <td>
                           <?php echo $row['residence']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_students" value=" 
                <?php echo $row['player_id']; ?>" style="color: #000080;">Select</a>
                    </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_selectable_players_for_goals() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select player.player_id,  profile.name as fname,  profile.middle_name as mname,  profile.last_name as lname,
            profile.gender,     profile.date_of_birth,  profile.nationality,  profile.date_registered,  
            profile.telephone,  profile.residence,team_id, team.team_name as tea                from profile
                 join player on player.profile = profile.profile_id 
                join team on player.team = team.team_id ";
        ?>
        <table class="new_data_table" id="selectable_option_table_player" style="margin-top: 0px;">
            <thead><tr>
                    <td> FIRST NAME </td>
                    <td> MIDDLE NAME</td>
                    <td> LAST NAME</td>
                    <td> GENDER </td>
                    <td> DATE OF BIRTH </td>
                    <td> NATIONALITY </td>
                    <td> DATE REGISTERED </td>
                    <td> TELEPHONE </td>
                    <td> RESIDENCE </td>
                    <td> OPTION </td>
                </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['fname']; ?>
                    </td>

                    <td class="player_id_col off">
                        <?php echo $row['player_id']; ?>
                    </td>

                    <td>
            <?php echo $row['mname']; ?>
                    </td>
                    <td>
            <?php echo $row['lname']; ?>
                    </td>
                    <td>
            <?php echo $row['gender']; ?>
                    </td>
                    <td>
            <?php echo $row['date_of_birth']; ?>
                    </td>
                    <td>
            <?php echo $row['nationality']; ?>
                    </td>
                    <td>
            <?php echo $row['date_registered']; ?>
                    </td>
                    <td>
            <?php echo $row['telephone']; ?>
                    </td>
                    <td>
            <?php echo $row['residence']; ?>
                    </td>
                    <td class='team_id_col off'>
            <?php echo $row['team_id']; ?>
                    </td>
                    <td class='team_name_col off'>
                           <?php echo $row['tea']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_player" value=" 
                <?php echo $row['player_id']; ?>" style="color: #000080;">Select</a>
                    </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_selectable_mathes() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = " select matches.matches_id, matches.championship, team.team_name,    matches.match_date
                    from matches
                    join team on team.team_id=matches.teamA";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> MATCH No. </td>
                    <td> NAME </td>
                    <td> MATCH DATE </td>
                    <td> OPTION </td>
                </tr></thead>
                    <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
            <?php echo $row['championship']; ?>
                    </td>
                    <td>
            <?php echo $row['team_name']; ?>
                    </td>
                    <td>
                           <?php echo $row['match_date']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_matches" style="color: #000080;" value="
            <?php echo $row['matches_id']; ?>">Select</a>
                    </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_selectable_mathes_for_goal() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = " select matches.matches_id, matches.championship, team.team_name,    matches.match_date, matches.teamA, matches.teamB
                    from matches
                    join team on team.team_id=matches.teamA";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> MATCH No. </td>
                    <td> NAME </td>
                    <td> MATCH DATE </td>
                    <td> OPTION </td>
                </tr></thead>
                    <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
            <?php echo $row['championship']; ?>
                    </td>
                    <td>
            <?php echo $row['team_name']; ?>
                    </td>
                    <td>
            <?php echo $row['match_date']; ?>
                    </td>
                    <td class="teamA_col off">
            <?php echo $row['teamA']; ?>
                    </td>
                    <td class="teamB_col off">
                           <?php echo $row['teamB']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_matches_for_goal" style="color: #000080;" value="
            <?php echo $row['matches_id']; ?>">Select</a>
                    </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_selectable_request() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   trans_request.trans_request_id,  trans_request.transfer_date,  trans_request.teamA,  trans_request.teamB,  trans_request.player,  trans_request.teamA_name,  trans_request.teamB_name,  trans_request.account,  trans_request.proposed_price
                        from trans_request
                        join player on trans_request.player = player.player_id 
                        join account on trans_request.account = account.account_id 
                       ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> trans_request_id </td><td> transfer_date </td><td> teamA </td><td> teamB </td><td> player </td><td> teamA_name </td><td> teamB_name </td><td> account </td><td> proposed_price </td>
                    <td> Option </td> </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['trans_request_id']; ?> </td>
                    <td>        <?php echo $row['transfer_date']; ?> </td>
                    <td>        <?php echo $row['teamA']; ?> </td>
                    <td class="team_transfer_col">        <?php echo $row['teamB']; ?> </td>
                    <td class="player_id_col">        <?php echo $row['player']; ?> </td>
                    <td>        <?php echo $row['teamA_name']; ?> </td>
                    <td>        <?php echo $row['teamB_name']; ?> </td>
                    <td>        <?php echo $row['account']; ?> </td>
                    <td>        <?php echo $row['proposed_price']; ?> </td>
                    <td>
                        <a href="#" class="select_link_trans_request" style="color: #000080;" value="
            <?php echo $row['trans_request_id']; ?>">Select</a></td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_teamA_by_match($match_id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "SELECT matches.teamA FROM footbal_profile.matches                where matches.matches_id=:matches_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':matches_id', $match_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['teamA'];
        return $userid;
    }

    function get_teamB_by_match($match_id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "SELECT matches.teamB FROM footbal_profile.matches
                where matches.matches_id=:matches_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':matches_id', $match_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['teamB'];
        return $userid;
    }

    function get_team_by_player($player) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "  select     player.team  from player where player=:player";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':player', $player);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team'];
        return $userid;
    }

    function get_point_teamA($matches) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = " select  goal.pointsA
                    from goal
                    join player on goal.player = player.player_id 
                    where goal.matches=:matches ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':matches', $matches);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['pointsA'];
        return $userid;
    }

    function get_point_teamB($matches) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = " select  goal.pointsB
                    from goal
                    join player on goal.player = player.player_id 
                    where goal.matches=:matches ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':matches', $matches);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['pointsB'];
        return $userid;
    }

    function list_matches() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.matches_id,  matches.match_date,  matches.championship,   
            matches.teamA_name,  matches.teamB_name
                from matches
                join championship on matches.championship = championship.championship_id 
                join account on matches.account = account.account_id 
                where confirmed='yes' ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> match_id </td><td> match_date </td><td> championship </td>
                    <td> teamA_name </td><td> teamB_name </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['matches_id']; ?> </td>
                    <td>        <?php echo $row['match_date']; ?> </td>
                    <td>        <?php echo $row['championship']; ?> </td>


                    <td>        <?php echo $row['teamA_name']; ?> </td>
                    <td>        <?php echo $row['teamB_name']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function list_trans_request() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select trans_request.trans_request_id,  trans_request.transfer_date,  trans_request.teamA,  trans_request.teamB,  trans_request.player,  trans_request.teamA_name,  trans_request.teamB_name,  trans_request.account,  trans_request.proposed_price
                from trans_request
                join player on trans_request.player = player.player_id 
                join account on trans_request.account = account.account_id 
               ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> trans_request_id </td><td> transfer_date </td><td> teamA </td><td> teamB </td><td> player </td><td> teamA_name </td><td> teamB_name </td><td> account </td><td> proposed_price </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['trans_request_id']; ?> </td>
                    <td>        <?php echo $row['transfer_date']; ?> </td>
                    <td>        <?php echo $row['teamA']; ?> </td>
                    <td>        <?php echo $row['teamB']; ?> </td>
                    <td>        <?php echo $row['player']; ?> </td>
                    <td>        <?php echo $row['teamA_name']; ?> </td>
                    <td>        <?php echo $row['teamB_name']; ?> </td>
                    <td>        <?php echo $row['account']; ?> </td>
                    <td>        <?php echo $row['proposed_price']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_profile_by_id($profile) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select profile.name,    profile.last_name,profile.middle_name,  profile.gender,  profile.date_of_birth,  profile.nationality, 
                    profile.date_registered,  profile.telephone,  profile.residence,  profile.profile_id
                 from profile where profile.profile_id=:profile_id  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $profile);
        $stmt->execute();
        ?>
        <div class="parts full_center_two_h heit_free xxx_titles">
            Player Profile
        </div>
        <table class="new_data_table left_off_seventy" style="font-size: 18px;">
            <thead> 
            </thead>
        <?php while ($row = $stmt->fetch()) { ?> 
                <tr> <td>Name:</td>  <td> <?php echo $row['name']; ?></td>         
                <tr> <td>Middle name</td>  <td> <?php echo $row['middle_name']; ?> </td>
                <tr> <td>Last name:</td>  <td>     <?php echo $row['last_name']; ?>       </td> <tr>
                <tr> <td>Gender:</td>  <td>     <?php echo $row['gender']; ?>          </td> <tr>
                <tr> <td>Date of birth:</td>  <td>     <?php echo $row['date_of_birth']; ?>   </td> <tr>
                <tr> <td>Nationality</td>  <td>     <?php echo $row['nationality']; ?>     </td> <tr>
                <tr> <td>Recruitment date</td>  <td>     <?php echo $row['date_registered']; ?> </td> <tr>
                <tr> <td>Telephone</td>  <td>     <?php echo $row['telephone']; ?>       </td> <tr>
                <tr> <td>Residence: </td>  <td>     <?php echo $row['residence']; ?>       </td> <tr>
                <tr class="off"> <td>Profile id</td>  <td>     <?php echo $row['profile_id']; ?>      </td> <tr>

        <?php } ?></table>
        <?php
    }

    function get_matches_teamA_name_by_matches($match_id) {
        $db = new dbconnection();
        $sql = "select    teamA_name  from matches          
            where  matches.matches_id = :match_id ";
        $stmt = $db->openconnection()->prepare($sql);
        $stmt->bindValue(':match_id', $match_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['teamA_name'];

        $sql2 = "select    teamB_name  from matches          
            where  matches.matches_id = :match_id ";
        $stmt2 = $db->openconnection()->prepare($sql2);
        $stmt2->bindValue(':match_id', $match_id);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $userid2 = $row2['teamB_name'];

        $str = $userid . '  --vs-- ' . $userid2;
        echo $str;
    }

//here are 2 teams returned

    function get_player_team_by_player($player_id) {
        $db = new dbconnection();
        $sql = "select    team_name  from team  
                    join player on player.team = team.team_id  where player.player_id =:player_id  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':player_id', $player_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_name'];
        return $userid;
    }

    function get_player_by_teams($teamA, $teamB) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select player.player_id,  profile.profile_id,  profile.name,  profile.middle_name,  profile.last_name,  profile.gender,  profile.date_of_birth,  profile.nationality,  profile.date_registered,  profile.telephone,  profile.residence
             from player
             join team on player.team = team.team_id 
             join profile on player.profile = profile.profile_id 
             where   team.team_id =:teamA  or   team.team_id =:teamB  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':teamA', $teamA);
        $stmt->bindValue(':teamB', $teamB);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> player_id </td><td> profile_id </td><td> name </td><td> middle_name </td><td> last_name </td><td> gender </td>
                    <td> date_of_birth </td><td> nationality </td><td> date_registered </td><td> telephone </td>
                    <td> residence </td>
                    <td> Option </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>        <?php echo $row['player_id']; ?> </td>
                    <td>        <?php echo $row['profile_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['middle_name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['date_of_birth']; ?> </td>
                    <td>        <?php echo $row['nationality']; ?> </td>
                    <td>        <?php echo $row['date_registered']; ?> </td>
                    <td>        <?php echo $row['telephone']; ?> </td>
                    <td>        <?php echo $row['residence']; ?> </td>
                    <td>
                        <a href="#" class="player_id_link" style="color: #000080;" >Select</a>
                    </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function list_match_participant() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from match_participant where match_participant.deleted='no'  ";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> match_participant </td>
                    <td> match_participantdeleted </td>
                    <td> match </td>
                    <td> player </td>
                    <td> allowed </td>
                    <td> substitute </td>

                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
            <?php echo $row['match_participant_id']; ?>
                    </td>
                    <td>
            <?php echo $row['deleted']; ?>
                    </td>
                    <td>
            <?php echo $row['match']; ?>
                    </td>
                    <td>
            <?php echo $row['player']; ?>
                    </td>
                    <td>
            <?php echo $row['allowed']; ?>
                    </td>
                    <td>
                           <?php echo $row['substitute']; ?>
                    </td>

                    <td>
                        <a href="#" class="delete_link_match_participantmatch_participant" style="color: #000080;" value="
            <?php echo $row['match_participant_id']; ?>">Delete</a>
                    </td></tr>
        <?php } ?></table>
        <?php
    }

    function get_account_category_id_by_name($name) {
        $con = new my_connection();
        $sql = "select    account_category_id  from account_category
                where  account_category.name =:name    ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }

    function get_referees($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select profile.profile_id,  profile.name,  profile.middle_name,  profile.last_name,
            profile.gender,  profile.date_of_birth,  profile.nationality,  profile.date_registered, 
            profile.telephone,  profile.residence                 from profile
             join account on account.profile = profile.profile_id 
                join account_category on account.account_category = account_category.account_category_id 
              where  account_category.name = :name";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> profile_id </td><td> name </td><td> middle_name </td><td> last_name </td><td> gender </td><td> date_of_birth </td><td> nationality </td><td> date_registered </td><td> telephone </td><td> residence </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>        <?php echo $row['profile_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['middle_name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['date_of_birth']; ?> </td>
                    <td>        <?php echo $row['nationality']; ?> </td>
                    <td>        <?php echo $row['date_registered']; ?> </td>
                    <td>        <?php echo $row['telephone']; ?> </td>
                    <td>        <?php echo $row['residence']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_teams_to_participate() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,  team.team_name, player.player_id
             from team
             join player on player.team = team.team_id 
             join profile on player.profile = profile.profile_id group by team_id  ";
        ?>
        <table class="new_data_table">
            <thead><tr><td>
                        <input type="checkbox" name="" id="check_all">Option
                    </td><td> team_id </td><td> team_name </td><td> player_id </td>
                </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr>  <td>  
                        <input type="checkbox" name="teams[]" value="<?php echo $row['team_id']; ?>"  class="checkables">  </td>
                    <td>        <?php echo $row['team_id']; ?> </td>
                    <td>        <?php echo $row['team_name']; ?> </td>
                    <td>        <?php echo $row['player_id']; ?> </td>
                </tr>
        <?php } ?>
        </table>
        <?php
    }

    function get_player_id_by_team_id($team) {
        $database = new dbconnection();
        $sql = "select    player_id  from player  
                join team on player.team = team.team_id 
                where   team.team_id =:team_id ";
        $stmt = $database->openconnection()->prepare($sql);
        $stmt->bindValue(':team_id', $team);
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            $userid = $row['player_id'];
            echo $userid;
        }
    }

    function get_player_byTransferRequest() {
        $con = new my_connection();
        $sql = "select    player  from trans_request 
                where   trans_request.trans_request_id = '$trans_request_id'   ";
        $stmt = $con->getCon()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['player'];
        return $userid;
    }

    function get_team_name_by_account($username, $password) {
        $con = new my_connection();
        $sql = "select    team_name  from team 
           join team_manager on team_manager.team = team.team_id 
            join account on team_manager.account = account.account_id 
            where  and account.username =:username and account.password = :password ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':password', $password);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_name'];
        return $userid;
    }

    function get_All_users() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,  account.username,  account.password,  account_category.name as cat,  profile.name,  profile.last_name
                    from account
                    join account_category on account.account_category = account_category.account_category_id 
                    join profile on account.profile = profile.profile_id ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> account_id </td><td> username </td><td> password </td><td> name </td><td> name </td><td> last_name </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['account_id']; ?> </td>
                    <td>        <?php echo $row['username']; ?> </td>
                    <td>        <?php echo $row['password']; ?> </td>
                    <td>        <?php echo $row['cat']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_my_team($account) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,team.team_name from team 
                  join team_manager on team_manager.team = team.team_id 
						where team_manager.account=:account";
        $stmt = $database->openconnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> ID </td>
                    <td> NAME </td 

                </tr></thead>
            <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td><?php echo $row['team_id']; ?> </td>
                    <td><?php echo $row['team_name']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_my_team_for_teamManager($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select team.team_name ,team_name from team 
                  join team_manager on team_manager.team = team.team_id 
						where team_manager.account=:account";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_name'];
        return $userid;
    }

    function get_my_tam_id($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select team.team_id ,team_name from team 
                  join team_manager on team_manager.team = team.team_id 
						where team_manager.account=:account";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_id'];
        return $userid;
    }

    function get_my_player($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select team.team_name ,team_name from team 
                  join team_manager on team_manager.team = team.team_id 
						where team_manager.account=:account";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['team_name'];
        return $userid;
    }

    function get_my_players($team) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select player.player_id,  player.salary,  player.position,  player.team,  profile.name, 
            profile.middle_name,  profile.last_name,  profile.gender,  team.team_id
         from player
         join team on player.team = team.team_id 
         join account on player.account = account.account_id 
         join profile on player.profile = profile.profile_id 
               where  team.team_id = :team_id";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':team_id', $team);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> player_id </td><td> salary </td><td> position </td><td> team </td><td> name </td><td> middle_name </td><td> last_name </td><td> gender </td><td> team_id </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>        <?php echo $row['player_id']; ?> </td>
                    <td>        <?php echo $row['salary']; ?> </td>
                    <td>        <?php echo $row['position']; ?> </td>
                    <td>        <?php echo $row['team']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['middle_name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['team_id']; ?> </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_schedule_toupdate() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.matches_id,  matches.match_date,  matches.teamA_name,  matches.teamB_name,  matches.stadium,  schedule.home_team,  schedule.away_team
                from matches
                 join championship on matches.championship = championship.championship_id 
                join schedule on schedule.championship = championship.championship_id
               join account on matches.account = account.account_id ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> match_id </td><td> match_date </td><td> teamA_name </td><td> teamB_name </td><td> stadium </td><td> home_team </td><td> away_team </td>
                </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['matches_id']; ?> </td>
                    <td>        <?php echo $row['match_date']; ?> </td>
                    <td>        <?php echo $row['teamA_name']; ?> </td>
                    <td>        <?php echo $row['teamB_name']; ?> </td>
                    <td>        <?php echo $row['stadium']; ?> </td>
                    <td>        <?php echo $row['home_team']; ?> </td>
                    <td>        <?php echo $row['away_team']; ?> </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_unassigned_teams() {
        $db = new dbconnection();
        $sql = "select team_id from team where team_id not in (select   team from player)   ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $c = 0;
        while ($row = $stmt->fetch()) {
            $c+=1;
        }
        if ($c >= 1) {
            return $c;
        }
    }

    function get_unassigned_teams_list() {
        $db = new dbconnection();
        $sql = "select team_id ,team_name from team where team_id not in (select   team from player)   ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $c = 0;
        ?>
        <table class="new_data_table">
            <thead>
            <td>TEAM NAME</td>
        </thead>

        <?php while ($row = $stmt->fetch()) { ?>
            <tr>
                <td><?php echo $row['team_name']; ?></td>
            </tr>
        <?php }
        ?>
        </table><?php
    }

}
?>
<html>
    <head>
        <title>title</title>
        <style>
            .new_data_table tr{
                border-bottom: 1px solid #8ab5bf;
            }
        </style>
    </head>
    <body>

    </body>
</html>
