<?php

class new_values {

    function new_account($account_category,$date_created,$profile,$username, $password,   $online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id,  :account_category, :date_created, :profile, :username,  :password, :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category,':date_created'=>$date_created, ':profile' => $profile,    ':username' => $username, ':password' => $password, ':is_online' => $online));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function new_account_category($name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name
        ));
    }

    function new_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into profile values(:profile_id, :name,  :middle_name,  :last_name,  :gender,  :date_of_birth,  :nationality,  :date_registered,  :telephone,  :residence)");
        $stm->execute(array(':profile_id' => 0, ':name' => $name, ':middle_name' => $middle_name, ':last_name' => $last_name, ':gender' => $gender, ':date_of_birth' => $date_of_birth, ':nationality' => $nationality, ':date_registered' => $date_registered, ':telephone' => $telephone, ':residence' => $residence
        ));
    }

    function new_championship($date_started, $account, $name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into championship values(:championship_id, :date_started,  :account, :name)");
        $stm->execute(array(':championship_id' => 0, ':date_started' => $date_started, ':account' => $account, ':name' => $name
        ));
    }

    function new_schedule($schedule_date, $teamA, $teamB, $championship, $home_team, $away_team, $time) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into schedule values(:schedule_id, :schedule_date,  :teamA,  :teamB,  :championship, :home_team, :away_team, :date_time)");
        $stm->execute(array(':schedule_id' => 0, ':schedule_date' => null, ':teamA' => $teamA, ':teamB' => null, ':championship' => $championship, ':home_team' => $home_team, ':away_team' => null, ':date_time' => null));
    }

    function new_fixture($fixture_date, $championship, $TeamA, $TeamB, $position, $date_to_play, $teamA, $teamB) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into fixture values(:fixture_id, :fixture_date,  :championship,  :TeamA,  :TeamB,  :position,  :date_to_play, :teamA_name, :teamB_name)");
        $stm->execute(array(':fixture_id' => 0, ':fixture_date' => $fixture_date, ':championship' => $championship, ':TeamA' => $TeamA, ':TeamB' => null, ':position' => $position, ':date_to_play' => null, ':teamA_name' => $teamA, ':teamB_name' => null
        ));
    }

    function new_match($match_date, $teamA, $teamB, $championship, $account, $teamA_name, $teamB_name, $stadium, $confirmed) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into matches values(:match_id, :match_date,  :teamA,  :teamB,  :championship,  :account, :teamA_name, :teamB_name, :stadium, :confirmed)");
        $stm->execute(array(':match_id' => 0, ':match_date' => null, ':teamA' => $teamA, ':teamB' => null, ':championship' => $championship, ':account' => $account, ':teamA_name' => $teamA_name, ':teamB_name' => null, ':stadium' => null, ':confirmed' => null));
    }

    function new_goal($goal_date, $match, $player, $winner, $pointsA, $pointsB) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into goal values(:goal_id, :goal_date,  :match,  :player,:winner, :pointsA,:pointsB)");
        $stm->execute(array(':goal_id' => 0, ':goal_date' => $goal_date, ':match' => $match, ':player' => $player, ':winner' => $winner, ':pointsA' => $pointsA, ':pointsB' => $pointsB
        ));
    }

    function new_penalty($penalty_date, $player, $match, $scored) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into penalty values(:penalty_id, :penalty_date,  :player,  :match,  :scored)");
        $stm->execute(array(':penalty_id' => 0, ':penalty_date' => $penalty_date, ':player' => $player, ':match' => $match, ':scored' => $scored
        ));
    }

    function new_substitution($substitution_date, $to_replace, $replacing, $match) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into substitution values(:substitution_id, :substitution_date,  :to_replace,  :replacing,  :match)");
        $stm->execute(array(':substitution_id' => 0, ':substitution_date' => $substitution_date, ':to_replace' => $to_replace, ':replacing' => $replacing, ':match' => $match
        ));
    }

    function new_card($color, $card_date, $player, $match) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into card values(:card_id, :color,  :card_date,  :player,  :match)");
        $stm->execute(array(':card_id' => 0, ':color' => $color, ':card_date' => $card_date, ':player' => $player, ':match' => $match
        ));
    }

    function new_team($team_name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into team values(:team_id, :team_name)");
            $stm->execute(array(':team_id' => 0, ':team_name' => $team_name));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function new_player($salary, $position, $team, $account, $profile) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into player values(:player_id, :salary,  :position,  :team,  :account,:profile)");
            $stm->execute(array(':player_id' => 0, ':salary' => $salary, ':position' => $position, ':team' => $team, ':account' => $account, ':profile' => $profile
            ));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function new_referee($username, $password, $account_category, $profile) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category, :profile)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category, ':profile' => $profile));
    }

    function new_federation_mng() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into federation_mng values(:federation_mng_id,)");
        $stm->execute(array(':federation_mng_id' => 0,
        ));
    }

    function list_trans_request() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from trans_request";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> trans_date </td>
                    <td> teamA </td>
                    <td> teamB </td>
                    <td> player </td>

                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
            <?php echo $row['trans_date']; ?>
                    </td>
                    <td>
            <?php echo $row['teamA']; ?>
                    </td>
                    <td>
            <?php echo $row['teamB']; ?>
                    </td>
                    <td>
            <?php echo $row['player']; ?>
                    </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function new_transfer($transfer_request, $trans_date, $agreed_price, $account) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into transfer values(:transfer_id, :transfer_request,  :trans_date,  :agreed_price,  :account)");
        $stm->execute(array(':transfer_id' => 0, ':transfer_request' => $transfer_request, ':trans_date' => $trans_date, ':agreed_price' => $agreed_price, ':account' => $account));
    }

    function new_trans_request($transfer_date, $teamA, $teamB, $player, $teamA_name, $teamB_name, $account, $proposed_price) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into trans_request values(:trans_request_id, :transfer_date,  :teamA,  :teamB,  :player,  :teamA_name,  :teamB_name,  :account,  :proposed_price)");
        $stm->execute(array(':trans_request_id' => 0, ':transfer_date' => $transfer_date, ':teamA' => $teamA, ':teamB' => $teamB, ':player' => $player, ':teamA_name' => $teamA_name, ':teamB_name' => $teamB_name, ':account' => $account, ':proposed_price' => $proposed_price
        ));
    }

    function new_match_participant($match_participantdeleted, $match, $player, $allowed, $substitute) {
      try{  require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
         $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into match_participant values(:match_participant_id, :match_participantdeleted,  :matches,  :player,  :allowed,  :substitute)");
        $stm->execute(array(':match_participant_id' => 0, ':match_participantdeleted' => $match_participantdeleted, ':matches' => $match, ':player' => $player, ':allowed' => $allowed, ':substitute' => $substitute
        ));
      } catch (Exception $e){
          echo $e->getMessage();
      }
    }

    function new_team_manager($team_managerdeleted, $account, $team, $created_by) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into team_manager values(:team_manager_id, :team_managerdeleted,  :account,  :team,  :created_by)");
            $stm->execute(array(':team_manager_id' => 0, ':team_managerdeleted' => $team_managerdeleted, ':account' => $account, ':team' => $team, ':created_by' => $created_by));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    //away data

    function new_away_match_match($match_date, $teamA, $teamB, $championship, $account, $teamA_name, $teamB_name, $stadium, $confirmed) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into matches values(:match_id, :match_date,  :teamA,  :teamB,  :championship,  :account, :teamA_name, :teamB_name, :stadium, :confirmed)");
        $stm->execute(array(':match_id' => 0, ':match_date' => null, ':teamA' => null, ':teamB' => $teamB, ':championship' => $championship, ':account' => $account, ':teamA_name' => null, ':teamB_name' => $teamB_name, ':stadium' => null, ':confirmed' => null));
    }

    function new_away_schedule($schedule_date, $teamA, $teamB, $championship, $home_team, $away_team, $time) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into schedule values(:schedule_id, :schedule_date,  :teamA,  :teamB,  :championship, :home_team, :away_team, :date_time)");
        $stm->execute(array(':schedule_id' => 0, ':schedule_date' => null, ':teamA' => null, ':teamB' => $teamB, ':championship' => $championship, ':home_team' => null, ':away_team' => $away_team, ':date_time' => null));
    }

    function new_away_match_fixture($fixture_date, $championship, $TeamA, $TeamB, $position, $date_to_play, $teamA, $teamB) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into fixture values(:fixture_id, :fixture_date,  :championship,  :TeamA,  :TeamB,  :position,  :date_to_play, :teamA_name, :teamB_name)");
        $stm->execute(array(':fixture_id' => 0, ':fixture_date' => $fixture_date, ':championship' => $championship, ':TeamA' => null, ':TeamB' => $TeamB, ':position' => $position, ':date_to_play' => null, ':teamA_name' => null, ':teamB_name' => $teamB));
    }

}
