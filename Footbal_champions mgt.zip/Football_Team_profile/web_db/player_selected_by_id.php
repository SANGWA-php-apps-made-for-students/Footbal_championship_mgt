<?php

class multi_valuesp {
       function get_player_by_teams($teamA, $teamB) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select player.player_id,  profile.profile_id,  profile.name,  profile.middle_name,  profile.last_name,  profile.gender,  profile.date_of_birth,  profile.nationality,  profile.date_registered,  profile.telephone,  profile.residence
             from player
             join team on player.team = team.team_id 
             join profile on player.profile = profile.profile_id 
             where   team.team_id =:teamA  or   team.team_id =:teamB  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':teamA', $teamA);
        $stmt->bindValue(':teamB', $teamB);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> player_id </td><td> profile_id </td><td> name </td><td> middle_name </td><td> last_name </td><td> gender </td>
                    <td> date_of_birth </td><td> nationality </td><td> date_registered </td><td> telephone </td>
                    <td> residence </td>
                    <td> Option </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>        <?php echo $row['player_id']; ?> </td>
                    <td>        <?php echo $row['profile_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['middle_name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['date_of_birth']; ?> </td>
                    <td>        <?php echo $row['nationality']; ?> </td>
                    <td>        <?php echo $row['date_registered']; ?> </td>
                    <td>        <?php echo $row['telephone']; ?> </td>
                    <td>        <?php echo $row['residence']; ?> </td>
                    <td>
                        <a href="#" class="player_id_link" style="color: #000080;" value="<?php echo $row['player_id'] ?>" >Select</a>
                    </td>
                </tr>
        <?php } ?></table>
        <?php
    }

}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>

        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>
