<?php

class schedules_update {

    function list_schedule_to_update() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from schedule";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> schedule_date </td>
                    <td> championship </td>
                    <td> Home team </td>
                    <td> Away team </td>
                    <td> Time </td>
                    <td> Option </td>

                </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?>
                <tr> 
                    <td>
            <?php echo $row['schedule_date']; ?>
                    </td>
                    <td>
            <?php echo $row['championship']; ?>
                    </td>
                    <td>
            <?php echo $row['home_team']; ?>
                    </td>
                    <td>
            <?php echo $row['away_team']; ?>
                    </td>
                    <td>
            <?php echo $row['date_time']; ?>
                    </td>
                    <td class="allow_drop">
                        <div class="parts  sub_dialog off">
                            <div class="hidden_dialog">
                                <input type="text" style="float: left;" class="parts date_pick"   placeholder="date" style="width: 80px; padding: 10px;" id="minutes" name="txt_match_date">
                                <select style="width: auto;" name="txt_time">
                                    <option>08h</option>
                                    <option>09h</option>
                                    <option>10h</option>
                                    <option>11h</option>
                                    <option>12h</option>
                                    <option>13h</option>
                                    <option>14h</option>
                                    <option>14h</option>
                                    <option>15h</option>
                                    <option>16h</option>
                                    <option>17h</option>
                                    <option>18h</option>
                                    <option>19h</option>
                                    <option>20h</option>
                                    <option>21h</option>
                                    <option>22h</option>
                                    <option>23h</option>
                                    <option>00h</option>
                                    <option>01h</option>
                                    <option>02h</option>
                                    <option>03h</option>
                                    <option>04h</option>
                                    <option>05h</option>
                                    <option>06h</option>
                                    <option>07h</option>
                                </select>
                                <input type="text" class="two_digits only_numbers"  style="width: 80px; padding: 10px;" id="minutes" name="txt_name">
                                <input type="text" id="dd">
                            </div>
                        </div>
                        <a href="#" style="color: #0a7740" class="schedule_update_link">Update</a>
                    </td>
                </tr>
        <?php } ?></table>
        <?php
    }
}
?>
<html>
    <head>
        <title>title</title>
        <link href="../federation_mngr/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../federation_mngr/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../federation_mngr/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../federation_mngr/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../federation_mngr/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../federation_mngr/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        
       
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../federation_mngr/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../federation_mngr/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            $('.date_pick').datepicker({
                minDate: new Date(),
                dateFormat: 'yy-mm-dd'
            });
            $('#dd').datepicker({
                minDate: new Date(),
                dateFormat: 'yy-mm-dd'
            });
        </script>
    </body>
</html>
