<?php

require_once '../web_db/connection.php';

class updates {

    function update_account($username, $password, $account_category) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update account  set username= '$username', password= '$password', account_category= '$account_category'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_account_category($name) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update account_category  set name= '$name'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_profile($name, $middle_name, $last_name, $gender, $date_of_birth, $nationality, $date_registered, $telephone, $residence) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update profile  set name= '$name', middle_name= '$middle_name', last_name= '$last_name', gender= '$gender', date_of_birth= '$date_of_birth', nationality= '$nationality', date_registered= '$date_registered', telephone= '$telephone', residence= '$residence'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_championship($date_started, $account) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update championship  set date_started= '$date_started', account= '$account'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_schedule($schedule_date, $team, $team, $championship) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update schedule  set schedule_date= '$schedule_date', team= '$team', team= '$team', championship= '$championship'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_fixture($fixture_date, $championship, $TeamA, $TeamB, $position, $date_to_play) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update fixture  set fixture_date= '$fixture_date', championship= '$championship', TeamA= '$TeamA', TeamB= '$TeamB', position= '$position', date_to_play= '$date_to_play'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_match($match_date, $teamA, $teamB, $championship, $account) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update match  set match_date= '$match_date', teamA= '$teamA', teamB= '$teamB', championship= '$championship', account= '$account'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_match_toschedule($teamidA, $teamA_name) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update matches  set teamA= ?, teamA_name=? WHERE matches_id= ? ");
        $stmt->execute(array($teamidA, $teamA_name));
    }

    function update_goal($goal_date, $match, $player) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update goal  set goal_date= '$goal_date', match= '$match', player= '$player'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_penalty($penalty_date, $player, $match, $scored) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update penalty  set penalty_date= '$penalty_date', player= '$player', match= '$match', scored= '$scored'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_substitution($substitution_date, $to_replace, $replacing, $match) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update substitution  set substitution_date= '$substitution_date', to_replace= '$to_replace', replacing= '$replacing', match= '$match'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_card($color, $card_date, $player, $match) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update card  set color= '$color', card_date= '$card_date', player= '$player', match= '$match'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_team($team_name, $team_date) {
        $con = new dbconnection();
        $con->con_users();

        $query = "update team  set team_name= '$team_name', team_date= '$team_date'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_player($salary, $position, $team, $account) {
        $con = new dbconnection();
        $con->con_users();
        $query = "update player  set salary= '$salary', position= '$position', team= '$team', account= '$account'";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_player_team($team, $player_id) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update player  set team= ? WHERE player_id= ? ");
        $stmt->execute(array($team, $player_id));
    }

    function update_referee() {
        $con = new dbconnection();
        $con->con_users();

        $query = "update referee  set ";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_federation_mng() {
        $con = new dbconnection();
        $con->con_users();

        $query = "update federation_mng  set ";
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function update_confirm_match($confirmed, $match_id) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update matches  set confirmed= ? WHERE matches_id= ? ");
        $stmt->execute(array($confirmed, $match_id));
        echo 'Match Confirmed';
    }

    //away teams

    function update_away_team_match($teamB, $name) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update matches  set teamB= ?, teamB_name=? WHERE teamB is null ");
        $stmt->execute(array($teamB, $name));
    }

    function update_away_team_schedule($teamA, $away_team) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update schedule  set teamB= ?,  away_team=? WHERE teamB is null ");
        $stmt->execute(array($teamA, $away_team));
    }

    function update_away_team_fixture($teamB, $team_name) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update fixture  set TeamB= ?, teamB_name=? WHERE TeamB is null ");
        $stmt->execute(array($teamB, $team_name));
    }

    //away team

    function update_away_team_match2($teamB, $name) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update matches  set teamA= ?, teamA_name=? WHERE teamA is null ");
        $stmt->execute(array($teamB, $name));
    }

    function update_away_team_schedule2($teamA, $away_team) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update schedule  set teamA= ?,  home_team=? WHERE teamA is null ");
        $stmt->execute(array($teamA, $away_team));
    }

    function update_away_team_fixture2($teamB, $team_name) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update fixture  set TeamA= ?, teamA_name=? WHERE TeamA is null ");
        $stmt->execute(array($teamB, $team_name));
    }

    //update match and fixture
    function update_match_staidum_time($match_date, $stadium, $match) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update matches  set match_date= ? ,stadium =?  where matches_id= ? ");
        $stmt->execute(array($match_date, $stadium, $match));
    }

    function update_fixture_staidum_time($date_to_play, $champ) {
        $dbase = new dbconnection();
        $db = $dbase->openconnection();
        $stmt = $db->prepare("update fixture set date_to_play= ? where championship= ? ");
        $stmt->execute(array($date_to_play, $champ));
    }

}
