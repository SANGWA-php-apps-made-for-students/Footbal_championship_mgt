var slideCounter = 0;
var count = 0;
$(document).ready(function () {
    try {
        get_teamA_id_combo();
        get_teamB_id_combo();
        get_team_id_combo();
        get_account_id_combo();
        get_championship_id_combo();
        get_championship_id_combo();
        get_championship_id_combo();
        get_account_id_combo();
        get_match_id_combo();
        get_player_id_combo();
        get_player_id_combo();
        get_match_id_combo();
        get_match_id_combo();
        get_player_id_combo();
        get_match_id_combo();
        get_account_id_combo();
        slideShow();
        get_card();
        show_players_list();
        show_matches_list();
        get_students_selected();
        get_match_selected();
        show_trans_requests_list();
        get_trans_request_selected();
        get_player_selected_for_profile();
        get_away_check();
        validate_numbers_textfields();
        hover_theme1();
        get_link_matches_for_goal();
        get_current_match_displayed();
        get_team_by_player();
        get_player_by_id_link();
        get_current_champ();
        get_checkables_checked();
        get_show_team_participate();
        get_confirm_match();
        get_only_team_selected();
        get_schedule_update_link();
        disp();
    } catch (err) {
        alert(err.message);
    }

});
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_teamA_id_combo() {
    try {
        $('.cbo_teamA').change(function () {
            var cbo_team = $('.cbo_teamA option:selected').text();
            $('#txt_teamA_name').val(cbo_team);
            $.post('../Admin/handler.php', {cbo_team: cbo_team}, function (data) {
                $('#txt_team_idA').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_teamB_id_combo() {
    try {
        $('.cbo_teamB').change(function () {
            var cbo_team = $('.cbo_teamB option:selected').text();
            $('#txt_teamB_name').val(cbo_team);
            $.post('../Admin/handler.php', {cbo_team: cbo_team}, function (data) {
                $('#txt_team_idB').val(data);

            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_team_id_combo() {
    try {
        $('.cbo_team').change(function () {
            var cbo_team = $('.cbo_team option:selected').text();
            $.post('../Admin/handler.php', {cbo_team: cbo_team}, function (data) {
                $('#txt_team_id').val(data);

            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_championship_id_combo() {
    try {
        $('.cbo_championship').change(function () {
            var cbo_championship = $('.cbo_championship option:selected').text();
            $.post('../Admin/handler.php', {cbo_championship: cbo_championship}, function (data) {
                $('#txt_championship_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').text();
            $.post('../Admin/handler.php', {cbo_match: cbo_match}, function (data) {
                $('#txt_match_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').text();
            $.post('../Admin/handler.php', {cbo_player: cbo_player}, function (data) {
                $('#txt_player_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').text();
            $.post('../Admin/handler.php', {cbo_match: cbo_match}, function (data) {
                $('#txt_match_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_player_id_combo() {
    try {
        $('.cbo_player').change(function () {
            var cbo_player = $('.cbo_player option:selected').text();
            $.post('../Admin/handler.php', {cbo_player: cbo_player}, function (data) {
                $('#txt_player_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_match_id_combo() {
    try {
        $('.cbo_match').change(function () {
            var cbo_match = $('.cbo_match option:selected').text();
            $.post('../Admin/handler.php', {cbo_match: cbo_match}, function (data) {
                $('#txt_match_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function slideShow() {
    setTimeout(function () {
        slideCounter += 1;
        if (slideCounter == 6) {
            $('.slide_pics').fadeOut(450);
            $('#pic1').fadeIn(450);
        } else if (slideCounter == 11) {
            $('.slide_pics').fadeOut(450);
            $('#pic2').fadeIn(450);
        } else if (slideCounter == 17) {
            $('.slide_pics').fadeOut(450);
            $('#pic3').fadeIn(450);
        } else if (slideCounter == 24) {
            $('.slide_pics').fadeOut(450);
            $('#pic4').fadeIn(450);
        } else if (slideCounter == 31) {
            $('.slide_pics').fadeOut(450);
            $('#pic5').fadeIn(450);
        } else if (slideCounter == 38) {
            $('.slide_pics').fadeOut(450);
            $('#pic6').fadeIn(450);
        } else if (slideCounter == 46) {
            $('.slide_pics').fadeOut(450);
            $('#pic7').fadeIn(450);
        } else if (slideCounter == 53) {
            $('.slide_pics').fadeOut(450);
            $('#pic8').fadeIn(450);
            slideCounter = 0;
        }
        slideShow();
    }, 1000);
}
function get_card() {
    $('#yellow_card').click(function () {
        $('#txt_card').val('yellow');
        $('#txt_color_id').val('yellow');
    });
    $('#red_card').click(function () {
        $('#txt_card').val('red');
        $('#txt_color_id').val('red');
    });
}
function show_players_list() {//show and hide
    $('#show_player').click(function () {
        $('#dialog_students').show(300);
        $('#dialog_child').fadeIn(300);
    });
    $('#dialog_students').click(function () {
        $('#dialog_child').fadeOut(300);
        $('#dialog_child_mathces').hide(300);
        $('#dialog_child_trans_requests').hide(300);
        $('#box_get_profile_by_id').fadeOut(300);
        $(this).hide(300);
    });
}
function show_matches_list() {
    $('#show_match').click(function () {
        $('#dialog_students').show(300);
        $('#dialog_child_mathces').fadeIn(300);
    });
}
function show_trans_requests_list() {
    $('#show_trans_requests').click(function () {
        $('#dialog_students').show(300);
        $('#dialog_child_trans_requests').fadeIn(300);
    });
}
function get_students_selected() {
    $('.select_link_students').click(function () {
        var student_id = $(this).attr('value').trim();
        $('#txt_player_id').val(student_id);
        $('#dialog_child').fadeOut(300);
        $('#dialog_students').fadeOut(300);
    });
}
function get_match_selected() {
    $('.select_link_matches').click(function () {
        var match_id = $(this).attr('value').trim();
        $('#txt_match_id').val(match_id);
        $('#dialog_students').hide(300);
        $('#dialog_child_mathces').hide(300);
    });
}
function get_trans_request_selected() {
    $('.select_link_trans_request').click(function () {
        var match_id = $(this).attr('value').trim();//this is the request id though
        var get_player_on_request = $(this).closest('td').siblings('.player_id_col').text().trim();
        var team_to_transfer = $(this).closest('td').siblings('.team_transfer_col').text().trim();
        $('#txt_trans_team_id').val(team_to_transfer);
        $('#txt_player_id').val(get_player_on_request);

        $('#txt_transfer_request_id').val(match_id);
        $('#dialog_students').hide(300);
        $('#dialog_child_trans_requests').hide(300);
    });
}
function get_player_selected_for_profile() {
    $('.get_player_selected_for_profile').click(function () {
        var profile_by_id = $(this).attr('value').trim();
        
        $.post('../Admin/handler.php', {profile_by_id: profile_by_id}, function (data) {
            $('#box_get_profile_by_id').fadeIn(300);
           $('#dialog_students').show(300);
           $('#box_get_profile_by_id').html(data);
            
            $('#dialog_child_trans_requests').fadeIn(300);
             
        });
        return false;
    });
}
function get_away_check() {
    $('#away_check').on('change', function () {
        if ($(this).is(':checked')) {
            $('#another_team').html('Home');
            $('#first_team').html('Away');
            $('#txt_away_id').val($('.cbo_teamA option:selected').text());
            $('#txt_home_id').val($('.cbo_teamB option:selected').text());

        } else {
            $('#another_team').html('Away');
            $('#first_team').html('Home');
//            $('#txt_home_id').val('  ');
            $('#txt_home_id').val($('.cbo_teamA option:selected').text());
            $('#txt_away_id').val($('.cbo_teamB option:selected').text());
        }
    });
}
function get_date_pickin() {
    $('#date_pick').datepicker();
}
function get_link_matches_for_goal() {
    $('.select_link_matches_for_goal').click(function () {
        try {
            var keep_match_id = $(this).attr('value').trim();
            $('#txt_match_id').val(keep_match_id);
            var teamA = $(this).closest('td').siblings('.teamA_col').text().trim();
            var teamB = $(this).closest('td').siblings('.teamB_col').text().trim();

            $.post('../Admin/handler.php', {keep_match_id: keep_match_id}, function (data) {

            }).complete(function () {
                var players_by_teams = 'player_for_teams';
                $.post('../Admin/handler.php', {players_by_teams: players_by_teams, teamA: teamA, teamB: teamB}, function (data) {
                    $('#dialog_child').html(data);
                }).complete(function () {

//                    alert(teamA + '   ' + teamB);
                    //get players according to the match
                    $('#dialog_child').fadeOut(300);
                    $('#dialog_students').fadeOut(300);
                    $('#dialog_child_mathces').fadeOut(300);
                });
            });
        } catch (err) {
            alert(err.message);
        }
    });
}
function get_current_match_displayed() {
    setTimeout(function () {
        $('#current_champ_holder').load('auto_calculations/Last_champ.php');
        var get_match_displed = 'get_match_displed';//note that this value is whatever you want
        $.post('../Admin/handler.php', {get_match_displed: get_match_displed}, function (data) {
            if (data != '') {
                $('#current_match_box').html(data);
            }
        });
        get_current_match_displayed();
    }, 1000);
}
function get_team_by_player() {
    $('.select_link_player').click(function () {
        var team_id = $(this).closest('td').siblings('.team_id_col').text().trim();
        var player_id = $(this).closest('td').siblings('.player_id_col').text().trim();
        var team_name = $(this).closest('td').siblings('.team_name_col').text().trim();

    });

}
function get_player_by_id_link() {
    $('.player_id_link').unbind('click').click(function () {
        var player_by_team = $(this).attr('value').trim();
        $('#txt_player_id').val(player_by_team);
        $('#dialog_child').fadeOut(300);
        $('#dialog_students').fadeOut(300);
        $('#dialog_child_mathces').fadeOut(300);
    });
}//this is on the goal form selcecting a player
function get_current_champ() {
    setTimeout(function () {
        $('#current_champ').delay(300).slideDown(500);
        get_current_champ();
    }, 1000);
}

function get_checkables_checked() {
    $('#check_all').on('change', function () {
        if ($(this).is(':checked')) {
            $('.checkables').prop('checked', true);
        } else {
            $('.checkables').prop('checked', false);
        }
    });
}
function get_show_team_participate() {
    $('#show_team_participating').click(function () {
        $('#dialog_teams_box').show(300);
        $('#dialog_team_child').fadeIn(300);
    });
    $('#dialog_teams_box').click(function () {
        $('#dialog_teams_box').hide(300);
        $('#dialog_team_child').fadeOut(300);
    });

}
function get_confirm_match() {
    $('.match_Confirm_link').click(function () {
        var match_confimr = $(this).attr('value').trim();
        //$(this).closest('tr').css('background-color','#000086');
        $.post('../Admin/handler.php', {match_confimr: match_confimr}, function (data) {
            alert(data);
        });
    });
}
function get_only_team_selected() {
    $('.only_team').unbind('change').change(function () {
        var item = $('.only_team option:selected').val().trim();
        $('#txt_team_id').val(item);
    });
}

function get_schedule_update_link() {
    $('.schedule_update_link').click(function () {
        var schedule_id = $(this).closest('td').siblings('.schedule_id_col').text().trim();
        var match_id = $(this).closest('td').siblings('.match_id_col').text().trim();
        var champ_id = $(this).closest('td').siblings('.champ_id_col').text().trim();
               
        $('#txt_champ_id').val(champ_id);
        $('#txt_match_id').val(match_id);
        

        //search matches and fixture by champ
//        $.post('../Admin/handler.php', {champ_id: champ_id, schedule_id: schedule_id}, function (data) {
//            alert(data);
//        });


        $('#dialog_students').fadeIn(300);
        $('#dialog_update_datePicker').fadeIn(300);
    });
    $('#dialog_students').click(function () {
        $('#dialog_update_datePicker').fadeOut(300);
    });
}
function get_schedule_fields_update() {
    $('#');
}
function disp() {
    setTimeout(function () {
        count += 1;
        if (count == 5) {
            $('#display').animate({fontSize: '+1'}, 1000).animate({fontSize: '35'}, 1000).html('Come and get all your best info');
        } else if (count == 10) {
            $('#display').animate({fontSize: '+1'}, 1000).animate({fontSize: '35'}, 1000).html('Enjoy by viewing national fixtures');
        }
        if (count == 18) {
            $('#display').animate({fontSize: '+1'}, 1000).animate({fontSize: '35'}, 1000).html('Free of access');
            count = 0;
        }
        disp();
    }, 1000);
}
//defaults
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
    $('.two_digits').keyup(function () {
        var nu = $(this).val();
        if (nu > 59) {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}

