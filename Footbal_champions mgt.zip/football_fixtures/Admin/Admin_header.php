<div class="parts  eighty_centered " style="background-color: #2a4e2e;color: #fff;">      
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Foot automatic timetable
    </div>
</div>  
<div class="parts menu eighty_centered">

    <?php
    if ($_SESSION['cat'] == 'Federation') {
        federation_mngr();
    } else if ($_SESSION['cat'] == 'admin') {
        admin_menu();
    } else if ($_SESSION['cat'] == 'team') {
        team_mangr();
    } else if ($_SESSION['cat'] == 'commissioner') {
        commissioner();
    }

    function federation_mngr() {
        ?>
           <a href="new_profile.php">Personal identification</a>
           <a href="new_account.php">account</a>
        <a href="new_account_category.php">accountcategory</a>
     
        <a href="new_championship.php">championship</a>
        <a href="new_team.php">team</a>
        <a href="new_player.php">player</a>
        <a href="new_schedule.php">schedule</a>

        <?php
    }

    function commissioner() {
        ?>
        <a href="new_matches.php">matches</a>
        <!--<a href="#">License</a>-->
        <a href="new_match_participant.php">match participant</a>
        <?php
    }

    function admin_menu() {
        ?>
        <a href="new_goal.php">goal</a>
        <a href="new_penalty.php">penalty</a>
        <a href="new_substitution.php">substitution</a>
        <a href="new_card.php">card</a>
        <?php
    }

    function team_mangr() {?>
        <a href="new_team.php">My Team</a>
        <!--<a href="new_matches.php">Team's events</a>-->
 <?php   }
    ?>
    <!--    <a href="new_fixture.php">fixture</a>
      
        <a href="new_federation_mng.php">federation_mng</a>
        <a href="new_transfer.php">transfer</a>
        <a href="new_trans_request.php">trans_request</a>
         
        <a href="new_team_manager.php">team_manager</a>-->

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="../logout.php">Logout <?php echo '('. $_SESSION['cat'].')'?></a>
    </div>
</div>
<?php
?>

