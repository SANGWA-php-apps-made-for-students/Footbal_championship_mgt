<?php session_start();?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
         require_once './Admin_header.php';
   
        ?>
        <div class="eighty_centered no_shade_noBorder xxx_titles">
            <?php
                  echo 'Welcome '.$_SESSION['names'] .'('.$_SESSION['cat'].')';
            ?>
        </div>
    </body>
</html>
