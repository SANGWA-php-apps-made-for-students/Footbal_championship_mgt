<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_match_participant'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'match_participant') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $match_participant_id = $_SESSION['id_upd'];

            $player = trim($_POST['txt_player_id']);
            $matches = $_POST['txt_matches_id'];

            $substitute_not = $_POST['txt_substitute_not'];


            $upd_obj->update_match_participant($player, $matches, $substitute_not, $match_participant_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $player = trim($_POST['txt_player_id']);
        $matches = trim($_POST['txt_matches_id']);
        $substitute_not = $_POST['txt_substitute_not'];

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_match_participant($player, $matches, $substitute_not);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            match_participant</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_match_participant.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_player_id"   name="txt_player_id"/><input type="hidden" id="txt_matches_id"   name="txt_matches_id"/>
            <?php
            include 'Admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                match_participant saved successfully!</div>

            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  match participant Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_name">Player </label></td><td> <?php get_player_combo(); ?>  </td></tr>
                    <tr><td><label for="txt_name">Match </label></td><td> <?php get_match_combo(); ?>  </td></tr>
                    <tr><td><label for="txt_substitute_not">Substitute  </label></td><td>
                            <select class="textbox" name="txt_substitute_not">
                                <option></option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_match_participant" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">match participant List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_match_participant();
                $obj->list_match_participant($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {

                var player = '<?php echo chosen_player_upd(); ?>';
                $('.cbo_player').val(player);
                $('#txt_player_id').val(player);


                var matches = '<?php echo chosen_matches_upd(); ?>';
                $('.cbo_matches').val(matches);
                $('#txt_matches_id').val(matches);

            }
        </script>
    </body>
</hmtl>
<?php

function chosen_player_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'match_participant') {
            $id = $_SESSION['id_upd'];
            $player = new multi_values();
            return $player->get_chosen_match_participant_player($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_matches_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'match_participant') {
            $id = $_SESSION['id_upd'];
            $matches = new multi_values();
            return $matches->get_chosen_match_participant_matches($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_substitute_not_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'match_participant') {
            $id = $_SESSION['id_upd'];
            $substitute_not = new multi_values();
            return $substitute_not->get_chosen_match_participant_substitute_not($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_player_combo() {
    $obj = new multi_values();
    $obj->get_player_in_combo();
}

function get_match_combo() {
    $obj = new multi_values();
    $obj->get_matches_in_combo();
}
