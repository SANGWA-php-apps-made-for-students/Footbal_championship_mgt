<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_schedule'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'schedule') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $schedule_id = $_SESSION['id_upd'];
            $team = trim($_POST['txt_team_id']);
            $team = $_POST['txt_team_id'];
            $championship = $_POST['txt_championship_id'];
            $date_of_match = $_POST['txt_date_of_match'];
            $upd_obj->update_schedule($team, $team, $championship, $date_of_match, $schedule_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        require_once '../web_db/multi_values.php';
        $mul= new multi_values();
        $teama = trim($_POST['txt_team_id']);
        $teamb = trim($_POST['teamb']);
        $championship = trim($_POST['txt_championship_id']);
        $date_of_match = $_POST['txt_date_of_match'];
        $last_championship=$mul->get_last_championship();
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_schedule($teama, $teamb, $last_championship, $date_of_match);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            schedule</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        
        <link href="../web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_schedule.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_team_id"   name="txt_team_id"/><input type="hidden" id="txt_team_id"   name="txt_team_id"/><input type="hidden" id="txt_championship_id"   name="txt_championship_id"/>
            <?php
            include 'Admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                schedule saved successfully!</div>

            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  schedule Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_teama">Teama </label></td><td><?php teama();?>  </td></tr>
                    <tr><td><label for="txt_teamb">Teamb </label></td><td> <?php teamb();?>  </td></tr>
                   
                    <tr><td><label for="txt_date_of_match">Date of match </label></td><td> <input type="text"     name="txt_date_of_match" required id="txt_date_of_match" class="textbox dates"    />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_schedule" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">schedule List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_schedule();
                $obj->list_schedule($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {

                var team = '<?php echo chosen_team_upd(); ?>';
                $('.cbo_team').val(team);
                $('#txt_team_id').val(team);


                var team = '<?php echo chosen_team_upd(); ?>';
                $('.cbo_team').val(team);
                $('#txt_team_id').val(team);


                var championship = '<?php echo chosen_championship_upd(); ?>';
                $('.cbo_championship').val(championship);
                $('#txt_championship_id').val(championship);

            }
            $('.dates').datepicker({
               dateFormat: 'yy-mm-dd' ,
               minDate:new Date()
            });
        </script>
    </body>
</hmtl>
<?php

 
function chosen_team_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'schedule') {
            $id = $_SESSION['id_upd'];
            $team = new multi_values();
            return $team->get_chosen_schedule_team($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_championship_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'schedule') {
            $id = $_SESSION['id_upd'];
            $championship = new multi_values();
            return $championship->get_chosen_schedule_championship($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_of_match_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'schedule') {
            $id = $_SESSION['id_upd'];
            $date_of_match = new multi_values();
            return $date_of_match->get_chosen_schedule_date_of_match($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function teama() {
    $obj = new multi_values();
    $obj->get_team_in_combo();
}
function teamb() {
    $obj = new multi_values();
    $obj->get_teamB_in_combo();
}
