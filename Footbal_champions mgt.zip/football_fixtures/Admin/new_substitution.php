<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_substitution'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $substitution_id = $_SESSION['id_upd'];

            $match = trim($_POST['txt_match_id']);
            $playert_in = $_POST['txt_playert_in'];
            $player_out = $_POST['txt_player_out'];
            $entry_date = date("y-m-d");

            $User = $_SESSION['userid'];



            $upd_obj->update_substitution($match, $playert_in, $player_out, $entry_date, $User, $substitution_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $match = trim($_POST['txt_matches_id']);
        $playert_in = $_POST['txt_playert_in'];
        $player_out = $_POST['txt_player_out'];
        $entry_date = date("y-m-d");
        $User = $_SESSION['userid'];

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_substitution($match, $playert_in, $player_out, $entry_date, $User);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            substitution</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_substitution.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_matches_id"   name="txt_matches_id"/>
<?php
include 'Admin_header.php';
?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                substitution saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  substitution Registration </div>
                <table class="new_data_table">

                    <tr><td><label for="txt_playert_in">Player In </label></td><td> 
                            <?php get_player_combo();?>
                        
                        </td></tr>
                    <tr><td><label for="txt_player_out">Player_out </label></td><td>  <?php get_player_out_combo();?>  </td></tr>
                    <tr><td><label for="txt_player_out">Match </label></td>  <td> <?php  get_match_combo(); ?>  </td></tr>
                    

                    <tr>   <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_substitution" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">substitution List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_substitution();
                $obj->list_substitution($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {

                var match = '<?php echo chosen_match_upd(); ?>';
                $('.cbo_match').val(match);
                $('#txt_match_id').val(match);

            }
        </script>
    </body>
</hmtl>
<?php

function chosen_match_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            $id = $_SESSION['id_upd'];
            $match = new multi_values();
            return $match->get_chosen_substitution_match($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_playert_in_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            $id = $_SESSION['id_upd'];
            $playert_in = new multi_values();
            return $playert_in->get_chosen_substitution_playert_in($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_player_out_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            $id = $_SESSION['id_upd'];
            $player_out = new multi_values();
            return $player_out->get_chosen_substitution_player_out($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_substitution_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'substitution') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_substitution_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_match_combo() {
    $obj = new multi_values();
    $obj->get_matches_in_combo();

    
}


function get_player_combo() {
     $obj = new multi_values();
    $obj->get_player_in_combo();
}

function get_player_out_combo() {
    $obj = new multi_values();
    $obj->get_player_out_combo();
}
