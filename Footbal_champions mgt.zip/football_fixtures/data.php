<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of data
 *
 * @author SANGWA
 */
class data {

    function get_fixtures() {
        try {
            require_once './web_db/connection.php';
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//            $sql = " select matches.match_id, t1.name as teama, t2.name as teamb,goal.entry_date, count(goal.goal_team_a) as goal1, count(goal.goal_team_b) as goal2 from matches
//                            left join team t1 on t1.team_id=matches.teamA
//                            left join team t2 on t2.team_id=matches.teamB
//                            left join goal on goal.matches=matches.match_id
//                            left join card on card.matches=matches.match_id
//                            left join penalty on penalty.match=penalty.penalty_id
//                            group by matches.match_id   ";

            $sql = "select goal.matches, sum(goal.goal_team_a) goal1,matches.entry_date, sum(goal_team_b) goal2, 
                t1.name as teama, t2.name as teamb from matches
                    left join goal on matches.match_id=goal.matches
                    left join team t1 on t1.team_id=matches.teamA
                    left join team t2 on t2.team_id=matches.teamB
                    group by matches";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
            <table class="dataList_table full_center_two_h heit_free home_table">
                <style>
                    .fixture_link{
                        color: blue;
                    }
                </style>
                <thead style="background-color: #57cf65;"><tr>

                        <td> Team A </td><td>Goals</td>    <td> Team B </td>  <td> Date </td> 
                    </tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    $g1 = ($row['goal1'] > 0) ? $row['goal1'] : 0;
                    $g2 = ($row['goal2'] > 0) ? $row['goal2'] : 0;
                    ?><tr> 
                        <td class="name_id_cols profile " title="profile" >
                            <?php echo $row['teama']; ?>
                        </td>
                        <td>
                            <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
                            <a href="#" class="fixture_link" onclick="fixture_link(this)" style="color: blue;"
                               data-id="<?php echo $row['matches']; ?>"  >
                                <?php echo $g1 . ' - ' . $g2; ?>
                            </a>
                            <script>
                                function fixture_link(item) {

                                    var match_events = $(item).data('id');
                                  var res='';
                                    $.post('handler.php', {match_events: match_events}, function (data) {
                                         res=data;
                                    }).complete(function () {
                                        $('.abs_full').show();
                                        $('#res_holder').show();
                                        $('#res_holder').html(res);
                                        
                                    });
                                    return false;

                                }
                            </script>
                        </td>
                        <td>
                            <?php echo $row['teamb']; ?>
                        </td>
                        <td>
                            <?php echo $row['entry_date']; ?>
                        </td>

                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    function get_fixtures_by_match($match) {
        try {
            require_once './web_db/connection.php';
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = " select matches.match_id, matches.entry_date, goal.matches, sum(goal.goal_team_a) goal1, sum(goal_team_b) goal2, t1.name as teama, t2.name as teamb
              ,count(penalty.penalty_id) as pen,  max(card.card) as card  from matches
                    left join goal on matches.match_id=goal.matches
                    left join team t1 on t1.team_id=matches.teamA
                    left join team t2 on t2.team_id=matches.teamB
                    left join penalty on penalty.match=matches.match_id
                    left join card on card.matches=matches.match_id
                    left join substitution on substitution.matches=matches.match_id
                    
                    where match_id=:match 
                    group by matches.match_id";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":match"=>$match));
            ?>
            <table class="dataList_table full_center_two_h heit_free home_table">
                <style>
                    .fixture_link{
                        color: blue;
                    }
                </style>
                <thead style="background-color: #57cf65;"><tr>

                        <td> Team A </td><td>Goals</td>    <td> Team B </td>  <td> Date </td> <td> Penalty </td><td>Card</td> <td>Date</td> 
                    </tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    $g1 = ($row['goal1'] > 0) ? $row['goal1'] : 0;
                    $g2 = ($row['goal2'] > 0) ? $row['goal2'] : 0;
                    ?><tr> 
                        <td class="name_id_cols profile " title="profile" >
                            <?php echo $row['teama']; ?>
                        </td>
                        <td>
                              <?php echo $g1 . ' - ' . $g2; ?>
                          
                           
                        </td>
                        <td>
                            <?php echo $row['teamb']; ?>
                        </td>
                        <td>
                            <?php echo $row['pen']; ?>
                        </td>
                        <td>
                            <?php echo $row['pen']; ?>
                        </td>
                        <td>
                             <?php echo $row['card']; ?>
                        </td>
                        <td>
                             <?php echo $row['entry_date']; ?>
                        </td>
                    </tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

}
?>
