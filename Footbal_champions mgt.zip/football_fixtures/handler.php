<?php
 if (filter_has_var(INPUT_POST, 'fixture')) {
    echo 'Live updates';
    require_once './data.php';
    $m=new data();
    echo $m->get_fixtures();
}
if (filter_has_var(INPUT_POST, 'match_events')) {
    $match_events=$_POST['match_events'];
    require_once './data.php';
    $m=new data();
    echo $m->get_fixtures_by_match($match_events);
}