<div class="parts  eighty_centered " style="background-color: #57cf65">     
    <div style="float: left; width: 100px;" ></div>
    <div class="parts  no_paddin_shade_no_Border xxx_titles" style="color: #fff; text-transform: capitalize;">
        Football automatic timetable
    </div>
</div>     
<div class="parts menu eighty_centered" style="background-color: #fff;">
    <a href="new_profile.php">Home</a>
    <a href="new_championship.php">About</a>
    <a href="new_schedule.php">Contact us</a>
      
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
<div class="parts eighty_centered no_paddin_shade_no_Border" style="color: #fff;">
    <marquee>
        RWANDAN FOOTBALL ENTERTAINEMENT
    </marquee>
</div>
