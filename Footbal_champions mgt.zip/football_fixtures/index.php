<?php
require_once 'web_db/connection.php';
?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  
        <style>
            .home_table td{
                font-size: 12px;
                padding: 3px;
            }
        </style>
    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>

        <div class="abs_full off" style="position: fixed; z-index: 1;"></div>
        <div id="res_holder" class="off" style="width: 80%;left: 10%;padding: 10px; position: fixed; z-index: 2; background-color: #fff; " id="res">Result</div>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>        
        <div class="parts eighty_centered no_paddin_shade_no_Border xxx_titles" style="color: #fff;">Fixtures</div>
        <div class="parts eighty_centered x_height_4x" style="background-color: #fff;">



        </div>
        <div class="parts eighty_centered footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a>
            </div>    
        </div>  
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                live_updates();
                fixture_link();


                $('.abs_full').click(function () {
                    $('#res_holder').hide();
                });
            });
            function live_updates() {
                setTimeout(function () {
                    var fixture = 'yes';
                    $.post('handler.php', {fixture: fixture}, function (data) {
                        $('.x_height_4x').html(data);
                    }).complete(function () {

                    });
                    live_updates();
                }, 2000);
            }

            function fixture_link() {
                $('.fixture_link').click(function () {

                    return false;
                });
            }

        </script>
    </body>
</html>
