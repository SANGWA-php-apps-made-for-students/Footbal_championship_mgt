
--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`address`     VARCHAR(60) 

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `championship`
--

CREATE TABLE IF NOT EXISTS `championship` (
`championship_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   

,PRIMARY KEY (`championship_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
`schedule_id`     int(11) NOT NULL AUTO_INCREMENT 
, `team`     int(11)   
, `team`     int(11)   
, `championship`     int(11)   
,`date_of_match`     VARCHAR(60) 

,PRIMARY KEY (`schedule_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `fixture`
--

CREATE TABLE IF NOT EXISTS `fixture` (
`fixture_id`     int(11) NOT NULL AUTO_INCREMENT 
, `championship`     int(11)   

,PRIMARY KEY (`fixture_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `matches`
--

CREATE TABLE IF NOT EXISTS `matches` (
`match_id`     int(11) NOT NULL AUTO_INCREMENT 
, `championship`     int(11)   
, `account`     int(11)   
, `teamA`     int(11)   
, `teamB`     int(11)   

,PRIMARY KEY (`match_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `goal`
--

CREATE TABLE IF NOT EXISTS `goal` (
`goal_id`     int(11) NOT NULL AUTO_INCREMENT 
, `matches`     int(11)   
, `player`     int(11)   
, `winner`     int(11)   
,`goal_team_a`     VARCHAR(60) 
,`goal_team_b`     VARCHAR(60) 
,`type`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`goal_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `penalty`
--

CREATE TABLE IF NOT EXISTS `penalty` (
`penalty_id`     int(11) NOT NULL AUTO_INCREMENT 
, `player`     int(11)   
, `match`     int(11)   

,PRIMARY KEY (`penalty_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `substitution`
--

CREATE TABLE IF NOT EXISTS `substitution` (
`substitution_id`     int(11) NOT NULL AUTO_INCREMENT 
, `match`     int(11)   
,`playert_in`     VARCHAR(60) 
,`player_out`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`substitution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `card`
--

CREATE TABLE IF NOT EXISTS `card` (
`card_id`     int(11) NOT NULL AUTO_INCREMENT 
, `player`     int(11)   
, `match`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`card_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
`team_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`team_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
`player_id`     int(11) NOT NULL AUTO_INCREMENT 
, `team`     int(11)   
, `account`     int(11)   
, `profile`     int(11)   

,PRIMARY KEY (`player_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `federation_mng`
--

CREATE TABLE IF NOT EXISTS `federation_mng` (
`federation_mng_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   

,PRIMARY KEY (`federation_mng_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `transfer`
--

CREATE TABLE IF NOT EXISTS `transfer` (
`transfer_id`     int(11) NOT NULL AUTO_INCREMENT 
, `transfer_request`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`transfer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `trans_request`
--

CREATE TABLE IF NOT EXISTS `trans_request` (
`trans_request_id`     int(11) NOT NULL AUTO_INCREMENT 
, `teamA`     int(11)   
, `teamB`     int(11)   
, `player`     int(11)   
, `account`     int(11)   

,PRIMARY KEY (`trans_request_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `match_participant`
--

CREATE TABLE IF NOT EXISTS `match_participant` (
`match_participant_id`     int(11) NOT NULL AUTO_INCREMENT 
, `player`     int(11)   
, `matches`     int(11)   
,`substitute_not`     VARCHAR(60) 

,PRIMARY KEY (`match_participant_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `team_manager`
--

CREATE TABLE IF NOT EXISTS `team_manager` (
`team_manager_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
, `team`     int(11)   
, `created_by`     int(11)   

,PRIMARY KEY (`team_manager_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

