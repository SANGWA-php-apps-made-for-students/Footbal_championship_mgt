<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_profile($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td> Name </td><td> gender </td><td> Address </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="name_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['address']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_address($id) {

            $db = new dbconnection();
            $sql = "select   profile.address from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['address'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_championship($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from championship";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> championship </td>
                    <td> Account </td><td> name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['championship_id']; ?>
                    </td>
                    <td class="account_id_cols championship " title="championship" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="championship_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['championship_id']; ?>"  data-table="championship">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="championship_update_link" style="color: #000080;" data-id_update="<?php echo $row['championship_id']; ?>" data-table="championship" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_championship_account($id) {

            $db = new dbconnection();
            $sql = "select   championship.account from championship where championship_id=:championship_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':championship_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_championship_name($id) {

            $db = new dbconnection();
            $sql = "select   championship.name from championship where championship_id=:championship_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':championship_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_championship() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  championship_id   from championship";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_championship() {
            $con = new dbconnection();
            $sql = "select championship.championship_id from championship
                    order by championship.championship_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['championship_id'];
            return $first_rec;
        }

        function get_last_championship() {
            $con = new dbconnection();
            $sql = "select championship.championship_id from championship
                    order by championship.championship_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['championship_id'];
            return $first_rec;
        }

        function list_schedule($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from schedule "
                    . " join championship on championship.championship_id=schedule.championship ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> schedule </td>
                    <td> Team A </td><td> Team B </td><td> Championship </td><td> Date of match </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['schedule_id']; ?>
                    </td>
                    <td class="team_id_cols schedule " title="schedule" >
                        <?php echo $this->get_team_name_by_id($row['teama']); ?>
                    </td>
                    <td>
                        <?php echo $this->get_team_name_by_id($row['teamb']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_of_match']); ?>
                    </td>


                    <td>
                        <a href="#" class="schedule_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['schedule_id']; ?>"  data-table="schedule">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="schedule_update_link" style="color: #000080;" data-id_update="<?php echo $row['schedule_id']; ?>" data-table="schedule" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field


        function get_chosen_schedule_team($id) {

            $db = new dbconnection();
            $sql = "select   schedule.team from schedule where schedule_id=:schedule_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':schedule_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['team'];
            echo $field;
        }

        function get_chosen_schedule_championship($id) {

            $db = new dbconnection();
            $sql = "select   schedule.championship from schedule where schedule_id=:schedule_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':schedule_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['championship'];
            echo $field;
        }

        function get_chosen_schedule_date_of_match($id) {

            $db = new dbconnection();
            $sql = "select   schedule.date_of_match from schedule where schedule_id=:schedule_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':schedule_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_of_match'];
            echo $field;
        }

        function All_schedule() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  schedule_id   from schedule";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_schedule() {
            $con = new dbconnection();
            $sql = "select schedule.schedule_id from schedule
                    order by schedule.schedule_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['schedule_id'];
            return $first_rec;
        }

        function get_last_schedule() {
            $con = new dbconnection();
            $sql = "select schedule.schedule_id from schedule
                    order by schedule.schedule_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['schedule_id'];
            return $first_rec;
        }

        function list_fixture($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from fixture";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> fixture </td>
                    <td> null </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['fixture_id']; ?>
                    </td>
                    <td class="championship_id_cols fixture " title="fixture" >
                        <?php echo $this->_e($row['championship']); ?>
                    </td>


                    <td>
                        <a href="#" class="fixture_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['fixture_id']; ?>"  data-table="fixture">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="fixture_update_link" style="color: #000080;" data-id_update="<?php echo $row['fixture_id']; ?>" data-table="fixture" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_fixture_championship($id) {

            $db = new dbconnection();
            $sql = "select   fixture.championship from fixture where fixture_id=:fixture_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':fixture_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['championship'];
            echo $field;
        }

        function All_fixture() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  fixture_id   from fixture";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_fixture() {
            $con = new dbconnection();
            $sql = "select fixture.fixture_id from fixture
                    order by fixture.fixture_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['fixture_id'];
            return $first_rec;
        }

        function get_last_fixture() {
            $con = new dbconnection();
            $sql = "select fixture.fixture_id from fixture
                    order by fixture.fixture_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['fixture_id'];
            return $first_rec;
        }

        function list_matches($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from matches "
                    . " join championship on championship.championship_id=matches.championship";
           
            
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> matches </td>
                    <td> Championship </td><td> Team A </td><td> Team B </td>
                    <td> User </td> <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['match_id']; ?>
                    </td>
                    <td class="championship_id_cols matches " title="matches" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>

                    <td>
                        <?php echo $this->get_team_name_by_id($row['teamA']); ?>
                    </td>
                    <td>
                        <?php echo $this->get_team_name_by_id($row['teamB']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                            <a href="#" class="matches_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['match_id']; ?>"  data-table="matches">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="matches_update_link" style="color: #000080;" data-id_update="<?php echo $row['match_id']; ?>" data-table="matches" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_matches_championship($id) {

            $db = new dbconnection();
            $sql = "select   matches.championship from matches where matches_id=:matches_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':matches_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['championship'];
            echo $field;
        }

        function get_chosen_matches_account($id) {

            $db = new dbconnection();
            $sql = "select   matches.account from matches where matches_id=:matches_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':matches_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_matches_teamA($id) {

            $db = new dbconnection();
            $sql = "select   matches.teamA from matches where matches_id=:matches_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':matches_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teamA'];
            echo $field;
        }

        function get_chosen_matches_teamB($id) {

            $db = new dbconnection();
            $sql = "select   matches.teamB from matches where matches_id=:matches_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':matches_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teamB'];
            echo $field;
        }

        function All_matches() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  matches_id   from matches";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_matches() {
            $con = new dbconnection();
            $sql = "select matches.matches_id from matches
                    order by matches.matches_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['matches_id'];
            return $first_rec;
        }

        function get_last_matches() {
            $con = new dbconnection();
            $sql = "select matches.matches_id from matches
                    order by matches.matches_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['matches_id'];
            return $first_rec;
        }

        function list_goal($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
//            $sql = "select * from goal "
//                    . " join player on player.player_id=goal.player"
//                    . " join profile on profile.profile_id=player.profile ";
            
           $sql=" SELECT g.goal_id, m.match_id,m.teamA, m.teamB, t.name as teama, t2.name as teamb, profile.name , g.goal_team_a, g.goal_team_b, g.type, g.entry_date, g.User
                    FROM footbal_profile.goal g
                   join matches m on m.match_id=g.matches
                     join team t on t.team_id=m.teamA  
                   join team t2 on t2.team_id=m.teamB 
                   join player on g.player=player.player_id 
                   join profile on  profile.profile_id=player.profile ";

            
            
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> goal </td>
                    <td> Match </td><td> Player </td><td class="off"> Winner </td>
                    <td> Goals team A </td><td> Goal Team B </td>
                    <td> type </td><td> Entry Date </td><td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <?php echo $row['goal_id']; ?>
                    </td>
                    <td class="matches_id_cols goal " title="goal" >
                        <?php echo $this->_e($row['teama'].' - '.$row['teamb']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td class="off">
                        <?php echo $this->_e($row['winner']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['goal_team_a']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['goal_team_b']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['type']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>


                    <td>
                        <a href="#" class="goal_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['goal_id']; ?>"  data-table="goal">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="goal_update_link" style="color: #000080;" data-id_update="<?php echo $row['goal_id']; ?>" data-table="goal" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_goal_matches($id) {

            $db = new dbconnection();
            $sql = "select   goal.matches from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['matches'];
            echo $field;
        }

        function get_chosen_goal_player($id) {

            $db = new dbconnection();
            $sql = "select   goal.player from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player'];
            echo $field;
        }

        function get_chosen_goal_winner($id) {

            $db = new dbconnection();
            $sql = "select   goal.winner from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['winner'];
            echo $field;
        }

        function get_chosen_goal_goal_team_a($id) {

            $db = new dbconnection();
            $sql = "select   goal.goal_team_a from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['goal_team_a'];
            echo $field;
        }

        function get_chosen_goal_goal_team_b($id) {

            $db = new dbconnection();
            $sql = "select   goal.goal_team_b from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['goal_team_b'];
            echo $field;
        }

        function get_chosen_goal_type($id) {

            $db = new dbconnection();
            $sql = "select   goal.type from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['type'];
            echo $field;
        }

        function get_chosen_goal_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   goal.entry_date from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_goal_User($id) {

            $db = new dbconnection();
            $sql = "select   goal.User from goal where goal_id=:goal_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':goal_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_goal() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  goal_id   from goal";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_goal() {
            $con = new dbconnection();
            $sql = "select goal.goal_id from goal
                    order by goal.goal_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['goal_id'];
            return $first_rec;
        }

        function get_last_goal() {
            $con = new dbconnection();
            $sql = "select goal.goal_id from goal
                    order by goal.goal_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['goal_id'];
            return $first_rec;
        }

        function list_penalty($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select penalty.penalty_id,  t.name as teama, t2.name as teamb , profile.name from penalty "
                    . " join matches m on m.match_id=penalty.match
                     join team t on t.team_id=m.teamA  
                   join team t2 on t2.team_id=m.teamB 
                   join player on player.player_id=penalty.player
                   join profile on profile.profile_id=player.profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> penalty </td>
                    <td> Player </td><td> Match </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <?php echo $row['penalty_id']; ?>
                    </td>
                    <td class="player_id_cols penalty " title="penalty" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['teama'].' - '.$row['teamb']); ?>
                    </td>
                    <td>
                        <a href="#" class="penalty_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['penalty_id']; ?>"  data-table="penalty">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="penalty_update_link" style="color: #000080;" data-id_update="<?php echo $row['penalty_id']; ?>" data-table="penalty" >Update</a>
                    </td>
                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_penalty_player($id) {

            $db = new dbconnection();
            $sql = "select   penalty.player from penalty where penalty_id=:penalty_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':penalty_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player'];
            echo $field;
        }

        function get_chosen_penalty_match($id) {

            $db = new dbconnection();
            $sql = "select   penalty.match from penalty where penalty_id=:penalty_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':penalty_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['match'];
            echo $field;
        }

        function All_penalty() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  penalty_id   from penalty";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_penalty() {
            $con = new dbconnection();
            $sql = "select penalty.penalty_id from penalty
                    order by penalty.penalty_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['penalty_id'];
            return $first_rec;
        }

        function get_last_penalty() {
            $con = new dbconnection();
            $sql = "select penalty.penalty_id from penalty
                    order by penalty.penalty_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['penalty_id'];
            return $first_rec;
        }

        function list_substitution($min) {
            try{
            $database = new dbconnection();
            $db = $database->openConnection();
             $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = " select substitution.substitution_id,t.name as teama, t2.name as teamb, pr1.name as playert_in, pr2.name as player_out, "
                    . " substitution.entry_date,pr3.name as User from substitution "
                    . " join matches m on m.match_id= substitution.matches"
                     . " join team t on t.team_id=m.teamA  
                      join team t2 on t2.team_id=m.teamB   
                      join player  p1 on p1.player_id=substitution.playert_in
                      join player  p2  on p2.player_id=substitution.player_out
                      join profile pr1 on pr1.profile_id=p1.profile 
                      join profile pr2 on pr2.profile_id=p2.profile
                      join account on account.account_id=substitution.User
                      join profile pr3 on pr3.profile_id=account.profile
                    ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> substitution </td>
                    <td> Match </td><td> Player In </td><td> Player_out </td><td> Entry Date </td><td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['substitution_id']; ?>
                    </td>
                    <td class="match_id_cols substitution " title="substitution" >
                        <?php echo $this->_e($row['teama'].' - '.$row['teamb']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['playert_in']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['player_out']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>


                    <td>
                        <a href="#" class="substitution_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['substitution_id']; ?>"  data-table="substitution">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="substitution_update_link" style="color: #000080;" data-id_update="<?php echo $row['substitution_id']; ?>" data-table="substitution" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php 
            } catch (Exception $e){
                echo $e->getMessage();
            }
        }

//chosen individual field
        function get_chosen_substitution_match($id) {

            $db = new dbconnection();
            $sql = "select   substitution.match from substitution where substitution_id=:substitution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':substitution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['match'];
            echo $field;
        }

        function get_chosen_substitution_playert_in($id) {

            $db = new dbconnection();
            $sql = "select   substitution.playert_in from substitution where substitution_id=:substitution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':substitution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['playert_in'];
            echo $field;
        }

        function get_chosen_substitution_player_out($id) {

            $db = new dbconnection();
            $sql = "select   substitution.player_out from substitution where substitution_id=:substitution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':substitution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player_out'];
            echo $field;
        }

        function get_chosen_substitution_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   substitution.entry_date from substitution where substitution_id=:substitution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':substitution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_substitution_User($id) {

            $db = new dbconnection();
            $sql = "select   substitution.User from substitution where substitution_id=:substitution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':substitution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_substitution() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  substitution_id   from substitution";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_substitution() {
            $con = new dbconnection();
            $sql = "select substitution.substitution_id from substitution
                    order by substitution.substitution_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['substitution_id'];
            return $first_rec;
        }

        function get_last_substitution() {
            $con = new dbconnection();
            $sql = "select substitution.substitution_id from substitution
                    order by substitution.substitution_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['substitution_id'];
            return $first_rec;
        }

        function list_card($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select card.card_id, card.card, t.name as teama,t2.name as teamb, p.name, card.entry_date, card.User, p2.name as User "
                    . " from card"
                    . " join matches m on m.match_id=card.matches"
                    . " join team t on t.team_id=m.teamA  
                   join team t2 on t2.team_id=m.teamB  
                   join player on player.player_id=card.player
                   join profile p on p.profile_id=player.profile 
                   join account on account.account_id=card.User
                   join profile p2 on p2.profile_id=account.profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> card </td>
                    <td> Player </td><td>Match</td><td> Card </td>  <td> Entry Date </td>
                    <td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['card_id']; ?>
                    </td>
                    <td class="player_id_cols card " title="card" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['teama'].' - '.$row['teamb']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['card']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>


                    <td>
                        <a href="#" class="card_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['card_id']; ?>"  data-table="card">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="card_update_link" style="color: #000080;" data-id_update="<?php echo $row['card_id']; ?>" data-table="card" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_card_player($id) {

            $db = new dbconnection();
            $sql = "select   card.player from card where card_id=:card_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':card_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player'];
            echo $field;
        }

        function get_chosen_card_match($id) {

            $db = new dbconnection();
            $sql = "select   card.match from card where card_id=:card_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':card_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['match'];
            echo $field;
        }

        function get_chosen_card_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   card.entry_date from card where card_id=:card_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':card_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_card_User($id) {

            $db = new dbconnection();
            $sql = "select   card.User from card where card_id=:card_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':card_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_card() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  card_id   from card";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_card() {
            $con = new dbconnection();
            $sql = "select card.card_id from card
                    order by card.card_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['card_id'];
            return $first_rec;
        }

        function get_last_card() {
            $con = new dbconnection();
            $sql = "select card.card_id from card
                    order by card.card_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['card_id'];
            return $first_rec;
        }

        function list_team($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from team";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> team </td>
                    <td> Name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['team_id']; ?>
                    </td>
                    <td class="name_id_cols team " title="team" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="team_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['team_id']; ?>"  data-table="team">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="team_update_link" style="color: #000080;" data-id_update="<?php echo $row['team_id']; ?>" data-table="team" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }
        function list_team_by_acc($account) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from team where account=:account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":account" => $account));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> team </td>
                    <td> Name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['team_id']; ?>
                    </td>
                    <td class="name_id_cols team " title="team" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="team_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['team_id']; ?>"  data-table="team">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="team_update_link" style="color: #000080;" data-id_update="<?php echo $row['team_id']; ?>" data-table="team" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }
        
        
        
        
        
        
        

//chosen individual field
        function get_chosen_team_name($id) {

            $db = new dbconnection();
            $sql = "select   team.name from team where team_id=:team_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':team_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_team() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  team_id   from team";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_team() {
            $con = new dbconnection();
            $sql = "select team.team_id from team
                    order by team.team_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['team_id'];
            return $first_rec;
        }

        function get_last_team() {
            $con = new dbconnection();
            $sql = "select team.team_id from team
                    order by team.team_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['team_id'];
            return $first_rec;
        }

        function list_player($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select player.player_id, player.account, profile.name, team.name as team  from player "
                    . " join profile on profile.profile_id=player.profile "
                    . " join team on player.team=team.team_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> player </td>
                    <td> Team </td><td> Profile </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['player_id']; ?>
                    </td>
                    <td class="team_id_cols player " title="player" >
                        <?php echo $this->_e($row['team']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="player_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['player_id']; ?>"  data-table="player">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="player_update_link" style="color: #000080;" data-id_update="<?php echo $row['player_id']; ?>" data-table="player" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_player_team($id) {

            $db = new dbconnection();
            $sql = "select   player.team from player where player_id=:player_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':player_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['team'];
            echo $field;
        }

        function get_chosen_player_account($id) {

            $db = new dbconnection();
            $sql = "select   player.account from player where player_id=:player_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':player_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_player_profile($id) {

            $db = new dbconnection();
            $sql = "select   player.profile from player where player_id=:player_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':player_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function All_player() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  player_id   from player";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_player() {
            $con = new dbconnection();
            $sql = "select player.player_id from player
                    order by player.player_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['player_id'];
            return $first_rec;
        }

        function get_last_player() {
            $con = new dbconnection();
            $sql = "select player.player_id from player
                    order by player.player_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['player_id'];
            return $first_rec;
        }

        function list_federation_mng($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from federation_mng";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> federation_mng </td>
                    <td> account </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['federation_mng_id']; ?>
                    </td>
                    <td class="account_id_cols federation_mng " title="federation_mng" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="federation_mng_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['federation_mng_id']; ?>"  data-table="federation_mng">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="federation_mng_update_link" style="color: #000080;" data-id_update="<?php echo $row['federation_mng_id']; ?>" data-table="federation_mng" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_federation_mng_account($id) {

            $db = new dbconnection();
            $sql = "select   federation_mng.account from federation_mng where federation_mng_id=:federation_mng_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':federation_mng_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_federation_mng() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  federation_mng_id   from federation_mng";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_federation_mng() {
            $con = new dbconnection();
            $sql = "select federation_mng.federation_mng_id from federation_mng
                    order by federation_mng.federation_mng_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['federation_mng_id'];
            return $first_rec;
        }

        function get_last_federation_mng() {
            $con = new dbconnection();
            $sql = "select federation_mng.federation_mng_id from federation_mng
                    order by federation_mng.federation_mng_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['federation_mng_id'];
            return $first_rec;
        }

        function list_transfer($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from transfer";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> transfer </td>
                    <td> null </td><td> null </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['transfer_id']; ?>
                    </td>
                    <td class="transfer_request_id_cols transfer " title="transfer" >
                        <?php echo $this->_e($row['transfer_request']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="transfer_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['transfer_id']; ?>"  data-table="transfer">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="transfer_update_link" style="color: #000080;" data-id_update="<?php echo $row['transfer_id']; ?>" data-table="transfer" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_transfer_transfer_request($id) {

            $db = new dbconnection();
            $sql = "select   transfer.transfer_request from transfer where transfer_id=:transfer_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':transfer_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['transfer_request'];
            echo $field;
        }

        function get_chosen_transfer_account($id) {

            $db = new dbconnection();
            $sql = "select   transfer.account from transfer where transfer_id=:transfer_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':transfer_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_transfer() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  transfer_id   from transfer";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_transfer() {
            $con = new dbconnection();
            $sql = "select transfer.transfer_id from transfer
                    order by transfer.transfer_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['transfer_id'];
            return $first_rec;
        }

        function get_last_transfer() {
            $con = new dbconnection();
            $sql = "select transfer.transfer_id from transfer
                    order by transfer.transfer_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['transfer_id'];
            return $first_rec;
        }

        function list_trans_request($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from trans_request";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> trans_request </td>
                    <td> null </td><td> null </td><td> null </td><td> null </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['trans_request_id']; ?>
                    </td>
                    <td class="teamA_id_cols trans_request " title="trans_request" >
                        <?php echo $this->_e($row['teamA']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['teamB']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['player']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['account']); ?>
                    </td>


                    <td>
                        <a href="#" class="trans_request_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['trans_request_id']; ?>"  data-table="trans_request">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="trans_request_update_link" style="color: #000080;" data-id_update="<?php echo $row['trans_request_id']; ?>" data-table="trans_request" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_trans_request_teamA($id) {

            $db = new dbconnection();
            $sql = "select   trans_request.teamA from trans_request where trans_request_id=:trans_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trans_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teamA'];
            echo $field;
        }

        function get_chosen_trans_request_teamB($id) {

            $db = new dbconnection();
            $sql = "select   trans_request.teamB from trans_request where trans_request_id=:trans_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trans_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['teamB'];
            echo $field;
        }

        function get_chosen_trans_request_player($id) {

            $db = new dbconnection();
            $sql = "select   trans_request.player from trans_request where trans_request_id=:trans_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trans_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player'];
            echo $field;
        }

        function get_chosen_trans_request_account($id) {

            $db = new dbconnection();
            $sql = "select   trans_request.account from trans_request where trans_request_id=:trans_request_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':trans_request_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function All_trans_request() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  trans_request_id   from trans_request";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_trans_request() {
            $con = new dbconnection();
            $sql = "select trans_request.trans_request_id from trans_request
                    order by trans_request.trans_request_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['trans_request_id'];
            return $first_rec;
        }

        function get_last_trans_request() {
            $con = new dbconnection();
            $sql = "select trans_request.trans_request_id from trans_request
                    order by trans_request.trans_request_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['trans_request_id'];
            return $first_rec;
        }

        function list_match_participant($min) {
           try{ $database = new dbconnection();
            $db = $database->openConnection();
             $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "select match_participant.match_participant_id,t.name as teama, t2.name as teamb, profile.name as player , match_participant.substitute_not"
                    . " from match_participant "
                    . " join matches m on m.match_id=match_participant.matches "
                    . " join team t on t.team_id=m.teamA  
                   join team t2 on t2.team_id=m.teamB  
                   join player on match_participant.player=player.player_id
                   join profile on profile.profile_id=player.profile
                    ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> S/N </td>
                    <td> Player </td><td> Match </td><td> Substitute </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['match_participant_id']; ?>
                    </td>
                    <td class="player_id_cols match_participant " title="match_participant" >
                        <?php echo $this->_e($row['player']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['teama'].' - '.$row['teamb']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['substitute_not']); ?>
                    </td>


                    <td>
                        <a href="#" class="match_participant_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['match_participant_id']; ?>"  data-table="match_participant">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="match_participant_update_link" style="color: #000080;" data-id_update="<?php echo $row['match_participant_id']; ?>" data-table="match_participant" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
           <?php } catch (Exception $e){
               echo $e->getMessage();
           }
        }

//chosen individual field
        function get_chosen_match_participant_player($id) {

            $db = new dbconnection();
            $sql = "select   match_participant.player from match_participant where match_participant_id=:match_participant_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':match_participant_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['player'];
            echo $field;
        }

        function get_chosen_match_participant_matches($id) {

            $db = new dbconnection();
            $sql = "select   match_participant.matches from match_participant where match_participant_id=:match_participant_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':match_participant_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['matches'];
            echo $field;
        }

        function get_chosen_match_participant_substitute_not($id) {

            $db = new dbconnection();
            $sql = "select   match_participant.substitute_not from match_participant where match_participant_id=:match_participant_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':match_participant_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['substitute_not'];
            echo $field;
        }

        function All_match_participant() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  match_participant_id   from match_participant";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_match_participant() {
            $con = new dbconnection();
            $sql = "select match_participant.match_participant_id from match_participant
                    order by match_participant.match_participant_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['match_participant_id'];
            return $first_rec;
        }

        function get_last_match_participant() {
            $con = new dbconnection();
            $sql = "select match_participant.match_participant_id from match_participant
                    order by match_participant.match_participant_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['match_participant_id'];
            return $first_rec;
        }

        function list_team_manager($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from team_manager";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> team_manager </td>
                    <td> null </td><td> null </td><td> null </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['team_manager_id']; ?>
                    </td>
                    <td class="account_id_cols team_manager " title="team_manager" >
                        <?php echo $this->_e($row['account']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['team']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['created_by']); ?>
                    </td>


                    <td>
                        <a href="#" class="team_manager_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['team_manager_id']; ?>"  data-table="team_manager">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="team_manager_update_link" style="color: #000080;" data-id_update="<?php echo $row['team_manager_id']; ?>" data-table="team_manager" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_team_manager_account($id) {

            $db = new dbconnection();
            $sql = "select   team_manager.account from team_manager where team_manager_id=:team_manager_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':team_manager_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account'];
            echo $field;
        }

        function get_chosen_team_manager_team($id) {

            $db = new dbconnection();
            $sql = "select   team_manager.team from team_manager where team_manager_id=:team_manager_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':team_manager_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['team'];
            echo $field;
        }

        function get_chosen_team_manager_created_by($id) {

            $db = new dbconnection();
            $sql = "select   team_manager.created_by from team_manager where team_manager_id=:team_manager_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':team_manager_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['created_by'];
            echo $field;
        }

        function All_team_manager() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  team_manager_id   from team_manager";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_team_manager() {
            $con = new dbconnection();
            $sql = "select team_manager.team_manager_id from team_manager
                    order by team_manager.team_manager_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['team_manager_id'];
            return $first_rec;
        }

        function get_last_team_manager() {
            $con = new dbconnection();
            $sql = "select team_manager.team_manager_id from team_manager
                    order by team_manager.team_manager_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['team_manager_id'];
            return $first_rec;
        }

        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td> Category </td><td> Date </td><td> Profile </td><td> Username </td><td> Password </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['password']); ?>
                    </td>



                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id']; ?>"  data-table="account">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td> Name </td>
                  </tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                 </tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_team_name_by_id($team) {

            $db = new dbconnection();
            $sql = "select name from team where team_id=:team ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->execute(array(":team" => $team));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_team_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select team.team_id,   team.name from team";
            ?>
        <select name="txt_team_id"   class="textbox cbo_team"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['team_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_championship_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select championship.championship_id,   championship.name from championship";
        ?>
        <select class="textbox cbo_championship"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['championship_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_teamA_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select teamA.teamA_id,   teamA.name from teamA";
        ?>
        <select class="textbox cbo_teamA"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['teamA_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_teamB_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select team.team_id,   team.name from team";
        ?>
        <select class="textbox cbo_teamB" name="teamb" ><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['team_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_matches_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select matches.match_id ,team.name  from matches "
                . "  join team on matches.teamA=team.team_id ";
        ?>
        <select class="textbox cbo_matches" ><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['match_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_winner_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select winner.winner_id,   winner.name from winner";
        ?>
        <select class="textbox cbo_winner"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['winner_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_match_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select match.match_id,   matches.name from match";
        ?>
        <select class="textbox cbo_match"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['match_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }
    function get_profile_acc_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name, account.account_id from profile "
                . " join account on account.profile=profile.profile_id";
        ?>
<select class="textbox cbo_profile" name="txt_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_transfer_request_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select transfer_request.transfer_request_id,   transfer_request.name from transfer_request";
        ?>
        <select class="textbox cbo_transfer_request"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['transfer_request_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_player_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select player.player_id, profile.name from player "
                . " join profile on profile.profile_id=player.profile";
        ?>
<select class="textbox cbo_player" name="txt_playert_in"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['player_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_player_out_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select player.player_id, profile.name from player "
                . " join profile on profile.profile_id=player.profile";
        ?>
        <select class="textbox cbo_player" name="txt_player_out"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['player_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_created_by_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select created_by.created_by_id,   created_by.name from created_by";
        ?>
        <select class="textbox cbo_created_by"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['created_by_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    
    function get_fixtures() {
         try {
             require_once 'web_db/multi_values.php';
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = " select matches.match_id, t1.name as teama, t2.name as teamb,goal.entry_date, count(goal.goal_team_a) as goal1, count(goal.goal_team_b) as goal2 from matches
                            left join team t1 on t1.team_id=matches.teamA
                            left join team t2 on t2.team_id=matches.teamB
                            left join goal on goal.matches
                            left join card on card.matches=matches.match_id
                            left join penalty on penalty.match=penalty.penalty_id
                            group by matches.match_id   ";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                ?>
                <table class="dataList_table full_center_two_h heit_free home_table">
                    <thead style="background-color: #57cf65;"><tr>

                            <td> Team A </td><td>Goals</td>    <td> Team B </td>  <td> Date </td> 
                        </tr></thead>
                    <?php
                    $pages = 1;
                    while ($row = $stmt->fetch()) {
                        ?><tr> 

                            <td class="name_id_cols profile " title="profile" >
                                <?php echo $row['teama']; ?>
                            </td>
                            <td>
                                <?php echo $row['goal1'] . ' - ' . $row['goal2']; ?>
                            </td>
                            <td>
                                <?php echo $row['teamb']; ?>
                            </td>
                            <td>
                                <?php echo $row['entry_date']; ?>
                            </td>

                        </tr>
                        <?php
                        $pages += 1;
                    }
                    ?></table>
                <?php
            } catch (Exception $e) {
                echo $e->getMessage();
            }
    }
    
    
    
    
    
    
    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

}
