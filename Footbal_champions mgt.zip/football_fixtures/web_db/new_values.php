<?php

class new_values {

    function new_profile($name, $gender, $address) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :name,  :gender,  :address)");
            $stm->execute(array(':profile_id' => 0, ':name' => $name, ':gender' => $gender, ':address' => $address
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_championship($account, $name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into championship values(:championship_id, :account,:name)");
            $stm->execute(array(':championship_id' => 0, ':account' => $account, ':name' => $name));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_schedule($teama, $teamb, $championship, $date_of_match) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into schedule values(:schedule_id, :teama,  :teamb,  :championship,  :date_of_match)");
            $stm->execute(array(':schedule_id' => 0, ':teama' => $teama, ':teamb' => $teamb, ':championship' => $championship, ':date_of_match' => $date_of_match
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_fixture($championship) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into fixture values(:fixture_id, :championship)");
            $stm->execute(array(':fixture_id' => 0, ':championship' => $championship
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_matches($championship, $account, $teamA, $teamB,$date) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into matches values(:matches_id, :championship,  :account,  :teamA,  :teamB, :entry_date)");
            $stm->execute(array(':matches_id' => 0, ':championship' => $championship, ':account' => $account, ':teamA' => $teamA, ':teamB' => $teamB,':entry_date'=>$date            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_goal($matches, $player, $winner, $goal_team_a, $goal_team_b, $type, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into goal values(:goal_id, :matches,  :player,  :winner,  :goal_team_a,  :goal_team_b,  :type,  :entry_date,  :User)");
            $stm->execute(array(':goal_id' => 0, ':matches' => $matches, ':player' => $player, ':winner' => $winner, ':goal_team_a' => $goal_team_a, ':goal_team_b' => $goal_team_b, ':type' => $type, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_penalty($player, $match) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into penalty values(:penalty_id, :player,  :match)");
            $stm->execute(array(':penalty_id' => 0, ':player' => $player, ':match' => $match
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_substitution($match, $playert_in, $player_out, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into substitution values(:substitution_id, :match,  :playert_in,  :player_out,  :entry_date,  :User)");
            $stm->execute(array(':substitution_id' => 0, ':match' => $match, ':playert_in' => $playert_in, ':player_out' => $player_out, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_card($player, $match, $entry_date, $User, $card) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into card values(:card_id, :player,  :match,  :entry_date,  :User, :card)");
            $stm->execute(array(':card_id' => 0, ':player' => $player, ':match' => $match, ':entry_date' => $entry_date, ':User' => $User, ':card' => $card));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_team($name, $account) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into team values(:team_id, :name,:account)");
            $stm->execute(array(':team_id' => 0, ':name' => $name, ':account' => $account));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }
  

    function new_player($team, $account, $profile) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into player values(:player_id, :team,  :account,  :profile)");
            $stm->execute(array(':player_id' => 0, ':team' => $team, ':account' => $account, ':profile' => $profile
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_federation_mng($account) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into federation_mng values(:federation_mng_id, :account)");
            $stm->execute(array(':federation_mng_id' => 0, ':account' => $account
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_transfer($transfer_request, $account) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into transfer values(:transfer_id, :transfer_request,  :account)");
            $stm->execute(array(':transfer_id' => 0, ':transfer_request' => $transfer_request, ':account' => $account
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_trans_request($teamA, $teamB, $player, $account) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into trans_request values(:trans_request_id, :teamA,  :teamB,  :player,  :account)");
            $stm->execute(array(':trans_request_id' => 0, ':teamA' => $teamA, ':teamB' => $teamB, ':player' => $player, ':account' => $account
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_match_participant($player, $matches, $substitute_not) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into match_participant values(:match_participant_id, :player,  :matches,  :substitute_not)");
            $stm->execute(array(':match_participant_id' => 0, ':player' => $player, ':matches' => $matches, ':substitute_not' => $substitute_not
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_team_manager($account, $team, $created_by) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into team_manager values(:team_manager_id, :account,  :team,  :created_by)");
            $stm->execute(array(':team_manager_id' => 0, ':account' => $account, ':team' => $team, ':created_by' => $created_by
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account_category($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
            $stm->execute(array(':account_category_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
