<?php

require_once 'connection.php';
class updates{

 function update_profile( $name, $gender, $address,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
name= ?, gender= ?, address= ? WHERE profile_id=?");
$stmt->execute(array($name, $gender, $address ,$profile_id ));

}
 function update_championship( $account,$championship_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE championship set 
account= ? WHERE championship_id=?");
$stmt->execute(array($account ,$championship_id ));

}
 function update_schedule( $team, $team, $championship, $date_of_match,$schedule_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE schedule set 
team= ?, team= ?, championship= ?, date_of_match= ? WHERE schedule_id=?");
$stmt->execute(array($team, $team, $championship, $date_of_match ,$schedule_id ));

}
 function update_fixture( $championship,$fixture_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE fixture set 
championship= ? WHERE fixture_id=?");
$stmt->execute(array($championship ,$fixture_id ));

}
 function update_matches( $championship, $account, $teamA, $teamB,$matches_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE matches set 
championship= ?, account= ?, teamA= ?, teamB= ? WHERE matches_id=?");
$stmt->execute(array($championship, $account, $teamA, $teamB ,$matches_id ));

}
 function update_goal( $matches, $player, $winner, $goal_team_a, $goal_team_b, $type, $entry_date, $User,$goal_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE goal set 
matches= ?, player= ?, winner= ?, goal_team_a= ?, goal_team_b= ?, type= ?, entry_date= ?, User= ? WHERE goal_id=?");
$stmt->execute(array($matches, $player, $winner, $goal_team_a, $goal_team_b, $type, $entry_date, $User ,$goal_id ));

}
 function update_penalty( $player, $match,$penalty_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE penalty set 
player= ?, match= ? WHERE penalty_id=?");
$stmt->execute(array($player, $match ,$penalty_id ));

}
 function update_substitution( $match, $playert_in, $player_out, $entry_date, $User,$substitution_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE substitution set 
match= ?, playert_in= ?, player_out= ?, entry_date= ?, User= ? WHERE substitution_id=?");
$stmt->execute(array($match, $playert_in, $player_out, $entry_date, $User ,$substitution_id ));

}
 function update_card( $player, $match, $entry_date, $User,$card_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE card set 
player= ?, match= ?, entry_date= ?, User= ? WHERE card_id=?");
$stmt->execute(array($player, $match, $entry_date, $User ,$card_id ));

}
 function update_team( $name,$team_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE team set 
name= ? WHERE team_id=?");
$stmt->execute(array($name ,$team_id ));

}
 function update_player( $team, $account, $profile,$player_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE player set 
team= ?, account= ?, profile= ? WHERE player_id=?");
$stmt->execute(array($team, $account, $profile ,$player_id ));

}
 function update_federation_mng( $account,$federation_mng_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE federation_mng set 
account= ? WHERE federation_mng_id=?");
$stmt->execute(array($account ,$federation_mng_id ));

}
 function update_transfer( $transfer_request, $account,$transfer_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE transfer set 
transfer_request= ?, account= ? WHERE transfer_id=?");
$stmt->execute(array($transfer_request, $account ,$transfer_id ));

}
 function update_trans_request( $teamA, $teamB, $player, $account,$trans_request_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE trans_request set 
teamA= ?, teamB= ?, player= ?, account= ? WHERE trans_request_id=?");
$stmt->execute(array($teamA, $teamB, $player, $account ,$trans_request_id ));

}
 function update_match_participant( $player, $matches, $substitute_not,$match_participant_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE match_participant set 
player= ?, matches= ?, substitute_not= ? WHERE match_participant_id=?");
$stmt->execute(array($player, $matches, $substitute_not ,$match_participant_id ));

}
 function update_team_manager( $account, $team, $created_by,$team_manager_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE team_manager set 
account= ?, team= ?, created_by= ? WHERE team_manager_id=?");
$stmt->execute(array($account, $team, $created_by ,$team_manager_id ));

}
 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}

}

